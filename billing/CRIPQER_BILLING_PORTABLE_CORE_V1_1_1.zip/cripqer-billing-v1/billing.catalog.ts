/**
 * CRIPQER BILLING V1 — single source of truth for plans, prices, provider IDs
 * and billing policies. UI components must read from here only.
 *
 * DEMO / PLACEHOLDER DATA — NOT A CRIPQER PRODUCT DECISION.
 * Every price, feature string, limit and provider ID in this file is a
 * placeholder used only to exercise the flow. They are NOT final Cripqer
 * pricing or entitlements and MUST be replaced by the production catalog
 * during host integration. Prices are in minor units (cents).
 */

import type {
  BillingCatalog,
  BillingInterval,
  CurrencyCode,
  PlanDefinition,
  PlanId,
} from "./billing.types";

/** PLACEHOLDER catalog — replace wholesale with the production catalog. */
export const BILLING_CATALOG: BillingCatalog = {
  version: "1.1.0-placeholder",
  defaultCurrency: "USD",
  defaultInterval: "monthly",
  enabledProviders: ["stripe", "mercado_pago", "paypal"],
  policies: {
    proration: "provider_default",
    downgradeEffective: "period_end",
    cancellation: "at_period_end",
    refunds: "manual_review",
    enterpriseDirectCheckout: false,
    showYearlySavings: true,
  },
  plans: [
    {
      id: "free",
      name: "Free",
      description: "Publica tu página Cripqer y comparte tu QR.",
      monthlyPrice: 0,
      yearlyPrice: 0,
      currency: "USD",
      badge: null,
      features: [
        "1 página pública",
        "QR básico",
        "Editor rápido",
        "Plantillas esenciales",
      ],
      limits: { pages: 1, customDomains: 0, teamMembers: 1 },
      recommended: false,
      checkoutEnabled: false,
      contactSales: false,
      ctaLabel: "Comenzar gratis",
      stripePriceIds: { monthly: null, yearly: null },
      paypalPlanIds: { monthly: null, yearly: null },
      mercadoPagoPlanIds: { monthly: null, yearly: null },
    },
    {
      id: "pro",
      name: "Pro",
      description: "Para creadores y profesionales independientes.",
      monthlyPrice: 900,
      yearlyPrice: 9000,
      currency: "USD",
      badge: "Más elegido",
      features: [
        "Páginas ilimitadas",
        "Power Editor",
        "Bloques premium",
        "QR personalizado",
        "Sin marca Cripqer",
      ],
      limits: { pages: null, customDomains: 1, teamMembers: 1 },
      recommended: true,
      checkoutEnabled: true,
      contactSales: false,
      ctaLabel: "Elegir Pro",
      stripePriceIds: { monthly: "price_pro_monthly_TEST", yearly: "price_pro_yearly_TEST" },
      paypalPlanIds: { monthly: "P-PRO-MONTHLY-TEST", yearly: "P-PRO-YEARLY-TEST" },
      mercadoPagoPlanIds: { monthly: "mp_pro_monthly_TEST", yearly: "mp_pro_yearly_TEST" },
    },
    {
      id: "business",
      name: "Business",
      description: "Para equipos y marcas que necesitan control y escala.",
      monthlyPrice: 2900,
      yearlyPrice: 29000,
      currency: "USD",
      badge: null,
      features: [
        "Todo lo de Pro",
        "Multi-usuario",
        "Dominios personalizados",
        "Roles y permisos",
        "Soporte prioritario",
      ],
      limits: { pages: null, customDomains: 5, teamMembers: 10 },
      recommended: false,
      checkoutEnabled: true,
      contactSales: false,
      ctaLabel: "Elegir Business",
      stripePriceIds: { monthly: "price_biz_monthly_TEST", yearly: "price_biz_yearly_TEST" },
      paypalPlanIds: { monthly: "P-BIZ-MONTHLY-TEST", yearly: "P-BIZ-YEARLY-TEST" },
      mercadoPagoPlanIds: { monthly: "mp_biz_monthly_TEST", yearly: "mp_biz_yearly_TEST" },
    },
    {
      id: "enterprise",
      name: "Enterprise",
      description: "Implementaciones a medida, seguridad y acuerdos de servicio.",
      monthlyPrice: null,
      yearlyPrice: null,
      currency: "USD",
      badge: null,
      features: [
        "Todo lo de Business",
        "SSO y controles avanzados",
        "Onboarding asistido",
        "Contrato y SLA",
      ],
      limits: { pages: null, customDomains: null, teamMembers: null },
      recommended: false,
      checkoutEnabled: false,
      contactSales: true,
      ctaLabel: "Contactar ventas",
      stripePriceIds: { monthly: null, yearly: null },
      paypalPlanIds: { monthly: null, yearly: null },
      mercadoPagoPlanIds: { monthly: null, yearly: null },
    },
  ],
};

/* -------------------------------- helpers -------------------------------- */

export function getPlan(planId: PlanId, catalog: BillingCatalog = BILLING_CATALOG) {
  return catalog.plans.find((p) => p.id === planId) ?? null;
}

export function getPrice(plan: PlanDefinition, interval: BillingInterval): number | null {
  return interval === "yearly" ? plan.yearlyPrice : plan.monthlyPrice;
}

export function getProviderPlanId(
  plan: PlanDefinition,
  provider: "stripe" | "mercado_pago" | "paypal",
  interval: BillingInterval,
): string | null {
  const map =
    provider === "stripe"
      ? plan.stripePriceIds
      : provider === "paypal"
        ? plan.paypalPlanIds
        : plan.mercadoPagoPlanIds;
  return (interval === "yearly" ? map.yearly : map.monthly) ?? null;
}

/** Checkout is possible only when the catalog enables it AND an ID exists. */
export function isCheckoutAvailable(
  plan: PlanDefinition,
  provider: "stripe" | "mercado_pago" | "paypal",
  interval: BillingInterval,
  catalog: BillingCatalog = BILLING_CATALOG,
): boolean {
  if (plan.contactSales && !catalog.policies.enterpriseDirectCheckout) return false;
  if (!plan.checkoutEnabled && !plan.contactSales) return false;
  return Boolean(getProviderPlanId(plan, provider, interval));
}

/** Display formatting only. No currency conversion anywhere in the UI. */
export function formatPrice(
  minorUnits: number | null,
  currency: CurrencyCode,
  locale = "es-CL",
): string {
  if (minorUnits === null) return "—";
  const zeroDecimal = ["CLP", "JPY", "KRW", "COP", "PYG", "VND"].includes(currency);
  const value = zeroDecimal ? minorUnits : minorUnits / 100;
  try {
    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency,
      minimumFractionDigits: zeroDecimal ? 0 : value % 1 === 0 ? 0 : 2,
    }).format(value);
  } catch {
    return `${value} ${currency}`;
  }
}

/** Derived from real catalog prices — never a fabricated discount. */
export function yearlySavingsPercent(plan: PlanDefinition): number | null {
  if (!plan.monthlyPrice || !plan.yearlyPrice) return null;
  const full = plan.monthlyPrice * 12;
  if (full <= plan.yearlyPrice) return null;
  return Math.round(((full - plan.yearlyPrice) / full) * 100);
}
