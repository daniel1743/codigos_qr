/**
 * CRIPQER BILLING V1 — server boundary contract.
 *
 * This file defines WHAT the host server must expose. It contains no secrets
 * and performs no provider calls. The default implementation is an HTTP client
 * plus a mock client for sandbox/demo use.
 *
 * SERVER-ONLY values (never in the browser):
 *   STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET,
 *   MERCADOPAGO_ACCESS_TOKEN, MERCADOPAGO_WEBHOOK_SECRET,
 *   PAYPAL_CLIENT_SECRET, PAYPAL_WEBHOOK_ID
 */

import type {
  BillingInterval,
  CheckoutSelection,
  CheckoutSession,
  EntitlementSnapshot,
  HostUser,
  PlanId,
  ProviderId,
  Subscription,
} from "./billing.types";

/* ------------------------------- endpoints -------------------------------- */

export const BILLING_ENDPOINTS = {
  createCheckout: "POST /api/billing/checkout",
  getCheckoutStatus: "GET  /api/billing/checkout/:checkoutId",
  getSubscription: "GET  /api/billing/subscription",
  cancelSubscription: "POST /api/billing/subscription/cancel",
  reactivateSubscription: "POST /api/billing/subscription/reactivate",
  changePlan: "POST /api/billing/subscription/change-plan",
  manageBilling: "POST /api/billing/portal",
  entitlements: "GET  /api/billing/entitlements",
  webhookStripe: "POST /api/public/billing/webhooks/stripe",
  webhookMercadoPago: "POST /api/public/billing/webhooks/mercado-pago",
  webhookPayPal: "POST /api/public/billing/webhooks/paypal",
} as const;

/* -------------------------- request/response DTOs -------------------------- */

/**
 * Logical return intent. The browser NEVER sends absolute success/cancel URLs:
 * the server builds them from its own base URL + an allowlisted intent.
 */
export type ReturnIntent = "billing" | "pricing" | "dashboard";

export interface CreateCheckoutRequest extends CheckoutSelection {
  /**
   * Display-only hints. The SERVER must re-derive userId from the session and
   * ignore anything else supplied here for authorization purposes.
   */
  user: HostUser;
  /** Allowlisted logical destination; the server constructs the real URLs. */
  returnIntent?: ReturnIntent;
}

/**
 * SERVER TRUST BOUNDARY (documented contract, enforced by the host):
 *  - planId / interval / provider from the browser are REQUESTS only.
 *  - amount, currency and the provider price/plan ID are resolved from the
 *    SERVER-side billing catalog; client values are never trusted.
 *  - successUrl / cancelUrl are built server-side from `returnIntent`.
 *  - every mutating call requires an authenticated session, subscription
 *    ownership validation, and (for cookie auth) Origin/CSRF validation.
 */
export const SERVER_TRUST_RULES = [
  "resolve price, currency and provider price/plan ID from the server catalog",
  "reject or ignore any amount/currency/priceId supplied by the browser",
  "build success/cancel URLs server-side from an allowlisted return intent",
  "re-derive userId from the session, never from the request body",
  "validate that the session user owns the subscriptionId before mutating",
  "validate Origin/Referer + CSRF token on cookie-authenticated mutations",
  "verify webhook signatures over the raw body and claim event IDs atomically",
] as const;

export interface ChangePlanRequest {
  subscriptionId: string;
  planId: PlanId;
  interval: BillingInterval;
}

export interface CancelRequest {
  subscriptionId: string;
  /** Falls back to catalog policy when omitted. */
  atPeriodEnd?: boolean;
}

export interface ReactivateRequest {
  /** Undoes a scheduled cancellation (cancelAtPeriodEnd = true). */
  subscriptionId: string;
}

export interface ManageBillingResponse {
  /** Provider-hosted portal URL, or null when the provider has none. */
  portalUrl: string | null;
}

/* --------------------------------- client --------------------------------- */

export interface BillingServerClient {
  createCheckout(req: CreateCheckoutRequest): Promise<CheckoutSession>;
  /** Authoritative checkout confirmation. The ONLY valid success signal. */
  getCheckoutStatus(checkoutId: string): Promise<CheckoutSession>;
  getSubscription(): Promise<Subscription | null>;
  cancelSubscription(req: CancelRequest): Promise<Subscription>;
  reactivateSubscription(req: ReactivateRequest): Promise<Subscription>;
  changePlan(req: ChangePlanRequest): Promise<Subscription>;
  manageBilling(provider: ProviderId): Promise<ManageBillingResponse>;
  getEntitlements(): Promise<EntitlementSnapshot>;
}


async function json<T>(input: string, init?: RequestInit): Promise<T> {
  const res = await fetch(input, {
    credentials: "include",
    headers: { "content-type": "application/json" },
    ...init,
  });
  if (!res.ok) {
    let message = `Billing request failed (${res.status})`;
    try {
      const body = (await res.json()) as { message?: string };
      if (body?.message) message = body.message;
    } catch {
      /* ignore */
    }
    throw new Error(message);
  }
  return (await res.json()) as T;
}

/** Real client: talks to the host server only. No provider secrets involved. */
export function createHttpBillingClient(baseUrl = ""): BillingServerClient {
  const u = (p: string) => `${baseUrl}${p}`;
  return {
    createCheckout: (req) =>
      json(u("/api/billing/checkout"), { method: "POST", body: JSON.stringify(req) }),
    getCheckoutStatus: (id) => json(u(`/api/billing/checkout/${encodeURIComponent(id)}`)),
    getSubscription: () => json(u("/api/billing/subscription")),
    cancelSubscription: (req) =>
      json(u("/api/billing/subscription/cancel"), { method: "POST", body: JSON.stringify(req) }),
    reactivateSubscription: (req) =>
      json(u("/api/billing/subscription/reactivate"), {
        method: "POST",
        body: JSON.stringify(req),
      }),
    changePlan: (req) =>
      json(u("/api/billing/subscription/change-plan"), {
        method: "POST",
        body: JSON.stringify(req),
      }),
    manageBilling: (provider) =>
      json(u("/api/billing/portal"), { method: "POST", body: JSON.stringify({ provider }) }),
    getEntitlements: () => json(u("/api/billing/entitlements")),
  };
}

/* ---------------------------------- mock ---------------------------------- */

export type MockOutcome = "success" | "pending" | "failed" | "cancelled";

/**
 * Sandbox client used by the demo screens and by host developers before the
 * real server exists. Deterministic, no network, no secrets.
 */
export function createMockBillingClient(options?: {
  outcome?: MockOutcome;
  latencyMs?: number;
  initialSubscription?: Subscription | null;
}): BillingServerClient {
  const latency = options?.latencyMs ?? 500;
  const outcome: MockOutcome = options?.outcome ?? "success";
  let subscription: Subscription | null = options?.initialSubscription ?? null;
  let pending: CheckoutSelection | null = null;
  const wait = () => new Promise((r) => setTimeout(r, latency));

  const nowIso = () => new Date().toISOString();
  const plusDays = (d: number) => new Date(Date.now() + d * 86_400_000).toISOString();

  return {
    async createCheckout(req) {
      await wait();
      pending = req;
      if (outcome === "failed") {
        return {
          checkoutId: "chk_mock_failed",
          provider: req.provider,
          status: "failed",
          message: "El pago fue rechazado por el emisor (sandbox).",
        };
      }
      if (outcome === "cancelled") {
        return {
          checkoutId: "chk_mock_cancelled",
          provider: req.provider,
          status: "cancelled",
          message: "Pago cancelado por el usuario (sandbox).",
        };
      }
      return {
        checkoutId: `chk_mock_${outcome}`,
        provider: req.provider,
        status: outcome === "pending" ? "pending" : "success",
        redirectUrl: null,
        clientToken: null,
        message:
          outcome === "pending"
            ? "Pago en revisión. Confirmaremos por webhook (sandbox)."
            : "Pago aprobado (sandbox).",
      };
    },
    async getCheckoutStatus(checkoutId) {
      await wait();
      const status = checkoutId.endsWith("pending")
        ? "pending"
        : checkoutId.endsWith("failed")
          ? "failed"
          : checkoutId.endsWith("cancelled")
            ? "cancelled"
            : "success";
      if (status === "success" && pending) {
        subscription = {
          subscriptionId: "sub_mock_1",
          userId: "user_mock",
          planId: pending.planId,
          provider: pending.provider,
          providerCustomerId: "cus_mock",
          providerSubscriptionId: "psub_mock",
          billingInterval: pending.interval,
          currency: pending.currency,
          status: "active",
          currentPeriodStart: nowIso(),
          currentPeriodEnd: plusDays(pending.interval === "yearly" ? 365 : 30),
          cancelAtPeriodEnd: false,
          paymentMethodLabel: "Visa •••• 4242",
          createdAt: nowIso(),
          updatedAt: nowIso(),
        };
      }
      return { checkoutId, provider: pending?.provider ?? "stripe", status };
    },
    async getSubscription() {
      await wait();
      return subscription;
    },
    async cancelSubscription(req) {
      await wait();
      if (!subscription) throw new Error("No hay suscripción activa.");
      subscription = {
        ...subscription,
        cancelAtPeriodEnd: req.atPeriodEnd !== false,
        status: req.atPeriodEnd === false ? "cancelled" : subscription.status,
        updatedAt: nowIso(),
      };
      return subscription;
    },
    async reactivateSubscription(req) {
      await wait();
      if (!subscription || subscription.subscriptionId !== req.subscriptionId) {
        throw new Error("No hay suscripción activa.");
      }
      subscription = { ...subscription, cancelAtPeriodEnd: false, updatedAt: nowIso() };
      return subscription;
    },
    async changePlan(req) {
      await wait();
      if (!subscription) throw new Error("No hay suscripción activa.");
      subscription = {
        ...subscription,
        planId: req.planId,
        billingInterval: req.interval,
        updatedAt: nowIso(),
      };
      return subscription;
    },
    async manageBilling() {
      await wait();
      return { portalUrl: null };
    },
    async getEntitlements() {
      await wait();
      return {
        userId: subscription?.userId ?? "user_mock",
        plan: subscription?.planId ?? "free",
        subscriptionStatus: subscription?.status ?? "free",
        validUntil: subscription?.currentPeriodEnd ?? null,
        entitlements: [],
      };
    },
  };
}
