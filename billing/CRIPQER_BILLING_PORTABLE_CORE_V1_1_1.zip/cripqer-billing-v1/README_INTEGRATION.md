# CRIPQER BILLING V1.1 — Integration Contract

Standalone, portable billing & subscription module. Not integrated into the
Cripqer app: copy this folder into the receiving repository and wire it up.

## 1. Delivered files

| File | Purpose |
| --- | --- |
| `billing.types.ts` | Normalized domain types: plans, providers, subscription, entitlements, checkout states. No dependencies. |
| `billing.catalog.ts` | **Single source of truth** for plan names, prices, currencies, features, limits, CTAs, provider price/plan IDs and billing policies + formatting helpers. |
| `billing.providers.ts` | Provider abstraction: metadata per provider and a single `ProviderAdapter` (`createCheckout`, `getSubscription`, `cancelSubscription`, `getCheckoutStatus`, `changePlan`, `reactivateSubscription`, `manageBilling`, checkout hand-off). All provider differences live here. |
| `billing.server-contract.ts` | Server boundary: endpoint list, request/response DTOs, `BillingServerClient` interface, real HTTP client and a deterministic **mock/sandbox client**. |
| `billing.webhooks.ts` | **Server-only.** Normalizes Stripe / Mercado Pago / PayPal events to internal events, plus signature-verification, **atomic** idempotency and authoritative-resource-lookup contracts and a reference `processWebhook` pipeline. |
| `PricingPlans.tsx` | Pricing cards, monthly/yearly toggle, recommended badge, current plan, feature list. Reads only the catalog. |
| `BillingCheckout.tsx` | Plan summary → provider selection → provider-secure payment → **return flow confirmed via `getCheckoutStatus`** → processing / pending / success / failed / cancelled. Active subscribers are routed to `changePlan()` with a confirmation summary. |
| `BillingAccount.tsx` | Current plan, status, cycle, renewal date, provider, masked payment label, change plan / manage payment / **cancel with confirmation** / **reactivate** a scheduled cancellation. |
| `billing.css` | Scoped styles under `.cq-billing`. No global resets, no CSS framework. |
| `README_INTEGRATION.md` | This document. |

Nothing else was created. **Cripqer source files modified: 0.**

## 2. Dependencies

Runtime dependencies of the delivered code: **React only** (`react` ≥ 18).
No UI framework, no state library, no HTTP library (uses `fetch`).

Provider SDKs are **not imported** by these files. Install only the ones you
actually use, on the side that needs them:

| Provider | Client (browser) | Server |
| --- | --- | --- |
| Stripe | `@stripe/stripe-js` (only if you switch to embedded Payment Element) | `stripe` |
| Mercado Pago | `@mercadopago/sdk-react` (only for embedded brick) | `mercadopago` |
| PayPal | `@paypal/react-paypal-js` (only for embedded buttons) | none required (REST API via `fetch`) |

The default flow is **hosted redirect / approval redirect**, which needs no
client SDK at all.

## 3. Environment variables (names only — no secrets here)

Browser-safe (publishable identifiers only):

```
VITE_STRIPE_PUBLISHABLE_KEY
VITE_MERCADOPAGO_PUBLIC_KEY
VITE_PAYPAL_CLIENT_ID
```

Server-only (never bundled into the client):

```
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET
MERCADOPAGO_ACCESS_TOKEN
MERCADOPAGO_WEBHOOK_SECRET
PAYPAL_CLIENT_ID
PAYPAL_CLIENT_SECRET
PAYPAL_WEBHOOK_ID
BILLING_SUCCESS_URL
BILLING_CANCEL_URL
```

## 4. Frontend integration points

```tsx
import "./cripqer-billing-v1/billing.css";
import { PricingPlans } from "./cripqer-billing-v1/PricingPlans";
import { BillingCheckout } from "./cripqer-billing-v1/BillingCheckout";
import { BillingAccount } from "./cripqer-billing-v1/BillingAccount";
import { createHttpBillingClient, createMockBillingClient } from "./cripqer-billing-v1/billing.server-contract";

const server = import.meta.env.DEV
  ? createMockBillingClient({ outcome: "success" })
  : createHttpBillingClient();

<PricingPlans currentPlan={plan} onSelectPlan={(id, interval) => goToCheckout(id, interval)} />
<BillingCheckout planId={id} interval={interval} user={{ userId, email }} server={server} />
<BillingAccount server={server} onChangePlan={goToPricing} />
```

Host inputs expected (auth is **not** implemented here): `userId`, `email`,
optional `locale` / `country`, optional `currentPlan`.

## 5. Server integration points

Implement these endpoints in the receiving repository (names are in
`BILLING_ENDPOINTS`); the server owns all secrets and re-derives `userId` from
the session — never trust the `user` field in the request body.

| Endpoint | Body | Returns |
| --- | --- | --- |
| `POST /api/billing/checkout` | `CreateCheckoutRequest` | `CheckoutSession` |
| `GET /api/billing/checkout/:id` | — | `CheckoutSession` |
| `GET /api/billing/subscription` | — | `Subscription \| null` |
| `POST /api/billing/subscription/cancel` | `CancelRequest` | `Subscription` |
| `POST /api/billing/subscription/change-plan` | `ChangePlanRequest` | `Subscription` |
| `POST /api/billing/portal` | `{ provider }` | `{ portalUrl }` |
| `GET /api/billing/entitlements` | — | `EntitlementSnapshot` |

Provider calls the server must make:

- **Stripe** — create Checkout Session (mode `subscription`) or Subscription;
  retrieve subscription; update items for plan change; cancel
  (`cancel_at_period_end`); Billing Portal session.
- **Mercado Pago** — create `preapproval` from a `preapproval_plan`; retrieve;
  update status (`paused` / `cancelled`). No billing portal → `portalUrl: null`.
  Plan change is done by cancel + re-subscribe.
- **PayPal** — create subscription (`/v1/billing/subscriptions`), return the
  approval link; retrieve; `/revise` for plan change; `/cancel`.

## 6. Webhook endpoints

```
POST /api/public/billing/webhooks/stripe
POST /api/public/billing/webhooks/mercado-pago
POST /api/public/billing/webhooks/paypal
```

Rules enforced by `processWebhook`:

1. Verify the provider signature over the **raw** body (timing-safe compare)
   before parsing anything. Invalid → `401`.
2. Normalize to an internal event; unknown events → `202 ignored`.
3. Idempotency by provider `eventId`; duplicates → `200 duplicate_ignored`.
4. Only then persist and refresh entitlements.

Internal events: `SUBSCRIPTION_CREATED`, `SUBSCRIPTION_ACTIVATED`,
`SUBSCRIPTION_UPDATED`, `PAYMENT_SUCCEEDED`, `PAYMENT_FAILED`,
`SUBSCRIPTION_PAUSED`, `SUBSCRIPTION_CANCELLED`, `SUBSCRIPTION_EXPIRED`.

**The success page is never the source of truth for access.**

## 7. Provider account configuration

- **Stripe** — create Products + recurring Prices (monthly & yearly) per plan;
  copy price IDs into `stripePriceIds`; register the webhook endpoint and the
  events listed in `normalizeStripeEvent`; enable the Billing Portal.
- **Mercado Pago** — create `preapproval_plan` per plan/interval/currency;
  copy IDs into `mercadoPagoPlanIds`; configure the notification URL.
- **PayPal** — create Catalog Products + Billing Plans; copy IDs into
  `paypalPlanIds`; create a webhook and store its `PAYPAL_WEBHOOK_ID`.

Map provider plan IDs back to Cripqer `planId` when handling webhooks, using
the catalog as the lookup table.

## 8. Subscription data model (expected persistence fields)

`subscriptionId`, `userId`, `planId`, `provider`, `providerCustomerId`,
`providerSubscriptionId`, `billingInterval`, `currency`, `status`,
`currentPeriodStart`, `currentPeriodEnd`, `cancelAtPeriodEnd`,
`paymentMethodLabel`, `createdAt`, `updatedAt`.

Statuses: `free | pending | active | past_due | paused | cancelled | expired`.

Also persist processed webhook `eventId`s for idempotency.

## 9. Entitlement output contract

```ts
{
  userId: string,
  plan: "free" | "pro" | "business" | "enterprise",
  subscriptionStatus: SubscriptionStatus,
  validUntil: string | null,   // ISO-8601
  entitlements: string[]       // final list defined by the host
}
```

Billing only reports plan/status/validity. It does **not** gate Engine V2,
Quick Editor or Power Editor, and cancellation never deletes user content or
page configuration.

## 10. Sandbox testing

1. Use `createMockBillingClient({ outcome })` with `outcome` set to
   `"success" | "pending" | "failed" | "cancelled"` to exercise every state
   with no provider account and no network.
2. Then switch to `createHttpBillingClient()` with provider test credentials:
   Stripe test mode (card `4242 4242 4242 4242`), Mercado Pago sandbox users,
   PayPal sandbox buyer account.
3. Replay webhooks with `stripe trigger`, the Mercado Pago simulator and the
   PayPal webhook simulator; verify idempotency by delivering twice.

## 11. Production readiness checklist

- [ ] Real prices, currencies and provider IDs set in `billing.catalog.ts`.
- [ ] Policies reviewed: proration, downgrade timing, cancellation, refunds.
- [ ] All server endpoints implemented and authenticated.
- [ ] `userId` derived from the session server-side, never from the client.
- [ ] Webhook signature verification live for all three providers.
- [ ] Idempotency store persisted (not in-memory).
- [ ] Secrets stored server-side only; no secret in the client bundle.
- [ ] Entitlement refresh triggered by webhooks, not by success pages.
- [ ] Responsive QA re-run inside the host layout at 320 / 360 / 390 px.
- [ ] Tax/invoicing handled by the provider or by a separate system (out of scope).

## 12. Explicitly out of scope

Database implementation, auth, Supabase, Cripqer integration, Engine/Editor
changes, analytics, agency billing, tax engine, invoicing engine, coupons,
affiliates, usage-based billing, extra payment providers.


## 11. V1.1 hardening — authoritative flow (READ THIS FIRST)

```
Browser (request only)
  -> Cripqer server  (resolves price, currency, provider price ID, return URLs)
  -> provider        (hosted/tokenized secure checkout)
  -> provider return (carries NO authority)
  -> Cripqer server  GET /api/billing/checkout/:checkoutId   <-- the ONLY success signal
  -> verified webhook / authoritative provider resource
  -> subscription state
  -> entitlement resolver (host-owned, separate from billing)
```

A success URL, a query parameter, or the mere fact that the browser came back
from the provider **can never activate paid access**. `BillingCheckout` stores
the `checkoutId` in `sessionStorage` before redirecting and, on return, calls
`getCheckoutStatus(checkoutId)`; only the server-reported state is rendered.
`getSubscription()` is *not* a checkout confirmation.

### Server rules (host must implement all of them)

1. **Server-authoritative pricing** — resolve amount, currency and the provider
   price/plan ID from the server-side catalog. Ignore any amount/currency/price
   ID supplied by the browser; treat `planId`/`interval`/`provider` as requests.
2. **Return URLs** — build `successUrl`/`cancelUrl` server-side from the
   allowlisted `returnIntent` (`billing` | `pricing` | `dashboard`). Never
   forward an arbitrary browser-supplied URL to a provider.
3. **Ownership** — re-derive `userId` from the session and verify the session
   user owns `subscriptionId` before cancel / reactivate / change plan / portal
   / account-bound checkout creation.
4. **CSRF / Origin** — for cookie-authenticated mutations, validate
   `Origin`/`Referer` and a CSRF token (or use a bearer token instead).
5. **Webhook verification** — verify the signature over the RAW body with a
   timing-safe compare, before parsing JSON.
6. **Atomic, provider-scoped idempotency** — implement
   `IdempotencyStore.claim(provider, eventId)` (and `markProcessed(provider,
   eventId)` / `release(provider, eventId)`) as a single atomic reservation
   keyed by `UNIQUE (provider, event_id)`, e.g.
   `INSERT INTO billing_events(provider, event_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`
   inside a transaction, and treat `0 rows affected` as a duplicate no-op.
   Call `markProcessed` after a successful apply and `release` on failure so
   the provider can retry. A non-atomic `has()/remember()` pair is NOT
   acceptable: concurrent deliveries would both pass the check.
7. **Mercado Pago** — notifications are THIN. `intakeMercadoPagoNotification`
   returns a `lookup_required` instruction with the topic-derived resource type
   and resource ID; the server must fetch the authoritative
   preapproval / authorized payment / payment from the Mercado Pago API
   (`ProviderResourceFetcher`) and only then call
   `normalizeMercadoPagoResource`. Never trust status/plan/currency from the
   webhook body.
8. **PayPal** — subscription events (`BILLING.SUBSCRIPTION.*`) use
   `resource.id` as the subscription ID. Sale events (`PAYMENT.SALE.*`) do
   **not**: the subscription reference comes from `billing_agreement_id` or
   `supplementary_data.related_ids.subscription_id`, and when absent the event
   becomes `lookup_required`. `resource.id` of a sale is never stored as a
   subscription ID.
9. **Stripe** — invoice events (`invoice.paid`, `invoice.payment_succeeded`,
   `invoice.payment_failed`) are NOT subscription objects. The subscription
   reference is read from `subscription` /
   `parent.subscription_details.subscription` / line items. `in_...` is never
   stored as `providerSubscriptionId`.
10. **Dates** — all provider timestamps go through `safeIso()`, which returns
    `null` for anything unparseable and never throws.

### Subscription lifecycle

* **No active subscription** → `createCheckout()`.
* **Active subscription** → `changePlan()` after an explicit confirmation
  summary. A second `createCheckout()` for an active subscriber is a bug: it
  creates a duplicate paid subscription.
* **Cancel** → confirmation dialog showing the plan and the effective date;
  default is cancel-at-period-end (catalog policy `policies.cancellation`).
* **Reactivate** → available when `status === "active" && cancelAtPeriodEnd`
  and the provider declares `supportsReactivation`; hidden/disabled otherwise.
* Proration, downgrade timing, cancellation timing and refunds come from
  `catalog.policies` — never hard-coded in the UI.

## 12. Placeholders

All pricing, feature strings, limits, entitlements and provider IDs in
`billing.catalog.ts` are **demo placeholders**, not Cripqer product decisions.
The production Cripqer plan catalog replaces them wholesale during
integration. Billing reports authoritative plan/subscription state only; it
does not itself enable Engine V2, Power Editor or any capability — that is the
host's entitlement resolver.

## 13. V1.1 validation evidence

* TypeScript (strict, `noUncheckedIndexedAccess`, `noPropertyAccessFromIndexSignature`)
  on the 5 core `.ts` files: **0 errors**.
* TypeScript (strict, `react-jsx`, `@types/react`) on the 3 `.tsx` screens: **0 errors**.
* Behavioural suite (webhooks + mock server flows): **30/30 passed**, incl.
  Stripe `in_123 → sub_ABC`, PayPal sale ≠ subscription, Mercado Pago thin
  notification → lookup, `"not-a-date"` → no throw, parallel duplicate event →
  single apply, and checkout success/pending/failed/cancelled + change plan +
  cancel + reactivate.
* Security scan: no raw card fields, no CVV/PAN handling, no secret keys.


## V1.1.1 corrections

- **PayPal resource-aware lookup** — `normalizeAuthoritativeResource` detects
  whether the fetched PayPal resource is a Subscription or a Sale/Payment. A
  Sale id (`resource.id`, e.g. `SALE-123`) is NEVER used as
  `providerSubscriptionId`; the subscription reference comes from
  `billing_agreement_id` or `supplementary_data.related_ids.subscription_id`,
  and the sale always chains to an authoritative subscription lookup
  (`nextAuthoritativeLookup`). With no reference, the event stays unresolved.
- **Hard lookup gate** — `processWebhook` resolves lookups iteratively and
  never calls `apply()` while `requiresAuthoritativeLookup` is `true`. When it
  cannot be resolved it returns `202 authoritative_lookup_unresolved` with no
  persistence and no fabricated subscription id.
- **Provider-scoped idempotency** — claims are keyed by `(provider, eventId)`,
  so `stripe:123` and `paypal:123` are distinct events while two concurrent
  `stripe:123` deliveries still apply exactly once.
- **Same-plan interval change** — a selection is the current subscription only
  when `planId` AND `billingInterval` match. Pro monthly -> Pro yearly (and the
  reverse) routes through `changePlan()`; a second subscription is never
  created just to switch billing cycle. `PricingPlans` accepts an optional
  `currentInterval` prop for the same rule.
