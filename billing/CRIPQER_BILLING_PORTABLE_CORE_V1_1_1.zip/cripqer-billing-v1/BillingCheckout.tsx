/**
 * CRIPQER BILLING V1.1 — checkout screen.
 *
 * Plan summary -> provider selection -> provider-secure payment -> RETURN FLOW.
 *
 * SECURITY / CORRECTNESS RULES
 *  - This component NEVER renders card inputs and never touches card data.
 *  - A browser return (or any URL query parameter) NEVER activates paid state.
 *    The only success signal is server.getCheckoutStatus(checkoutId).
 *  - Users with an ACTIVE subscription go through changePlan(), never through
 *    a second createCheckout() — that would create a duplicate paid sub.
 *  - Amounts, currencies, provider price IDs and return URLs are resolved by
 *    the SERVER; the values shown here are display-only catalog placeholders.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  BILLING_CATALOG,
  formatPrice,
  getPlan,
  getPrice,
  isCheckoutAvailable,
} from "./billing.catalog";
import { createProviderAdapter, listProviders } from "./billing.providers";
import type { BillingServerClient, ReturnIntent } from "./billing.server-contract";
import type {
  BillingCatalog,
  BillingInterval,
  CheckoutState,
  HostUser,
  PlanId,
  ProviderId,
  Subscription,
} from "./billing.types";

/** Survives the provider redirect; cleared once a terminal state is confirmed. */
const PENDING_KEY = "cq_billing_pending_checkout";

function readPendingCheckoutId(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage.getItem(PENDING_KEY);
  } catch {
    return null;
  }
}
function writePendingCheckoutId(id: string | null) {
  if (typeof window === "undefined") return;
  try {
    if (id) window.sessionStorage.setItem(PENDING_KEY, id);
    else window.sessionStorage.removeItem(PENDING_KEY);
  } catch {
    /* storage unavailable — the flow still works, only the auto-resume is lost */
  }
}

export interface BillingCheckoutProps {
  planId: PlanId;
  interval: BillingInterval;
  user: HostUser;
  server: BillingServerClient;
  catalog?: BillingCatalog;
  locale?: string;
  /** Logical destination; the SERVER builds the real success/cancel URLs. */
  returnIntent?: ReturnIntent;
  /** Current subscription, when the host already loaded it. */
  activeSubscription?: Subscription | null;
  onBack?: () => void;
  /** Fired when the flow reaches a terminal state (server-confirmed only). */
  onStateChange?: (state: CheckoutState) => void;
  onDone?: () => void;
}

const ACTIVE_STATUSES = ["active", "past_due", "paused"];

export function BillingCheckout({
  planId,
  interval,
  user,
  server,
  catalog = BILLING_CATALOG,
  locale = "es-CL",
  returnIntent = "billing",
  activeSubscription = null,
  onBack,
  onStateChange,
  onDone,
}: BillingCheckoutProps) {
  const plan = getPlan(planId, catalog);
  const providers = useMemo(
    () => listProviders(catalog.enabledProviders),
    [catalog.enabledProviders],
  );
  const [provider, setProvider] = useState<ProviderId | null>(providers[0]?.id ?? null);
  const [state, setState] = useState<CheckoutState>("idle");
  const [message, setMessage] = useState<string | null>(null);
  const [confirmChange, setConfirmChange] = useState(false);
  const resumed = useRef(false);

  const isPlanChange =
    Boolean(activeSubscription) && ACTIVE_STATUSES.includes(activeSubscription!.status);

  const setPhase = useCallback(
    (next: CheckoutState, msg?: string | null) => {
      setState(next);
      setMessage(msg ?? null);
      onStateChange?.(next);
    },
    [onStateChange],
  );

  /** Authoritative confirmation — the ONLY way this UI reports success. */
  const confirmCheckout = useCallback(
    async (checkoutId: string) => {
      setPhase("processing", "Confirmando el pago con el proveedor…");
      try {
        const session = await server.getCheckoutStatus(checkoutId);
        if (session.status === "processing" || session.status === "redirecting") {
          setPhase("pending", session.message ?? "El proveedor aún está procesando el cobro.");
          return;
        }
        writePendingCheckoutId(session.status === "pending" ? checkoutId : null);
        setPhase(session.status, session.message ?? null);
      } catch (err) {
        writePendingCheckoutId(checkoutId);
        setPhase(
          "pending",
          err instanceof Error
            ? `No pudimos confirmar el pago todavía: ${err.message}`
            : "No pudimos confirmar el pago todavía.",
        );
      }
    },
    [server, setPhase],
  );

  /** Return flow: resume the pending checkout after the provider redirect. */
  useEffect(() => {
    if (resumed.current) return;
    resumed.current = true;
    const pendingId = readPendingCheckoutId();
    if (pendingId) void confirmCheckout(pendingId);
  }, [confirmCheckout]);

  if (!plan) {
    return (
      <section className="cq-billing">
        <p className="cq-note cq-note--error">Plan no disponible.</p>
      </section>
    );
  }

  const price = getPrice(plan, interval);

  async function startCheckout() {
    if (!provider || !plan) return;
    setPhase("processing");
    try {
      const adapter = createProviderAdapter(provider, server);
      // The server resolves price, currency, provider price ID and return URLs.
      const session = await adapter.createCheckout({
        planId: plan.id,
        interval,
        provider,
        currency: plan.currency,
        user,
        returnIntent,
      });

      writePendingCheckoutId(session.checkoutId);

      const handled = await adapter.handleCheckoutSession(session);
      if (handled.status === "redirecting") {
        setPhase("redirecting", "Te estamos llevando al pago seguro del proveedor…");
        return; // the page unloads; the return flow confirms on the way back
      }
      // No redirect (embedded flow): confirm against the server, never locally.
      await confirmCheckout(session.checkoutId);
    } catch (err) {
      writePendingCheckoutId(null);
      setPhase("failed", err instanceof Error ? err.message : "No se pudo iniciar el pago.");
    }
  }

  /** Existing paid subscriber: mutate the subscription, do NOT buy a second one. */
  async function applyPlanChange() {
    if (!activeSubscription || !plan) return;
    setPhase("processing", "Aplicando el cambio de plan…");
    try {
      await server.changePlan({
        subscriptionId: activeSubscription.subscriptionId,
        planId: plan.id,
        interval,
      });
      setPhase("success", "Tu plan fue actualizado.");
    } catch (err) {
      setPhase("failed", err instanceof Error ? err.message : "No se pudo cambiar el plan.");
    }
  }

  if (state === "success" || state === "pending" || state === "failed" || state === "cancelled") {
    return (
      <section className="cq-billing" aria-live="polite">
        <ResultState
          state={state}
          message={message}
          onRetry={() => {
            writePendingCheckoutId(null);
            setPhase("idle");
          }}
          onRefresh={
            state === "pending"
              ? () => {
                  const id = readPendingCheckoutId();
                  if (id) void confirmCheckout(id);
                }
              : undefined
          }
          onDone={onDone}
        />
      </section>
    );
  }

  const busy = state === "processing" || state === "redirecting";
  const currentPlan = activeSubscription ? getPlan(activeSubscription.planId, catalog) : null;

  return (
    <section className="cq-billing" aria-labelledby="cq-checkout-title">
      {onBack ? (
        <button type="button" className="cq-back" onClick={onBack}>
          ← Volver a planes
        </button>
      ) : null}

      <h1 className="cq-h1" id="cq-checkout-title">
        {isPlanChange ? "Cambiar de plan" : "Confirmar suscripción"}
      </h1>
      <p className="cq-sub">
        {isPlanChange
          ? "Actualizamos tu suscripción existente, sin crear un segundo cobro."
          : "Revisa tu plan y elige cómo quieres pagar."}
      </p>

      <div className="cq-summary">
        {isPlanChange && currentPlan ? (
          <div className="cq-row">
            <span>Plan actual</span>
            <span>{currentPlan.name}</span>
          </div>
        ) : null}
        <div className="cq-row">
          <span>{isPlanChange ? "Nuevo plan" : "Plan"}</span>
          <span>{plan.name}</span>
        </div>
        <div className="cq-row">
          <span>Ciclo</span>
          <span>{interval === "yearly" ? "Anual" : "Mensual"}</span>
        </div>
        <div className="cq-row">
          <span>Moneda</span>
          <span>{plan.currency}</span>
        </div>
        <div className="cq-row cq-row--total">
          <span>{isPlanChange ? "Precio de referencia" : "Total hoy"}</span>
          <span>{formatPrice(price, plan.currency, locale)}</span>
        </div>
      </div>
      <p className="cq-muted cq-fineprint">
        Precio referencial del catálogo (demo). El monto final lo calcula y cobra el servidor
        según el catálogo autoritativo y la política de prorrateo configurada.
      </p>

      {isPlanChange ? (
        <>
          <p className="cq-note cq-note--warn">
            Prorrateo: <strong>{catalog.policies.proration}</strong> · Bajada de plan efectiva:{" "}
            <strong>{catalog.policies.downgradeEffective}</strong> · Reembolsos:{" "}
            <strong>{catalog.policies.refunds}</strong>. Políticas configurables en el catálogo.
          </p>
          {busy ? (
            <div className="cq-state" aria-live="polite">
              <div className="cq-spinner" aria-hidden="true" />
              <p className="cq-muted">Procesando…</p>
            </div>
          ) : null}
          {!confirmChange ? (
            <button
              type="button"
              className="cq-btn cq-btn--primary"
              onClick={() => setConfirmChange(true)}
              disabled={
                busy ||
                (activeSubscription!.planId === plan.id &&
                  activeSubscription!.billingInterval === interval)
              }
            >
              Continuar con el cambio
            </button>
          ) : (
            <div className="cq-confirm" role="group" aria-label="Confirmar cambio de plan">
              <p className="cq-muted">
                ¿Confirmas cambiar de {currentPlan?.name ?? "tu plan actual"} a {plan.name}?
              </p>
              <div className="cq-actions">
                <button type="button" className="cq-btn" onClick={() => setConfirmChange(false)}>
                  Volver
                </button>
                <button
                  type="button"
                  className="cq-btn cq-btn--primary"
                  onClick={applyPlanChange}
                  disabled={busy}
                >
                  Confirmar cambio
                </button>
              </div>
            </div>
          )}
        </>
      ) : (
        <>
          <h2 className="cq-h2">Método de pago</h2>
          <p className="cq-muted" style={{ marginBottom: 12 }}>
            El pago se completa en la interfaz segura del proveedor. Cripqer no recibe ni
            almacena datos de tarjeta.
          </p>

          <div className="cq-methods" role="radiogroup" aria-label="Método de pago">
            {providers.map((p) => {
              const available = isCheckoutAvailable(plan, p.id, interval, catalog);
              return (
                <button
                  key={p.id}
                  type="button"
                  role="radio"
                  aria-checked={provider === p.id}
                  className="cq-method"
                  disabled={!available || busy}
                  onClick={() => setProvider(p.id)}
                >
                  <span className="cq-method-dot" aria-hidden="true" />
                  <span>
                    <strong>{p.label}</strong>
                    <br />
                    <span className="cq-muted">
                      {available ? p.description : "No disponible para este plan o ciclo."}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>

          {busy ? (
            <div className="cq-state" aria-live="polite">
              <div className="cq-spinner" aria-hidden="true" />
              <p className="cq-muted">
                {state === "redirecting" ? "Redirigiendo al proveedor…" : "Procesando…"}
              </p>
            </div>
          ) : null}

          <button
            type="button"
            className="cq-btn cq-btn--primary"
            onClick={startCheckout}
            disabled={!provider || busy || !isCheckoutAvailable(plan, provider!, interval, catalog)}
          >
            Ir al pago seguro
          </button>
        </>
      )}
    </section>
  );
}

function ResultState({
  state,
  message,
  onRetry,
  onRefresh,
  onDone,
}: {
  state: CheckoutState;
  message: string | null;
  onRetry: () => void;
  onRefresh?: () => void;
  onDone?: () => void;
}) {
  const copy: Record<string, { icon: string; title: string; body: string }> = {
    success: {
      icon: "✓",
      title: "Pago confirmado",
      body: "El servidor confirmó el cobro. Tu suscripción queda activa según el estado reportado por el proveedor.",
    },
    pending: {
      icon: "⏳",
      title: "Pago en revisión",
      body: "El proveedor aún está procesando el cobro. Te avisaremos al confirmarse.",
    },
    failed: {
      icon: "✕",
      title: "El pago no se completó",
      body: "No se realizó ningún cobro. Puedes intentarlo otra vez o usar otro método.",
    },
    cancelled: {
      icon: "—",
      title: "Pago cancelado",
      body: "Cancelaste el proceso. Tu plan actual no cambió.",
    },
  };
  const c = copy[state] ?? copy["failed"]!;

  return (
    <div className="cq-state">
      <div className="cq-state-icon" aria-hidden="true">
        {c.icon}
      </div>
      <h1 className="cq-h1">{c.title}</h1>
      <p className="cq-sub">{message ?? c.body}</p>
      <div className="cq-actions" style={{ justifyContent: "center" }}>
        {onRefresh ? (
          <button type="button" className="cq-btn" onClick={onRefresh}>
            Actualizar estado
          </button>
        ) : null}
        {state !== "success" && state !== "pending" ? (
          <button type="button" className="cq-btn" onClick={onRetry}>
            Intentar de nuevo
          </button>
        ) : null}
        {onDone ? (
          <button type="button" className="cq-btn cq-btn--primary" onClick={onDone}>
            Ir a mi facturación
          </button>
        ) : null}
      </div>
    </div>
  );
}

export default BillingCheckout;
