/**
 * CRIPQER BILLING V1 — provider abstraction.
 *
 * All provider differences live here. UI components never branch on provider
 * business logic; they only read metadata and call the adapter interface.
 *
 * SECURITY: adapters run in the browser and MUST NOT hold secret keys.
 * Card data is always collected by the provider's own hosted/tokenized UI.
 */

import type {
  BillingInterval,
  CheckoutSession,
  EntitlementSnapshot,
  PlanId,
  ProviderId,
  Subscription,
} from "./billing.types";
import type {
  BillingServerClient,
  CreateCheckoutRequest,
  ManageBillingResponse,
} from "./billing.server-contract";

/* ------------------------------- metadata --------------------------------- */

export interface ProviderMeta {
  id: ProviderId;
  label: string;
  /** Short, factual description. No marketing claims. */
  description: string;
  /** How the payment UI is presented to the user. */
  uiMode: "hosted_redirect" | "embedded_element" | "approval_redirect";
  supportsYearly: boolean;
  supportsPlanChange: boolean;
  supportsPause: boolean;
  supportsBillingPortal: boolean;
  /** Whether a scheduled cancellation can be undone with this provider. */
  supportsReactivation: boolean;
  /** Public browser identifier env var name (never a secret). */
  publicKeyEnvVar: string;
  /** Official SDK/script needed on the client, if any. */
  clientDependency: string | null;
}

export const PROVIDER_META: Record<ProviderId, ProviderMeta> = {
  stripe: {
    id: "stripe",
    label: "Tarjeta de crédito o débito",
    description: "Pago seguro procesado por Stripe.",
    uiMode: "hosted_redirect",
    supportsYearly: true,
    supportsPlanChange: true,
    supportsPause: true,
    supportsBillingPortal: true,
    supportsReactivation: true,
    publicKeyEnvVar: "VITE_STRIPE_PUBLISHABLE_KEY",
    clientDependency: "@stripe/stripe-js",
  },
  mercado_pago: {
    id: "mercado_pago",
    label: "Mercado Pago",
    description: "Tarjetas locales y saldo de Mercado Pago.",
    uiMode: "hosted_redirect",
    supportsYearly: true,
    supportsPlanChange: false,
    supportsPause: true,
    supportsBillingPortal: false,
    supportsReactivation: false,
    publicKeyEnvVar: "VITE_MERCADOPAGO_PUBLIC_KEY",
    clientDependency: "@mercadopago/sdk-react",
  },
  paypal: {
    id: "paypal",
    label: "PayPal",
    description: "Aprobación de suscripción en PayPal.",
    uiMode: "approval_redirect",
    supportsYearly: true,
    supportsPlanChange: true,
    supportsPause: true,
    supportsBillingPortal: false,
    supportsReactivation: true,
    publicKeyEnvVar: "VITE_PAYPAL_CLIENT_ID",
    clientDependency: "@paypal/react-paypal-js",
  },
};

/* -------------------------------- adapter --------------------------------- */

export interface ProviderAdapter {
  readonly meta: ProviderMeta;
  createCheckout(req: CreateCheckoutRequest): Promise<CheckoutSession>;
  /** Authoritative confirmation of a checkout; the only valid success signal. */
  getCheckoutStatus(checkoutId: string): Promise<CheckoutSession>;
  getSubscription(): Promise<Subscription | null>;
  cancelSubscription(subscriptionId: string, atPeriodEnd?: boolean): Promise<Subscription>;
  /** Undoes a scheduled cancellation when the provider supports it. */
  reactivateSubscription(subscriptionId: string): Promise<Subscription>;
  changePlan(
    subscriptionId: string,
    planId: PlanId,
    interval: BillingInterval,
  ): Promise<Subscription>;
  manageBilling(): Promise<ManageBillingResponse>;
  getEntitlements(): Promise<EntitlementSnapshot>;
  /**
   * Hands control to the provider's secure UI.
   * Returns the session unchanged for embedded flows (host mounts the element).
   */
  handleCheckoutSession(session: CheckoutSession): Promise<CheckoutSession>;
}

/**
 * Single generic adapter: every provider call goes through the host server,
 * which owns the secrets. Only the hand-off to the provider UI differs.
 */
export function createProviderAdapter(
  provider: ProviderId,
  server: BillingServerClient,
  navigate: (url: string) => void = (url) => {
    if (typeof window !== "undefined") window.location.assign(url);
  },
): ProviderAdapter {
  const meta = PROVIDER_META[provider];
  return {
    meta,
    createCheckout: (req) => server.createCheckout({ ...req, provider }),
    getCheckoutStatus: (checkoutId) => server.getCheckoutStatus(checkoutId),
    getSubscription: () => server.getSubscription(),
    cancelSubscription: (subscriptionId, atPeriodEnd) =>
      server.cancelSubscription({ subscriptionId, atPeriodEnd }),
    reactivateSubscription: (subscriptionId) =>
      server.reactivateSubscription({ subscriptionId }),
    changePlan: (subscriptionId, planId, interval) =>
      server.changePlan({ subscriptionId, planId, interval }),
    manageBilling: () => server.manageBilling(provider),
    getEntitlements: () => server.getEntitlements(),
    async handleCheckoutSession(session) {
      if (session.redirectUrl) {
        navigate(session.redirectUrl);
        return { ...session, status: "redirecting" };
      }
      return session;
    },
  };
}

export function listProviders(enabled: ProviderId[]): ProviderMeta[] {
  return enabled.map((id) => PROVIDER_META[id]).filter(Boolean);
}
