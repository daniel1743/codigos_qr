/**
 * CRIPQER BILLING V1 — normalized domain types.
 * Portable, dependency-free. No auth, no DB, no provider SDK types here.
 */

/* ---------------------------------- ids ---------------------------------- */

export type PlanId = "free" | "pro" | "business" | "enterprise";
/** Reserved, not active in V1. */
export type FuturePlanId = "agency";

export type ProviderId = "stripe" | "mercado_pago" | "paypal";

export type BillingInterval = "monthly" | "yearly";

/** ISO-4217 code, e.g. "USD", "CLP", "BRL", "MXN". Never converted client-side. */
export type CurrencyCode = string;

/* --------------------------------- catalog -------------------------------- */

export interface PlanLimits {
  /** null = unlimited / not enforced by billing. */
  [key: string]: number | null;
}

export interface PlanProviderIds {
  /** Provider price/plan identifiers keyed by interval. */
  monthly?: string | null;
  yearly?: string | null;
}

export interface PlanDefinition {
  id: PlanId;
  name: string;
  description: string;
  /** Minor units (cents). 0 for free plans, null when price is "contact sales". */
  monthlyPrice: number | null;
  yearlyPrice: number | null;
  currency: CurrencyCode;
  badge: string | null;
  features: string[];
  limits: PlanLimits;
  recommended: boolean;
  /** false => the CTA does not open checkout (free plan / contact sales). */
  checkoutEnabled: boolean;
  contactSales: boolean;
  ctaLabel: string;
  stripePriceIds: PlanProviderIds;
  paypalPlanIds: PlanProviderIds;
  mercadoPagoPlanIds: PlanProviderIds;
}

export interface BillingCatalog {
  version: string;
  defaultCurrency: CurrencyCode;
  defaultInterval: BillingInterval;
  /** Provider order shown in checkout; also acts as the enabled-provider list. */
  enabledProviders: ProviderId[];
  plans: PlanDefinition[];
  policies: BillingPolicies;
}

/** Centralized, configurable — never hard-coded inside UI. */
export interface BillingPolicies {
  /** How an upgrade is charged mid-period. */
  proration: "provider_default" | "immediate" | "none";
  /** When a downgrade takes effect. */
  downgradeEffective: "period_end" | "immediate";
  /** Cancellation behaviour requested to the provider. */
  cancellation: "at_period_end" | "immediate";
  refunds: "manual_review" | "none";
  /** Enterprise may be flipped to self-serve checkout without code changes. */
  enterpriseDirectCheckout: boolean;
  /** Yearly discount is derived from catalog prices, never invented in UI. */
  showYearlySavings: boolean;
}

/* ------------------------------ subscription ------------------------------ */

export type SubscriptionStatus =
  | "free"
  | "pending"
  | "active"
  | "past_due"
  | "paused"
  | "cancelled"
  | "expired";

export interface Subscription {
  subscriptionId: string;
  userId: string;
  planId: PlanId;
  provider: ProviderId | null;
  providerCustomerId: string | null;
  providerSubscriptionId: string | null;
  billingInterval: BillingInterval;
  currency: CurrencyCode;
  status: SubscriptionStatus;
  /** ISO-8601 strings, or null when the provider does not supply them. */
  currentPeriodStart: string | null;
  currentPeriodEnd: string | null;
  cancelAtPeriodEnd: boolean;
  /** Provider-supplied safe descriptor only (e.g. "Visa •••• 4242"). */
  paymentMethodLabel: string | null;
  createdAt: string;
  updatedAt: string;
}

/* ------------------------------ entitlements ------------------------------ */

export interface EntitlementSnapshot {
  userId: string;
  plan: PlanId;
  subscriptionStatus: SubscriptionStatus;
  /** ISO-8601 end of paid access, null for free/expired. */
  validUntil: string | null;
  /** Opaque strings; final list is defined by the host, not by billing. */
  entitlements: string[];
}

/* -------------------------------- checkout -------------------------------- */

export type CheckoutState =
  | "idle"
  | "processing"
  | "redirecting"
  | "pending"
  | "success"
  | "failed"
  | "cancelled";

export interface HostUser {
  userId: string;
  email?: string;
  locale?: string;
  country?: string;
  currentPlan?: PlanId;
}

export interface CheckoutSelection {
  planId: PlanId;
  interval: BillingInterval;
  provider: ProviderId;
  currency: CurrencyCode;
}

/** Provider-agnostic result of a server-created checkout. */
export interface CheckoutSession {
  /** Server-generated id used to poll status. */
  checkoutId: string;
  provider: ProviderId;
  /** Redirect/approval URL for hosted or approval-based flows. */
  redirectUrl?: string | null;
  /** Client-side secret/token for embedded provider elements (public by design). */
  clientToken?: string | null;
  status: CheckoutState;
  message?: string | null;
}

export interface BillingError {
  code: string;
  message: string;
  /** true when the same action can be retried unchanged. */
  retryable: boolean;
}
