/**
 * CRIPQER BILLING V1.1 — webhook normalization contract (SERVER-SIDE ONLY).
 *
 * Import this file from server code only. It performs no network calls and
 * contains no secrets; signature verification and authoritative provider
 * lookups are delegated to the host, which holds the provider credentials.
 *
 * RULE: payment success pages are NOT the source of truth. Access is granted
 * only after a verified provider event (or an authoritative provider resource
 * fetched by the server) is normalized and persisted.
 */

import type { BillingInterval, ProviderId, SubscriptionStatus } from "./billing.types";

export type BillingEventType =
  | "SUBSCRIPTION_CREATED"
  | "SUBSCRIPTION_ACTIVATED"
  | "SUBSCRIPTION_UPDATED"
  | "PAYMENT_SUCCEEDED"
  | "PAYMENT_FAILED"
  | "PAYMENT_REFUNDED"
  | "SUBSCRIPTION_PAUSED"
  | "SUBSCRIPTION_CANCELLED"
  | "SUBSCRIPTION_EXPIRED";

export interface NormalizedBillingEvent {
  /** Provider event id — the idempotency key. */
  eventId: string;
  provider: ProviderId;
  type: BillingEventType;
  occurredAt: string;
  providerCustomerId: string | null;
  /** ALWAYS a subscription reference, never an invoice/sale/payment id. */
  providerSubscriptionId: string | null;
  /** Provider price/plan id; map to a Cripqer planId via the catalog. */
  providerPlanId: string | null;
  billingInterval: BillingInterval | null;
  currency: string | null;
  status: SubscriptionStatus | null;
  currentPeriodStart: string | null;
  currentPeriodEnd: string | null;
  cancelAtPeriodEnd: boolean | null;
  /**
   * true when the subscription reference could not be derived from the event
   * payload alone and the host MUST resolve it through an authoritative
   * provider API lookup before persisting state.
   */
  requiresAuthoritativeLookup: boolean;
  /** Original event, kept for audit. Never contains card numbers. */
  raw: unknown;
}

/** Resource kinds a provider notification can point at. */
export type ProviderResourceType =
  | "subscription"
  | "preapproval"
  | "authorized_payment"
  | "payment"
  | "invoice"
  | "sale"
  | "unknown";

/**
 * Emitted when the notification is "thin" (Mercado Pago) or points at a
 * non-subscription resource (PayPal sale). The host MUST fetch the
 * authoritative resource from the provider API before normalizing.
 */
export interface WebhookLookupInstruction {
  eventId: string;
  provider: ProviderId;
  resourceType: ProviderResourceType;
  resourceId: string | null;
  occurredAt: string;
  raw: unknown;
}

export type WebhookIntake =
  | { kind: "normalized"; event: NormalizedBillingEvent }
  | { kind: "lookup_required"; lookup: WebhookLookupInstruction }
  | { kind: "ignored"; reason: string };

/* ---------------------------- verification API ---------------------------- */

/**
 * The host implements one verifier per provider using its server secrets.
 * It MUST verify over the RAW request body and use a timing-safe compare.
 *
 *  stripe        -> Stripe-Signature header + STRIPE_WEBHOOK_SECRET
 *  mercado_pago  -> x-signature / x-request-id + MERCADOPAGO_WEBHOOK_SECRET
 *  paypal        -> transmission headers verified against PAYPAL_WEBHOOK_ID
 */
export interface WebhookVerifier {
  verify(rawBody: string, headers: Record<string, string>): Promise<boolean> | boolean;
}

/**
 * ATOMIC idempotency contract.
 *
 * `claim` MUST be a single atomic reservation (e.g. INSERT ... ON CONFLICT DO
 * NOTHING on a UNIQUE (provider, event_id) column, inside a transaction).
 * A non-atomic has()/remember() pair is NOT acceptable in production: two
 * concurrent deliveries of the same event would both pass the check.
 *
 *  claim  -> true  = this worker owns the event, proceed
 *  claim  -> false = already claimed/processed, return a no-op
 */
export interface IdempotencyStore {
  /** Scoped by (provider, eventId): two providers may reuse the same id. */
  claim(provider: ProviderId, eventId: string): Promise<boolean>;
  /** Called after apply() succeeds. */
  markProcessed(provider: ProviderId, eventId: string): Promise<void>;
  /** Called when apply() throws, so the event can be retried by the provider. */
  release(provider: ProviderId, eventId: string): Promise<void>;
}

/**
 * Authoritative provider resource lookup. Implemented by the host with the
 * provider's server credentials. Returns the raw provider resource.
 */
export interface ProviderResourceFetcher {
  fetchResource(
    provider: ProviderId,
    resourceType: ProviderResourceType,
    resourceId: string,
  ): Promise<unknown>;
}

/* ------------------------------ status maps ------------------------------- */

const STRIPE_SUBSCRIPTION_STATUS: Record<string, SubscriptionStatus> = {
  trialing: "active",
  active: "active",
  past_due: "past_due",
  unpaid: "past_due",
  paused: "paused",
  canceled: "cancelled",
  incomplete: "pending",
  incomplete_expired: "expired",
};

const MP_STATUS: Record<string, SubscriptionStatus> = {
  pending: "pending",
  authorized: "active",
  paused: "paused",
  cancelled: "cancelled",
  finished: "expired",
};

const PAYPAL_STATUS: Record<string, SubscriptionStatus> = {
  APPROVAL_PENDING: "pending",
  APPROVED: "pending",
  ACTIVE: "active",
  SUSPENDED: "paused",
  CANCELLED: "cancelled",
  EXPIRED: "expired",
};

/* -------------------------------- helpers --------------------------------- */

/** Safe ISO parser: never throws, returns null for anything unparseable. */
export function safeIso(value: unknown): string | null {
  if (value === null || value === undefined) return null;
  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? null : value.toISOString();
  }
  if (typeof value === "number") {
    // Provider unix seconds (Stripe) or milliseconds.
    if (!Number.isFinite(value)) return null;
    const ms = Math.abs(value) < 1e11 ? value * 1000 : value;
    const d = new Date(ms);
    return Number.isNaN(d.getTime()) ? null : d.toISOString();
  }
  if (typeof value !== "string" || value.trim() === "") return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

const str = (v: unknown): string | null =>
  typeof v === "string" && v !== "" ? v : typeof v === "number" ? String(v) : null;

const get = (o: unknown, path: string): unknown =>
  path.split(".").reduce<unknown>((acc, k) => (acc as Record<string, unknown>)?.[k], o);

/* ------------------------------- Stripe ----------------------------------- */

const STRIPE_SUBSCRIPTION_EVENTS: Record<string, BillingEventType> = {
  "customer.subscription.created": "SUBSCRIPTION_CREATED",
  "customer.subscription.updated": "SUBSCRIPTION_UPDATED",
  "customer.subscription.deleted": "SUBSCRIPTION_CANCELLED",
  "customer.subscription.paused": "SUBSCRIPTION_PAUSED",
  "customer.subscription.resumed": "SUBSCRIPTION_UPDATED",
};

const STRIPE_INVOICE_EVENTS: Record<string, BillingEventType> = {
  "invoice.paid": "PAYMENT_SUCCEEDED",
  "invoice.payment_succeeded": "PAYMENT_SUCCEEDED",
  "invoice.payment_failed": "PAYMENT_FAILED",
};

/** Stripe puts the subscription reference in different places per object type. */
function stripeSubscriptionRefFromInvoice(invoice: unknown): string | null {
  return (
    str(get(invoice, "subscription")) ??
    str(get(invoice, "subscription_details.subscription")) ??
    str(get(invoice, "parent.subscription_details.subscription")) ??
    str(get(invoice, "lines.data.0.subscription")) ??
    str(get(invoice, "lines.data.0.parent.subscription_item_details.subscription")) ??
    null
  );
}

export function normalizeStripeEvent(event: unknown): NormalizedBillingEvent | null {
  const type = String(get(event, "type") ?? "");
  const obj = get(event, "data.object");
  const eventId = str(get(event, "id")) ?? "";
  const occurredAt = safeIso(get(event, "created")) ?? new Date().toISOString();

  // --- Subscription objects -------------------------------------------------
  const subEvent = STRIPE_SUBSCRIPTION_EVENTS[type];
  if (subEvent) {
    return {
      eventId,
      provider: "stripe",
      type: subEvent,
      occurredAt,
      providerCustomerId: str(get(obj, "customer")),
      providerSubscriptionId: str(get(obj, "id")),
      providerPlanId: str(get(obj, "items.data.0.price.id")),
      billingInterval:
        get(obj, "items.data.0.price.recurring.interval") === "year" ? "yearly" : "monthly",
      currency: (str(get(obj, "currency")) ?? "").toUpperCase() || null,
      status: STRIPE_SUBSCRIPTION_STATUS[String(get(obj, "status") ?? "")] ?? null,
      currentPeriodStart:
        safeIso(get(obj, "current_period_start")) ??
        safeIso(get(obj, "items.data.0.current_period_start")),
      currentPeriodEnd:
        safeIso(get(obj, "current_period_end")) ??
        safeIso(get(obj, "items.data.0.current_period_end")),
      cancelAtPeriodEnd:
        typeof get(obj, "cancel_at_period_end") === "boolean"
          ? (get(obj, "cancel_at_period_end") as boolean)
          : null,
      requiresAuthoritativeLookup: false,
      raw: event,
    };
  }

  // --- Invoice objects ------------------------------------------------------
  const invEvent = STRIPE_INVOICE_EVENTS[type];
  if (invEvent) {
    const subscriptionId = stripeSubscriptionRefFromInvoice(obj);
    return {
      eventId,
      provider: "stripe",
      type: invEvent,
      occurredAt,
      providerCustomerId: str(get(obj, "customer")),
      // NEVER the invoice id.
      providerSubscriptionId: subscriptionId,
      providerPlanId: str(get(obj, "lines.data.0.price.id")),
      billingInterval:
        get(obj, "lines.data.0.price.recurring.interval") === "year" ? "yearly" : "monthly",
      currency: (str(get(obj, "currency")) ?? "").toUpperCase() || null,
      // An invoice carries no subscription status; the host must read it from
      // the subscription object or a subsequent subscription event.
      status: null,
      currentPeriodStart: safeIso(get(obj, "lines.data.0.period.start")),
      currentPeriodEnd: safeIso(get(obj, "lines.data.0.period.end")),
      cancelAtPeriodEnd: null,
      requiresAuthoritativeLookup: subscriptionId === null,
      raw: event,
    };
  }

  // --- Checkout session -----------------------------------------------------
  if (type === "checkout.session.completed") {
    const subscriptionId = str(get(obj, "subscription"));
    return {
      eventId,
      provider: "stripe",
      type: "SUBSCRIPTION_ACTIVATED",
      occurredAt,
      providerCustomerId: str(get(obj, "customer")),
      providerSubscriptionId: subscriptionId,
      providerPlanId: null,
      billingInterval: null,
      currency: (str(get(obj, "currency")) ?? "").toUpperCase() || null,
      status: get(obj, "payment_status") === "paid" ? "active" : "pending",
      currentPeriodStart: null,
      currentPeriodEnd: null,
      cancelAtPeriodEnd: null,
      requiresAuthoritativeLookup: subscriptionId === null,
      raw: event,
    };
  }

  return null;
}

/* ----------------------------- Mercado Pago -------------------------------- */

/**
 * Mercado Pago notifications are THIN: they carry a topic and a resource id,
 * not a complete subscription. Never trust status/plan/currency from the body.
 */
export function intakeMercadoPagoNotification(event: unknown): WebhookIntake {
  const topic = String(get(event, "type") ?? get(event, "topic") ?? "");
  const action = String(get(event, "action") ?? "");
  const resourceId =
    str(get(event, "data.id")) ?? str(get(event, "resource")) ?? str(get(event, "id"));
  const eventId =
    str(get(event, "id")) ?? (resourceId ? `${topic}:${action}:${resourceId}` : "");

  const resourceType: ProviderResourceType =
    topic.includes("preapproval_plan")
      ? "unknown"
      : topic.includes("preapproval") || topic.includes("subscription")
        ? "preapproval"
        : topic.includes("authorized_payment")
          ? "authorized_payment"
          : topic.includes("payment")
            ? "payment"
            : "unknown";

  if (!resourceId || resourceType === "unknown") {
    return { kind: "ignored", reason: "unsupported_or_incomplete_notification" };
  }

  return {
    kind: "lookup_required",
    lookup: {
      eventId,
      provider: "mercado_pago",
      resourceType,
      resourceId,
      occurredAt: safeIso(get(event, "date_created")) ?? new Date().toISOString(),
      raw: event,
    },
  };
}

/**
 * Normalizes the AUTHORITATIVE resource fetched from the Mercado Pago API
 * (preapproval, authorized payment, or payment), not the webhook body.
 */
export function normalizeMercadoPagoResource(
  resource: unknown,
  lookup: WebhookLookupInstruction,
): NormalizedBillingEvent | null {
  const isPreapproval =
    lookup.resourceType === "preapproval" || lookup.resourceType === "unknown";
  const preapprovalId = isPreapproval
    ? str(get(resource, "id"))
    : str(get(resource, "preapproval_id"));

  const rawStatus = String(get(resource, "status") ?? "");
  const status = isPreapproval ? (MP_STATUS[rawStatus] ?? null) : null;

  let type: BillingEventType;
  if (isPreapproval) {
    type =
      status === "active"
        ? "SUBSCRIPTION_ACTIVATED"
        : status === "paused"
          ? "SUBSCRIPTION_PAUSED"
          : status === "cancelled"
            ? "SUBSCRIPTION_CANCELLED"
            : status === "expired"
              ? "SUBSCRIPTION_EXPIRED"
              : status === "pending"
                ? "SUBSCRIPTION_CREATED"
                : "SUBSCRIPTION_UPDATED";
  } else {
    type = ["approved", "accredited"].includes(rawStatus)
      ? "PAYMENT_SUCCEEDED"
      : rawStatus === "refunded"
        ? "PAYMENT_REFUNDED"
        : ["rejected", "cancelled"].includes(rawStatus)
          ? "PAYMENT_FAILED"
          : "SUBSCRIPTION_UPDATED";
  }

  return {
    eventId: lookup.eventId,
    provider: "mercado_pago",
    type,
    occurredAt: lookup.occurredAt,
    providerCustomerId:
      str(get(resource, "payer_id")) ?? str(get(resource, "payer.id")) ?? null,
    providerSubscriptionId: preapprovalId,
    providerPlanId: str(get(resource, "preapproval_plan_id")),
    billingInterval: isPreapproval
      ? get(resource, "auto_recurring.frequency_type") === "years"
        ? "yearly"
        : "monthly"
      : null,
    currency:
      str(get(resource, "auto_recurring.currency_id")) ?? str(get(resource, "currency_id")),
    status,
    currentPeriodStart: safeIso(get(resource, "last_modified")),
    currentPeriodEnd: safeIso(get(resource, "next_payment_date")),
    cancelAtPeriodEnd: null,
    // A payment resource only points at the preapproval; the host still has to
    // read the preapproval to know the authoritative subscription state.
    requiresAuthoritativeLookup: preapprovalId === null || !isPreapproval,
    raw: resource,
  };
}

/* --------------------------------- PayPal ---------------------------------- */

const PAYPAL_SUBSCRIPTION_EVENTS: Record<string, BillingEventType> = {
  "BILLING.SUBSCRIPTION.CREATED": "SUBSCRIPTION_CREATED",
  "BILLING.SUBSCRIPTION.ACTIVATED": "SUBSCRIPTION_ACTIVATED",
  "BILLING.SUBSCRIPTION.UPDATED": "SUBSCRIPTION_UPDATED",
  "BILLING.SUBSCRIPTION.RE-ACTIVATED": "SUBSCRIPTION_ACTIVATED",
  "BILLING.SUBSCRIPTION.SUSPENDED": "SUBSCRIPTION_PAUSED",
  "BILLING.SUBSCRIPTION.CANCELLED": "SUBSCRIPTION_CANCELLED",
  "BILLING.SUBSCRIPTION.EXPIRED": "SUBSCRIPTION_EXPIRED",
  "BILLING.SUBSCRIPTION.PAYMENT.FAILED": "PAYMENT_FAILED",
};

const PAYPAL_SALE_EVENTS: Record<string, BillingEventType> = {
  "PAYMENT.SALE.COMPLETED": "PAYMENT_SUCCEEDED",
  "PAYMENT.SALE.DENIED": "PAYMENT_FAILED",
  "PAYMENT.SALE.REFUNDED": "PAYMENT_REFUNDED",
  "PAYMENT.SALE.REVERSED": "PAYMENT_REFUNDED",
};

export function normalizePayPalEvent(event: unknown): NormalizedBillingEvent | null {
  const type = String(get(event, "event_type") ?? "");
  const res = get(event, "resource");
  const eventId = str(get(event, "id")) ?? "";
  const occurredAt = safeIso(get(event, "create_time")) ?? new Date().toISOString();

  // --- Subscription resources ----------------------------------------------
  const subEvent = PAYPAL_SUBSCRIPTION_EVENTS[type];
  if (subEvent) {
    return {
      eventId,
      provider: "paypal",
      type: subEvent,
      occurredAt,
      providerCustomerId: str(get(res, "subscriber.payer_id")),
      providerSubscriptionId: str(get(res, "id")),
      providerPlanId: str(get(res, "plan_id")),
      billingInterval: null,
      currency: str(get(res, "billing_info.last_payment.amount.currency_code")),
      status: PAYPAL_STATUS[String(get(res, "status") ?? "")] ?? null,
      currentPeriodStart: safeIso(get(res, "start_time")),
      currentPeriodEnd: safeIso(get(res, "billing_info.next_billing_time")),
      cancelAtPeriodEnd: null,
      requiresAuthoritativeLookup: false,
      raw: event,
    };
  }

  // --- Sale resources: resource.id is a SALE id, never a subscription id ----
  const saleEvent = PAYPAL_SALE_EVENTS[type];
  if (saleEvent) {
    // PayPal exposes the subscription on sales via billing_agreement_id
    // (legacy) or the supplementary billing_subscription reference.
    const subscriptionId =
      str(get(res, "billing_agreement_id")) ??
      str(get(res, "supplementary_data.related_ids.subscription_id")) ??
      null;
    return {
      eventId,
      provider: "paypal",
      type: saleEvent,
      occurredAt,
      providerCustomerId: str(get(res, "payer.payer_info.payer_id")),
      providerSubscriptionId: subscriptionId,
      providerPlanId: null,
      billingInterval: null,
      currency: str(get(res, "amount.currency")) ?? str(get(res, "amount.currency_code")),
      status: null,
      currentPeriodStart: null,
      currentPeriodEnd: null,
      cancelAtPeriodEnd: null,
      // Sale id (resource.id) is deliberately NOT used as a subscription id.
      requiresAuthoritativeLookup: subscriptionId === null,
      raw: event,
    };
  }

  return null;
}

export function intakePayPalEvent(event: unknown): WebhookIntake {
  const normalized = normalizePayPalEvent(event);
  if (!normalized) return { kind: "ignored", reason: "unsupported_event" };
  if (normalized.requiresAuthoritativeLookup && !normalized.providerSubscriptionId) {
    return {
      kind: "lookup_required",
      lookup: {
        eventId: normalized.eventId,
        provider: "paypal",
        resourceType: "sale",
        resourceId: str(get(event, "resource.id")),
        occurredAt: normalized.occurredAt,
        raw: event,
      },
    };
  }
  return { kind: "normalized", event: normalized };
}

/* -------------------------------- intake ---------------------------------- */

export function intakeWebhookEvent(provider: ProviderId, event: unknown): WebhookIntake {
  if (provider === "mercado_pago") return intakeMercadoPagoNotification(event);
  if (provider === "paypal") return intakePayPalEvent(event);
  const normalized = normalizeStripeEvent(event);
  return normalized
    ? { kind: "normalized", event: normalized }
    : { kind: "ignored", reason: "unsupported_event" };
}

/** Detects what a fetched PayPal resource actually is. */
function paypalResourceKind(
  lookup: WebhookLookupInstruction,
  resource: unknown,
): "subscription" | "sale" {
  if (lookup.resourceType === "sale" || lookup.resourceType === "payment") return "sale";
  if (get(resource, "plan_id") !== undefined || get(resource, "billing_info") !== undefined) {
    return "subscription";
  }
  if (
    get(resource, "billing_agreement_id") !== undefined ||
    get(resource, "amount") !== undefined
  ) {
    return "sale";
  }
  return lookup.resourceType === "subscription" ? "subscription" : "sale";
}

/** Normalizes an authoritative resource fetched by the host after a lookup. */
export function normalizeAuthoritativeResource(
  lookup: WebhookLookupInstruction,
  resource: unknown,
): NormalizedBillingEvent | null {
  if (lookup.provider === "mercado_pago") return normalizeMercadoPagoResource(resource, lookup);
  if (lookup.provider === "paypal") {
    const kind = paypalResourceKind(lookup, resource);
    if (kind === "sale") {
      // A PayPal Sale/Payment id is NEVER a subscription id.
      const subscriptionId =
        str(get(resource, "billing_agreement_id")) ??
        str(get(resource, "supplementary_data.related_ids.subscription_id")) ??
        null;
      return {
        eventId: lookup.eventId,
        provider: "paypal",
        type: "PAYMENT_SUCCEEDED",
        occurredAt: lookup.occurredAt,
        providerCustomerId: str(get(resource, "payer.payer_info.payer_id")),
        providerSubscriptionId: subscriptionId,
        providerPlanId: null,
        billingInterval: null,
        currency:
          str(get(resource, "amount.currency")) ?? str(get(resource, "amount.currency_code")),
        status: null,
        currentPeriodStart: null,
        currentPeriodEnd: null,
        cancelAtPeriodEnd: null,
        // Even with a reference, the authoritative subscription must be read.
        requiresAuthoritativeLookup: true,
        raw: resource,
      };
    }
    const subscriptionId = str(get(resource, "id"));
    return {
      eventId: lookup.eventId,
      provider: "paypal",
      type: PAYPAL_STATUS[String(get(resource, "status") ?? "")] === "active"
        ? "SUBSCRIPTION_ACTIVATED"
        : "SUBSCRIPTION_UPDATED",
      occurredAt: lookup.occurredAt,
      providerCustomerId: str(get(resource, "subscriber.payer_id")),
      providerSubscriptionId: subscriptionId,
      providerPlanId: str(get(resource, "plan_id")),
      billingInterval: null,
      currency: str(get(resource, "billing_info.last_payment.amount.currency_code")),
      status: PAYPAL_STATUS[String(get(resource, "status") ?? "")] ?? null,
      currentPeriodStart: safeIso(get(resource, "start_time")),
      currentPeriodEnd: safeIso(get(resource, "billing_info.next_billing_time")),
      cancelAtPeriodEnd: null,
      requiresAuthoritativeLookup: subscriptionId === null,
      raw: resource,
    };
  }
  // Stripe: the resource IS the subscription object.
  return normalizeStripeEvent({
    id: lookup.eventId,
    type: "customer.subscription.updated",
    created: lookup.occurredAt,
    data: { object: resource },
  });
}

/**
 * Computes the NEXT authoritative lookup when an event is still unresolved.
 * Returns null when nothing further can be resolved safely — the host must
 * then stop without applying the event.
 */
export function nextAuthoritativeLookup(
  lookup: WebhookLookupInstruction,
  event: NormalizedBillingEvent,
): WebhookLookupInstruction | null {
  if (!event.requiresAuthoritativeLookup) return null;
  const subscriptionRef =
    event.providerSubscriptionId ??
    (event.provider === "mercado_pago" ? str(get(event.raw, "preapproval_id")) : null);
  if (!subscriptionRef) return null;
  const resourceType: ProviderResourceType =
    event.provider === "mercado_pago" ? "preapproval" : "subscription";
  if (lookup.resourceType === resourceType && lookup.resourceId === subscriptionRef) {
    return null; // already fetched this exact resource; avoid loops
  }
  return { ...lookup, resourceType, resourceId: subscriptionRef };
}


/**
 * Reference pipeline.
 * verify -> parse -> intake -> (authoritative lookup) -> atomic claim -> apply.
 * `apply` is host-owned persistence (DB write + entitlement refresh).
 */
export async function processWebhook(args: {
  provider: ProviderId;
  rawBody: string;
  headers: Record<string, string>;
  verifier: WebhookVerifier;
  idempotency: IdempotencyStore;
  /** Required for Mercado Pago and for PayPal sale events. */
  fetcher?: ProviderResourceFetcher;
  apply: (event: NormalizedBillingEvent) => Promise<void>;
}): Promise<{ status: 200 | 202 | 400 | 401 | 500; reason: string }> {
  const ok = await args.verifier.verify(args.rawBody, args.headers);
  if (!ok) return { status: 401, reason: "invalid_signature" };

  let parsed: unknown;
  try {
    parsed = JSON.parse(args.rawBody);
  } catch {
    return { status: 400, reason: "invalid_json" };
  }

  const intake = intakeWebhookEvent(args.provider, parsed);
  if (intake.kind === "ignored") return { status: 202, reason: intake.reason };

  let event: NormalizedBillingEvent | null;
  if (intake.kind === "lookup_required") {
    if (!args.fetcher || !intake.lookup.resourceId) {
      return { status: 202, reason: "authoritative_lookup_unavailable" };
    }
    // Iterative resolution: an event NEVER reaches apply() while
    // requiresAuthoritativeLookup is still true.
    let lookup: WebhookLookupInstruction | null = intake.lookup;
    event = null;
    for (let i = 0; i < 4 && lookup && lookup.resourceId; i += 1) {
      const resource = await args.fetcher.fetchResource(
        lookup.provider,
        lookup.resourceType,
        lookup.resourceId,
      );
      const normalized = normalizeAuthoritativeResource(lookup, resource);
      if (!normalized) return { status: 202, reason: "ignored_event" };
      event = normalized;
      if (!normalized.requiresAuthoritativeLookup) break;
      lookup = nextAuthoritativeLookup(lookup, normalized);
    }
    if (!event || event.requiresAuthoritativeLookup) {
      // Safe terminal state: no apply, no fabricated subscription id.
      return { status: 202, reason: "authoritative_lookup_unresolved" };
    }
  } else {
    event = intake.event;
    if (event.requiresAuthoritativeLookup) {
      return { status: 202, reason: "authoritative_lookup_unresolved" };
    }
  }

  if (!event || !event.eventId) return { status: 202, reason: "ignored_event" };

  // ATOMIC, PROVIDER-SCOPED claim: only one concurrent delivery may proceed.
  const claimed = await args.idempotency.claim(event.provider, event.eventId);
  if (!claimed) return { status: 200, reason: "duplicate_ignored" };

  try {
    await args.apply(event);
  } catch (err) {
    await args.idempotency.release(event.provider, event.eventId);
    return { status: 500, reason: err instanceof Error ? err.message : "apply_failed" };
  }
  await args.idempotency.markProcessed(event.provider, event.eventId);
  return { status: 200, reason: "processed" };
}

