/**
 * CRIPQER BILLING V1 — billing account screen.
 * Reads normalized subscription state from the host server and exposes
 * change plan / manage payment / cancel. It never deletes user content.
 */

import { useCallback, useEffect, useState } from "react";
import { BILLING_CATALOG, getPlan } from "./billing.catalog";
import { PROVIDER_META, createProviderAdapter } from "./billing.providers";
import type { BillingServerClient } from "./billing.server-contract";
import type {
  BillingCatalog,
  Subscription,
  SubscriptionStatus,
} from "./billing.types";

const STATUS_LABEL: Record<SubscriptionStatus, string> = {
  free: "Plan gratuito",
  pending: "Pago pendiente",
  active: "Activa",
  past_due: "Pago vencido",
  paused: "Pausada",
  cancelled: "Cancelada",
  expired: "Expirada",
};

export interface BillingAccountProps {
  server: BillingServerClient;
  catalog?: BillingCatalog;
  locale?: string;
  onChangePlan?: () => void;
}

export function BillingAccount({
  server,
  catalog = BILLING_CATALOG,
  locale = "es-CL",
  onChangePlan,
}: BillingAccountProps) {
  const [sub, setSub] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [confirmCancel, setConfirmCancel] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setSub(await server.getSubscription());
    } catch (e) {
      setError(e instanceof Error ? e.message : "No se pudo cargar la facturación.");
    } finally {
      setLoading(false);
    }
  }, [server]);

  useEffect(() => {
    void load();
  }, [load]);

  const fmtDate = (iso: string | null) =>
    iso ? new Date(iso).toLocaleDateString(locale, { dateStyle: "long" }) : "—";

  async function cancel() {
    if (!sub) return;
    setConfirmCancel(false);
    const atPeriodEnd = catalog.policies.cancellation === "at_period_end";
    setBusy(true);
    setError(null);
    try {
      setSub(await server.cancelSubscription({ subscriptionId: sub.subscriptionId, atPeriodEnd }));
      setNotice(
        atPeriodEnd
          ? "Tu suscripción seguirá activa hasta el final del período y no se renovará."
          : "Tu suscripción fue cancelada.",
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "No se pudo cancelar la suscripción.");
    } finally {
      setBusy(false);
    }
  }

  async function reactivate() {
    if (!sub) return;
    setBusy(true);
    setError(null);
    try {
      setSub(await server.reactivateSubscription({ subscriptionId: sub.subscriptionId }));
      setNotice("Cancelación revertida. Tu suscripción se renovará normalmente.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "No se pudo reactivar la suscripción.");
    } finally {
      setBusy(false);
    }
  }

  async function managePayment() {
    if (!sub?.provider) return;
    setBusy(true);
    setError(null);
    try {
      const adapter = createProviderAdapter(sub.provider, server);
      const { portalUrl } = await adapter.manageBilling();
      if (portalUrl && typeof window !== "undefined") window.location.assign(portalUrl);
      else setNotice("Este proveedor no ofrece portal de gestión. Contacta a soporte.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "No se pudo abrir la gestión de pago.");
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return (
      <section className="cq-billing">
        <div className="cq-state" aria-live="polite">
          <div className="cq-spinner" aria-hidden="true" />
          <p className="cq-muted">Cargando tu facturación…</p>
        </div>
      </section>
    );
  }

  const plan = getPlan(sub?.planId ?? "free", catalog);
  const status: SubscriptionStatus = sub?.status ?? "free";
  const providerLabel = sub?.provider ? PROVIDER_META[sub.provider].label : "—";
  const canCancel = Boolean(sub) && ["active", "past_due", "paused"].includes(status);
  const providerMeta = sub?.provider ? PROVIDER_META[sub.provider] : null;
  const canReactivate =
    Boolean(sub?.cancelAtPeriodEnd) && status === "active" && Boolean(providerMeta?.supportsReactivation);

  return (
    <section className="cq-billing" aria-labelledby="cq-account-title">
      <h1 className="cq-h1" id="cq-account-title">
        Facturación
      </h1>
      <p className="cq-sub">Tu plan, estado de suscripción y opciones de pago.</p>

      {error ? <p className="cq-note cq-note--error">{error}</p> : null}
      {notice ? <p className="cq-note cq-note--ok">{notice}</p> : null}

      <div className="cq-summary">
        <div className="cq-row">
          <span>Plan actual</span>
          <span>{plan?.name ?? "Free"}</span>
        </div>
        <div className="cq-row">
          <span>Estado</span>
          <span className={`cq-status cq-status--${status}`}>{STATUS_LABEL[status]}</span>
        </div>
        <div className="cq-row">
          <span>Ciclo</span>
          <span>{sub?.billingInterval === "yearly" ? "Anual" : sub ? "Mensual" : "—"}</span>
        </div>
        <div className="cq-row">
          <span>{sub?.cancelAtPeriodEnd ? "Acceso hasta" : "Próxima renovación"}</span>
          <span>{fmtDate(sub?.currentPeriodEnd ?? null)}</span>
        </div>
        <div className="cq-row">
          <span>Proveedor de pago</span>
          <span>{providerLabel}</span>
        </div>
        {sub?.paymentMethodLabel ? (
          <div className="cq-row">
            <span>Medio de pago</span>
            <span>{sub.paymentMethodLabel}</span>
          </div>
        ) : null}
      </div>

      {sub?.cancelAtPeriodEnd ? (
        <p className="cq-note cq-note--warn">
          Cancelación programada. Conservas el acceso hasta {fmtDate(sub.currentPeriodEnd)}. Tu
          contenido y configuración de páginas no se eliminan.
        </p>
      ) : null}
      {status === "past_due" ? (
        <p className="cq-note cq-note--warn">
          El último cobro falló. Actualiza tu medio de pago para mantener el plan.
        </p>
      ) : null}

      {confirmCancel && sub ? (
        <div className="cq-confirm" role="group" aria-label="Confirmar cancelación">
          <p>
            ¿Cancelar <strong>{plan?.name ?? "tu plan"}</strong>?
          </p>
          <p className="cq-muted">
            {catalog.policies.cancellation === "at_period_end"
              ? `Conservas el acceso hasta ${fmtDate(sub.currentPeriodEnd)} y no habrá renovación. Tu contenido y configuración no se eliminan.`
              : "La cancelación es inmediata. Tu contenido y configuración no se eliminan."}
          </p>
          <div className="cq-actions">
            <button type="button" className="cq-btn" onClick={() => setConfirmCancel(false)} disabled={busy}>
              Mantener mi plan
            </button>
            <button
              type="button"
              className="cq-btn cq-btn--danger"
              onClick={cancel}
              disabled={busy}
            >
              Sí, cancelar
            </button>
          </div>
        </div>
      ) : null}

      <div className="cq-actions">
        {canReactivate ? (
          <button type="button" className="cq-btn cq-btn--primary" onClick={reactivate} disabled={busy}>
            Reactivar suscripción
          </button>
        ) : null}
        <button type="button" className="cq-btn cq-btn--primary" onClick={onChangePlan} disabled={busy}>
          Cambiar de plan
        </button>
        <button
          type="button"
          className="cq-btn"
          onClick={managePayment}
          disabled={busy || !sub?.provider}
        >
          Gestionar pago
        </button>
        <button
          type="button"
          className="cq-btn cq-btn--danger cq-btn--ghost"
          onClick={() => setConfirmCancel(true)}
          disabled={busy || !canCancel || Boolean(sub?.cancelAtPeriodEnd) || confirmCancel}
        >
          Cancelar suscripción
        </button>
      </div>
    </section>
  );
}

export default BillingAccount;
