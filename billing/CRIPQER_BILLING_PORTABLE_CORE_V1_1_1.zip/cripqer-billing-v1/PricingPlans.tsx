/**
 * CRIPQER BILLING V1 — pricing screen.
 * Pure presentation: every price, label, badge and provider id comes from the
 * catalog. No provider logic, no secrets, no network calls.
 */

import { useMemo, useState } from "react";
import {
  BILLING_CATALOG,
  formatPrice,
  getPrice,
  yearlySavingsPercent,
} from "./billing.catalog";
import type {
  BillingCatalog,
  BillingInterval,
  PlanDefinition,
  PlanId,
} from "./billing.types";

export interface PricingPlansProps {
  catalog?: BillingCatalog;
  currentPlan?: PlanId;
  /** Interval of the active subscription; same plan + other interval is NOT current. */
  currentInterval?: BillingInterval;
  locale?: string;
  defaultInterval?: BillingInterval;
  /** Free plan CTA / already-owned plan. */
  onSelectFree?: () => void;
  /** Paid plan CTA -> host routes to <BillingCheckout />. */
  onSelectPlan: (planId: PlanId, interval: BillingInterval) => void;
  /** Enterprise CTA when contactSales is true. */
  onContactSales?: () => void;
}

export function PricingPlans({
  catalog = BILLING_CATALOG,
  currentPlan = "free",
  currentInterval,
  locale = "es-CL",
  defaultInterval,
  onSelectFree,
  onSelectPlan,
  onContactSales,
}: PricingPlansProps) {
  const [interval, setInterval] = useState<BillingInterval>(
    defaultInterval ?? catalog.defaultInterval,
  );

  const plans = useMemo(() => catalog.plans, [catalog]);
  const directEnterprise = catalog.policies.enterpriseDirectCheckout;

  return (
    <section className="cq-billing" aria-labelledby="cq-pricing-title">
      <h1 className="cq-h1" id="cq-pricing-title">
        Planes Cripqer
      </h1>
      <p className="cq-sub">
        Precios transparentes. Cambia o cancela cuando quieras.
      </p>

      <div className="cq-toggle" role="group" aria-label="Ciclo de facturación">
        <button
          type="button"
          aria-pressed={interval === "monthly"}
          onClick={() => setInterval("monthly")}
        >
          Mensual
        </button>
        <button
          type="button"
          aria-pressed={interval === "yearly"}
          onClick={() => setInterval("yearly")}
        >
          Anual
        </button>
      </div>

      <div className="cq-grid">
        {plans.map((plan) => (
          <PlanCard
            key={plan.id}
            plan={plan}
            interval={interval}
            locale={locale}
            isCurrent={
              plan.id === currentPlan &&
              (currentInterval === undefined || currentInterval === interval)
            }
            showSavings={catalog.policies.showYearlySavings}
            onSelect={() => {
              if (plan.contactSales && !directEnterprise) {
                onContactSales?.();
                return;
              }
              if (!plan.checkoutEnabled && !plan.contactSales) {
                onSelectFree?.();
                return;
              }
              onSelectPlan(plan.id, interval);
            }}
          />
        ))}
      </div>
    </section>
  );
}

function PlanCard({
  plan,
  interval,
  locale,
  isCurrent,
  showSavings,
  onSelect,
}: {
  plan: PlanDefinition;
  interval: BillingInterval;
  locale: string;
  isCurrent: boolean;
  showSavings: boolean;
  onSelect: () => void;
}) {
  const price = getPrice(plan, interval);
  const savings = showSavings && interval === "yearly" ? yearlySavingsPercent(plan) : null;

  return (
    <article
      className={[
        "cq-card",
        plan.recommended ? "cq-card--recommended" : "",
        isCurrent ? "cq-card--current" : "",
      ]
        .filter(Boolean)
        .join(" ")}
      aria-label={`Plan ${plan.name}`}
    >
      {plan.badge ? <span className="cq-badge">{plan.badge}</span> : null}
      {isCurrent ? <span className="cq-badge cq-badge--muted">Plan actual</span> : null}

      <h2 className="cq-h2">{plan.name}</h2>
      <p className="cq-muted">{plan.description}</p>

      <div className="cq-price">
        <strong>
          {plan.contactSales ? "A medida" : formatPrice(price, plan.currency, locale)}
        </strong>
        {!plan.contactSales && price !== null ? (
          <span className="cq-muted">
            /{interval === "yearly" ? "año" : "mes"}
          </span>
        ) : null}
      </div>
      {savings !== null ? (
        <span className="cq-muted">Ahorras {savings}% frente al pago mensual</span>
      ) : null}

      <ul className="cq-features">
        {plan.features.map((f) => (
          <li key={f}>{f}</li>
        ))}
      </ul>

      <button
        type="button"
        className={`cq-btn ${plan.recommended ? "cq-btn--primary" : ""}`}
        onClick={onSelect}
        disabled={isCurrent && !plan.contactSales}
      >
        {isCurrent && !plan.contactSales ? "Tu plan actual" : plan.ctaLabel}
      </button>
    </article>
  );
}

export default PricingPlans;
