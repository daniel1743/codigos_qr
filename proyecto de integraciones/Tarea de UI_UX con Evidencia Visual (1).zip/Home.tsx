/* Editorial Canvas — direct-on-page editing, warm paper surfaces, graphite selection ink. */
import { useMemo, useState } from "react";
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  ArrowLeft,
  Check,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  Circle,
  Eye,
  GripHorizontal,
  Image as ImageIcon,
  ImagePlus,
  LayoutTemplate,
  Link2,
  MoveVertical,
  PanelBottom,
  Palette,
  PenLine,
  Plus,
  ScanFace,
  SlidersHorizontal,
  Sparkles,
  Square,
  Type,
  UserRound,
} from "lucide-react";

type SheetState = "collapsed" | "medium" | "expanded";
type Selection = "banner" | "avatar" | "name" | "bio" | "button" | "card" | "footer";
type Tab = "Perfil" | "Enlaces" | "Diseño" | "Galería";

const ASSETS = {
  banner: "/manus-storage/editor-banner_86eacacd.jpg",
  avatar: "/manus-storage/editor-avatar_f71a32fe.jpg",
  card: "/manus-storage/editor-card_dbbab06b.jpg",
  logo: "/manus-storage/folio-mark_a3f5cc16.png",
};

const tabs: { label: Tab; icon: typeof UserRound }[] = [
  { label: "Perfil", icon: UserRound },
  { label: "Enlaces", icon: Link2 },
  { label: "Diseño", icon: Palette },
  { label: "Galería", icon: ImageIcon },
];

const selectionCopy: Record<Selection, { eyebrow: string; title: string }> = {
  banner: { eyebrow: "Fondo de página", title: "Banner" },
  avatar: { eyebrow: "Imagen de perfil", title: "Avatar" },
  name: { eyebrow: "Texto seleccionado", title: "Nombre" },
  bio: { eyebrow: "Texto seleccionado", title: "Biografía" },
  button: { eyebrow: "Enlace seleccionado", title: "Botón" },
  card: { eyebrow: "Enlace seleccionado", title: "Tarjeta" },
  footer: { eyebrow: "Pie de página", title: "Footer" },
};

const chipSets = {
  fonts: ["Inter", "Poppins", "Manrope", "Lato", "Raleway"],
  buttonShape: ["Cuadrado", "Redondeado", "Píldora", "Premium"],
  border: ["Ninguno", "Fino", "Medio", "Fuerte"],
  alignment: ["Izquierda", "Centro", "Derecha"],
};

function ChipRow({
  items,
  active,
  onSelect,
  ariaLabel,
  fontNames = false,
}: {
  items: string[];
  active: string;
  onSelect: (item: string) => void;
  ariaLabel: string;
  fontNames?: boolean;
}) {
  return (
    <div className="chip-scroll" aria-label={ariaLabel} role="list">
      {items.map((item) => (
        <button
          className={`choice-chip ${active === item ? "is-active" : ""} ${fontNames ? `font-${item.toLowerCase()}` : ""}`}
          key={item}
          onClick={() => onSelect(item)}
          role="listitem"
          type="button"
        >
          {active === item && <Check size={12} strokeWidth={2.6} />}
          <span>{item}</span>
        </button>
      ))}
      <ChevronRight className="chip-end" size={14} aria-hidden="true" />
    </div>
  );
}

function RangeControl({ label, value, fill = "64%" }: { label: string; value: string; fill?: string }) {
  return (
    <div className="range-control">
      <div className="range-label">
        <span>{label}</span>
        <span className="range-value">{value}</span>
      </div>
      <div className="range-track" aria-hidden="true">
        <span className="range-fill" style={{ width: fill }} />
        <span className="range-thumb" style={{ left: fill }} />
      </div>
    </div>
  );
}

function ColorSwatches({ active, onSelect }: { active: string; onSelect: (color: string) => void }) {
  const swatches = [
    { name: "Negro", value: "ink", color: "#1d1d1b" },
    { name: "Blanco", value: "white", color: "#ffffff" },
    { name: "Gris", value: "gray", color: "#bab8b1" },
    { name: "Arena", value: "sand", color: "#ded8cc" },
  ];
  return (
    <div className="swatches" aria-label="Color del botón">
      {swatches.map((swatch) => (
        <button
          className={`swatch-option ${active === swatch.value ? "is-active" : ""}`}
          key={swatch.value}
          onClick={() => onSelect(swatch.value)}
          type="button"
        >
          <span className="swatch-dot" style={{ backgroundColor: swatch.color }} />
          <span>{swatch.name}</span>
        </button>
      ))}
    </div>
  );
}

function SectionLabel({ children, trailing }: { children: string; trailing?: string }) {
  return (
    <div className="section-label">
      <span>{children}</span>
      {trailing && <span className="section-trailing">{trailing}</span>}
    </div>
  );
}

export default function Home() {
  const [selected, setSelected] = useState<Selection>("bio");
  const [sheetState, setSheetState] = useState<SheetState>("medium");
  const [activeTab, setActiveTab] = useState<Tab>("Perfil");
  const [font, setFont] = useState("Manrope");
  const [shape, setShape] = useState("Redondeado");
  const [border, setBorder] = useState("Fino");
  const [alignment, setAlignment] = useState("Centro");
  const [buttonColor, setButtonColor] = useState("ink");
  const [linkPresentation, setLinkPresentation] = useState<"Botón" | "Tarjeta">("Botón");

  const selectedCopy = useMemo(() => selectionCopy[selected], [selected]);
  const selectedElementClass = (key: Selection) => `canvas-element ${selected === key ? "is-selected" : ""}`;

  const selectElement = (key: Selection) => {
    setSelected(key);
    if (sheetState === "collapsed") setSheetState("medium");
  };

  const renderContext = () => {
    if (activeTab === "Galería") {
      return (
        <div className="context-content">
          <div className="context-row gallery-heading">
            <div>
              <SectionLabel trailing="4 elementos">Galería</SectionLabel>
              <p className="helper-copy">Elige qué aparece en tu página.</p>
            </div>
            <button className="icon-button soft" type="button" aria-label="Añadir imagen">
              <Plus size={16} />
            </button>
          </div>
          <div className="mini-gallery">
            <button className="mini-gallery-item is-active" type="button" onClick={() => selectElement("card")}>
              <img src={ASSETS.card} alt="Vista previa de naturaleza muerta editorial" />
              <span>Estudio 01</span>
            </button>
            <button className="mini-gallery-item" type="button" onClick={() => selectElement("banner")}>
              <img src={ASSETS.banner} alt="Vista previa de banner arquitectónico" />
              <span>Portada</span>
            </button>
            <button className="mini-gallery-add" type="button">
              <ImagePlus size={18} />
              <span>Añadir</span>
            </button>
          </div>
        </div>
      );
    }

    if (activeTab === "Diseño") {
      return (
        <div className="context-content">
          <div className="context-row">
            <div>
              <SectionLabel trailing="Tema actual">Estilo</SectionLabel>
              <p className="helper-copy">Una base clara para que tu contenido respire.</p>
            </div>
            <button className="theme-sample" type="button" aria-label="Tema marfil seleccionado">
              <span />
              <Check size={12} />
            </button>
          </div>
          <SectionLabel trailing="Horizontal">Alineación</SectionLabel>
          <ChipRow items={chipSets.alignment} active={alignment} onSelect={setAlignment} ariaLabel="Alineación" />
          <SectionLabel trailing="Página">Fondo</SectionLabel>
          <ColorSwatches active="sand" onSelect={() => undefined} />
          <RangeControl label="Separación" value="24 px" fill="58%" />
        </div>
      );
    }

    if (activeTab === "Enlaces" || selected === "button" || selected === "card") {
      return (
        <div className="context-content">
          <SectionLabel trailing="Presentación">Enlace</SectionLabel>
          <div className="segmented-control" role="tablist" aria-label="Presentación del enlace">
            {(["Botón", "Tarjeta"] as const).map((item) => (
              <button className={linkPresentation === item ? "is-active" : ""} key={item} onClick={() => setLinkPresentation(item)} role="tab" type="button">
                {item === "Botón" ? <Square size={13} /> : <LayoutTemplate size={13} />}
                {item}
              </button>
            ))}
          </div>
          {linkPresentation === "Tarjeta" ? (
            <div className="card-preview-control">
              <div className="card-preview-copy">
                <span className="preview-percent">75% contenido</span>
                <strong>Título del enlace</strong>
                <small>Descripción corta</small>
              </div>
              <img src={ASSETS.card} alt="Preview visual de tarjeta" />
              <span className="preview-percent right">25% foto</span>
            </div>
          ) : (
            <>
              <SectionLabel trailing="Horizontal">Forma</SectionLabel>
              <ChipRow items={chipSets.buttonShape} active={shape} onSelect={setShape} ariaLabel="Forma de botón" />
              <SectionLabel trailing="Horizontal">Bordes</SectionLabel>
              <ChipRow items={chipSets.border} active={border} onSelect={setBorder} ariaLabel="Bordes" />
              <SectionLabel trailing="Compacto">Color del botón</SectionLabel>
              <ColorSwatches active={buttonColor} onSelect={setButtonColor} />
            </>
          )}
          <RangeControl label="Radio" value="12 px" fill="72%" />
        </div>
      );
    }

    if (selected === "avatar") {
      return (
        <div className="context-content">
          <div className="context-row">
            <div>
              <SectionLabel trailing="1:1">Avatar</SectionLabel>
              <p className="helper-copy">Una imagen que se reconoce de inmediato.</p>
            </div>
            <button className="icon-button soft" type="button" aria-label="Cambiar avatar">
              <ScanFace size={16} />
            </button>
          </div>
          <div className="avatar-options">
            <button className="avatar-shape active" type="button"><Circle size={17} /><span>Círculo</span></button>
            <button className="avatar-shape" type="button"><Square size={17} /><span>Cuadrado</span></button>
          </div>
          <RangeControl label="Tamaño" value="96 px" fill="68%" />
          <RangeControl label="Difuminación" value="0%" fill="4%" />
        </div>
      );
    }

    if (selected === "banner") {
      return (
        <div className="context-content">
          <SectionLabel trailing="Presets horizontales">Fondo</SectionLabel>
          <div className="background-presets">
            <button className="background-preset is-active" type="button" aria-label="Fondo marfil"><span className="preset-ivory" /><Check size={12} /></button>
            <button className="background-preset" type="button" aria-label="Fondo piedra"><span className="preset-stone" /></button>
            <button className="background-preset" type="button" aria-label="Fondo tinta"><span className="preset-ink" /></button>
            <button className="background-preset" type="button" aria-label="Fondo imagen"><img src={ASSETS.banner} alt="" /></button>
          </div>
          <RangeControl label="Altura del banner" value="148 px" fill="56%" />
          <RangeControl label="Opacidad" value="100%" fill="100%" />
        </div>
      );
    }

    if (selected === "footer") {
      return (
        <div className="context-content">
          <SectionLabel trailing="Horizontal">Alineación</SectionLabel>
          <ChipRow items={chipSets.alignment} active={alignment} onSelect={setAlignment} ariaLabel="Alineación del footer" />
          <RangeControl label="Separación" value="20 px" fill="48%" />
          <div className="footer-note"><Sparkles size={14} />Visible, incluso al final de la página.</div>
        </div>
      );
    }

    return (
      <div className="context-content">
        <SectionLabel trailing="Horizontal">Fuentes</SectionLabel>
        <ChipRow items={chipSets.fonts} active={font} onSelect={setFont} ariaLabel="Fuentes" fontNames />
        <div className="text-tools-row">
          <button className="format-button is-active" type="button"><strong>B</strong></button>
          <button className="format-button" type="button"><em>I</em></button>
          <button className="format-button" type="button"><AlignLeft size={14} /></button>
          <button className="format-button" type="button"><AlignCenter size={14} /></button>
          <button className="format-button" type="button"><AlignRight size={14} /></button>
          <span className="text-size">16 <small>px</small></span>
        </div>
        <RangeControl label="Interlineado" value="1.5" fill="54%" />
        <RangeControl label="Separación" value="12 px" fill="38%" />
      </div>
    );
  };

  return (
    <main className="editor-app">
      <div className="editor-desktop-rail left-rail" aria-hidden="true">
        <div className="rail-kicker"><span className="rail-line" /> PROTOTIPO UI/UX</div>
        <h1>Edita sobre<br /><i>la página.</i></h1>
        <p>Una maqueta visual donde el resultado permanece visible mientras cada detalle toma forma.</p>
        <div className="rail-rule" />
        <span className="rail-meta">EDITORIAL CANVAS / 01</span>
      </div>

      <section className="editor-device" aria-label="Prototipo de editor móvil">
        <header className="editor-header">
          <button className="header-icon" type="button" aria-label="Volver"><ArrowLeft size={17} /></button>
          <div className="header-title"><img src={ASSETS.logo} alt="" /><strong className="brand-wordmark">folio</strong><span className="header-divider">/</span><span>Editor</span><span className="saved-state"><span className="state-dot" />Borrador</span></div>
          <button className="header-icon" type="button" aria-label="Vista previa"><Eye size={17} /></button>
        </header>

        <div className={`canvas-zone sheet-${sheetState}`}>
          <div className="canvas-meta"><span>MI PÁGINA <span className="margin-mark">│</span> MARGEN 01</span><span className="canvas-meta-right"><span className="live-dot" />Vista en vivo</span></div>
          <div className="canvas-scroll" aria-label="Canvas desplazable de la página">
            <article className="profile-page">
              <button className={`${selectedElementClass("banner")} banner`} onClick={() => selectElement("banner")} type="button" aria-label="Seleccionar banner">
                <img src={ASSETS.banner} alt="Banner abstracto de arquitectura" />
                <span className="element-tag">Banner</span>
              </button>
              <div className="profile-content">
                <button className={`${selectedElementClass("avatar")} avatar`} onClick={() => selectElement("avatar")} type="button" aria-label="Seleccionar avatar">
                  <img src={ASSETS.avatar} alt="Retrato de Alex Rivera" />
                  <span className="element-tag">Avatar</span>
                </button>
                <button className={`${selectedElementClass("name")} profile-name`} onClick={() => selectElement("name")} type="button" aria-label="Seleccionar nombre">
                  Alex Rivera <span className="verified">✓</span>
                  <span className="element-tag">Nombre</span>
                </button>
                <button className={`${selectedElementClass("bio")} profile-bio`} onClick={() => selectElement("bio")} type="button" aria-label="Seleccionar biografía">
                  Diseño objetos digitales, espacios tranquilos y otras formas de claridad.
                  <span className="element-tag">Biografía</span>
                </button>
                <div className="profile-links">
                  <button className={`${selectedElementClass("button")} profile-link main-link`} onClick={() => selectElement("button")} type="button" aria-label="Seleccionar botón de enlace">
                    <span className="link-leading"><PenLine size={15} /></span>
                    <span>Notas de proceso</span>
                    <ChevronRight size={15} />
                    <span className="element-tag">Botón</span>
                  </button>
                  <button className="profile-link secondary-link" type="button" onClick={() => selectElement("button")} aria-label="Seleccionar enlace secundario">
                    <span>Estudio / 2025</span><ArrowLeft size={14} className="turn-arrow" />
                  </button>
                </div>
                <button className={`${selectedElementClass("card")} feature-card`} onClick={() => selectElement("card")} type="button" aria-label="Seleccionar tarjeta">
                  <span className="feature-card-copy"><small>EN EL ESTUDIO</small><strong>Objetos<br />que respiran</strong><span>→ Ver colección</span></span>
                  <img src={ASSETS.card} alt="Composición de objetos de estudio" />
                  <span className="element-tag">Tarjeta</span>
                </button>
                <button className={`${selectedElementClass("footer")} profile-footer`} onClick={() => selectElement("footer")} type="button" aria-label="Seleccionar footer">
                  <span>hecho con intención</span><span className="footer-mark">f</span><span className="element-tag">Footer</span>
                </button>
              </div>
            </article>
          </div>
        </div>

        <section className={`tool-sheet sheet-${sheetState}`} aria-label="Herramientas contextuales">
          <div className="sheet-handle-wrap">
            <button className="sheet-handle" onClick={() => setSheetState(sheetState === "expanded" ? "medium" : "expanded")} type="button" aria-label="Cambiar altura del panel">
              <GripHorizontal size={18} />
            </button>
            <div className="sheet-state"><span>Editar</span><span className="sheet-state-dot">·</span><span>{selectedCopy.title}</span></div>
            <button className="sheet-collapse" onClick={() => setSheetState(sheetState === "collapsed" ? "medium" : "collapsed")} type="button" aria-label={sheetState === "collapsed" ? "Expandir panel" : "Colapsar panel"}>
              {sheetState === "collapsed" ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
            </button>
          </div>
          <div className="sheet-state-switcher" aria-label="Estados de panel">
            {(["collapsed", "medium", "expanded"] as SheetState[]).map((state) => (
              <button className={sheetState === state ? "is-active" : ""} key={state} onClick={() => setSheetState(state)} type="button">
                {state === "collapsed" ? "Básico" : state === "medium" ? "Medio" : "Expandido"}
              </button>
            ))}
          </div>
          <div className="sheet-scroll">
            <div className="context-heading"><div><span className="eyebrow">{selectedCopy.eyebrow}</span><h2>{selectedCopy.title}</h2></div><button className="context-menu" type="button" aria-label="Más opciones"><SlidersHorizontal size={15} /></button></div>
            {renderContext()}
          </div>
        </section>

        <nav className="bottom-nav" aria-label="Navegación del editor">
          {tabs.map(({ label, icon: Icon }) => (
            <button className={activeTab === label ? "is-active" : ""} key={label} onClick={() => { setActiveTab(label); if (label === "Enlaces") setSelected("button"); else if (label === "Diseño") setSelected("banner"); }} type="button">
              <Icon size={17} strokeWidth={activeTab === label ? 2.1 : 1.7} />
              <span>{label}</span>
            </button>
          ))}
        </nav>
      </section>

      <div className="editor-desktop-rail right-rail" aria-hidden="true">
        <div className="rail-status"><span className="status-ring" /> CANVAS SIEMPRE VISIBLE</div>
        <div className="rail-state-card"><span className="state-card-index">01</span><strong>El lienzo es<br />la interfaz.</strong><span className="state-card-note">Panel contextual · {sheetState === "expanded" ? "48%" : sheetState === "medium" ? "34%" : "18%"} de altura</span></div>
        <div className="rail-state-card muted"><span className="state-card-index">02</span><strong>Controles que<br />siguen el contexto.</strong><span className="state-card-note">Selecciona cualquier pieza para ver su edición.</span></div>
        <div className="rail-key"><PanelBottom size={14} /><span>ARRASTRA EL PANEL<br />PARA EXPLORAR</span></div>
      </div>
    </main>
  );
}
