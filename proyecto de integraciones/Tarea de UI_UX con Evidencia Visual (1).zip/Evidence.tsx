/* Evidence-only renderer: preserves each isolated template as the visual source of truth. */
import { useMemo } from "react";
import TemplateAmanda from "../../../TemplateAmanda";
import TemplateAdriana from "../../../TemplateAdriana";
import TemplateEudora from "../../../TemplateEudora";
import TemplateLarissa from "../../../TemplateLarissa";
import TemplateBarbara from "../../../TemplateBarbara";
import TemplateAline from "../../../TemplateAline";

const assets = {
  banner: "/manus-storage/editor-banner_86eacacd.jpg",
  avatar: "/manus-storage/editor-avatar_f71a32fe.jpg",
  card: "/manus-storage/editor-card_dbbab06b.jpg",
  logo: "/manus-storage/folio-mark_a3f5cc16.png",
};

export default function Evidence() {
  const slug = window.location.pathname.split("/").filter(Boolean).pop() || "amanda";
  const template = useMemo(() => {
    const common = { avatarUrl: assets.avatar, backgroundUrl: assets.banner, logoUrl: assets.logo };
    if (slug === "adriana") return <TemplateAdriana {...common} />;
    if (slug === "eudora") return <TemplateEudora {...common} />;
    if (slug === "larissa") return <TemplateLarissa {...common} />;
    if (slug === "barbara") return <TemplateBarbara {...common} />;
    if (slug === "aline") return <TemplateAline {...common} />;
    return <TemplateAmanda {...common} />;
  }, [slug]);
  return <main className="evidence-page"><style>{`.evidence-page{min-height:100vh;background:#dedbd3;display:flex;align-items:center;justify-content:center;padding:28px;box-sizing:border-box}.evidence-frame{width:min(100%,720px);min-height:min(860px,calc(100vh - 56px));background:#f7f4ee;border:1px solid #cbc6bc;box-shadow:0 24px 70px rgba(31,29,25,.16);overflow:hidden}.evidence-label{height:34px;display:flex;justify-content:space-between;align-items:center;padding:0 17px;color:#77736b;font:800 9px Arial,sans-serif;letter-spacing:.15em;text-transform:uppercase;border-bottom:1px solid #e4e0d8;box-sizing:border-box}.evidence-label strong{color:#1d1d1b;font-weight:800}.evidence-stage{min-height:calc(min(860px,100vh - 56px) - 34px);overflow:auto}.evidence-stage>*{min-height:100%}@media(max-width:520px){.evidence-page{padding:0}.evidence-frame{min-height:100vh;border:0;box-shadow:none}.evidence-label{display:none}.evidence-stage{min-height:100vh}}`}</style><div className="evidence-frame"><div className="evidence-label"><strong>Folio / Template</strong><span>{slug}</span></div><div className="evidence-stage">{template}</div></div></main>;
}
