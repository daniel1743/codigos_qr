# Brainstorm visual — Editor móvil UI/UX

## Tres direcciones posibles

### 1. Editorial Canvas
**Very Brief Intro:** Una interfaz de edición inspirada en el diseño editorial suizo y las herramientas premium de Apple: lienzo protagonista, tipografía precisa y controles que aparecen como una bandeja de composición. Se siente serena, táctil y profesional.

**Probability:** 0.07

### 2. Soft Utility
**Very Brief Intro:** Una experiencia de herramienta ligera con superficies cálidas, módulos casi flotantes y una sensación de cuaderno digital. Prioriza claridad, accesibilidad y una lectura amable de cada control.

**Probability:** 0.03

### 3. Monochrome Studio
**Very Brief Intro:** Un estudio visual en blanco, gris y negro con contrastes de escala, estados activos oscuros y una composición más técnica. Comunica precisión y control sin volverse fría.

**Probability:** 0.09

## Dirección elegida: Editorial Canvas

### Design Movement
Diseño editorial suizo contemporáneo combinado con patrones de interacción de utilidades premium para móvil.

### Core Principles
1. **El lienzo manda:** el template permanece visible y reconocible en todo momento.
2. **Contexto antes que cantidad:** cada herramienta aparece según el elemento seleccionado.
3. **Precisión silenciosa:** la jerarquía se construye con escala tipográfica, ritmo y estados sutiles, no con color estridente.
4. **Tacto editorial:** chips horizontales, sliders delgados y superficies con profundidad mínima hacen que el panel se sienta manipulable.

### Color Philosophy
La interfaz vive en una escala de blancos cálidos, grises niebla, carbón y negro suave. El contraste oscuro se reserva para acciones, selección y lectura principal; el color no compite con el contenido editado. Un blanco marfil casi imperceptible en el lienzo diferencia la página del espacio de trabajo sin crear bloques pesados.

### Layout Paradigm
Composición vertical asimétrica de tres bandas: header mínimo, canvas flexible y bottom sheet contextual. El canvas usa un marco de “escenario” con escala adaptativa; el panel tiene altura limitada y scroll propio. La navegación queda integrada en el borde inferior como una barra ligera, nunca como un dashboard.

### Signature Elements
- **Cinta de estado vertical:** una línea negra fina al costado del canvas que indica el elemento seleccionado.
- **Handles editoriales:** pequeños puntos y rings de selección, casi como marcas de maquetación.
- **Bottom sheet en papel:** panel blanco cálido con handle, sombra difusa y grupos de control separados por aire.

### Interaction Philosophy
Las interacciones confirman la edición sin sacarla del contexto: tocar una pieza mantiene el template visible, marca el objetivo y abre abajo únicamente sus controles. Cambiar entre Perfil, Enlaces, Diseño y Galería conserva la misma superficie de edición, alterando solo el foco de herramientas.

### Animation
Transiciones rápidas y discretas, entre 160 y 260 ms, con ease-out personalizado. El canvas reduce su escala suavemente cuando el sheet crece; los chips activos cambian por contraste y microdesplazamiento, no por destellos. El panel entra desde abajo con una elevación corta y la selección del lienzo aparece con opacity + ring, respetando `prefers-reduced-motion`.

### Typography System
- **Display / títulos:** DM Sans, 700–800, con tracking ligeramente negativo para el header y los nombres de sección.
- **UI / lectura:** Manrope, 400–700, para labels, microcopy y controles.
- **Regla:** títulos compactos en carbón; secundarios en gris medio; labels con mayúsculas pequeñas y tracking amplio solo en metadatos.

### Brand Essence
Un editor móvil de páginas personales para creadores que quieren ver el resultado mientras diseñan, sin entrar en un formulario complejo. **Personalidad:** sobrio, táctil, exacto.

### Brand Voice
Los headlines y CTAs son cortos, seguros y concretos; las microcopias orientan sin explicar de más.

- “Diseña sobre la página, no alrededor de ella.”
- “Ajusta el detalle. Mantén la vista.”

### Wordmark & Logo
Marca conceptual **folio**: un rectángulo abierto por una esquina, combinado con una línea vertical que recuerda el margen de una página. El símbolo se usa sin texto en el header y como favicon; el wordmark utiliza una ligadura personalizada entre “fi” y una “o” abierta, nunca un texto genérico.

### Signature Brand Color
**Carbón de margen — `#1D1D1B`**. Es el color propio de las marcas de selección, los iconos activos y los controles de acción; funciona como la tinta que une el lienzo con la herramienta.

## Regla de decisión
Antes de añadir cualquier elemento, comprobar: **¿refuerza la edición directa sobre el lienzo o la convierte en un formulario?** Si la respuesta es lo segundo, se elimina o se reduce.
