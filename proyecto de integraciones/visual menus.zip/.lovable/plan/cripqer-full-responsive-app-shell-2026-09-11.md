# CRIPQER Full Responsive App Shell

## Objetivo
Crear una referencia visual responsive del producto completo, manteniendo el Power Editor existente como experiencia inmersiva y sin implementar lógica real.

## Alcance visual
- Shell autenticado con navegación jerárquica para Inicio, Mi página, Editor, Documentos y Perfil.
- Vistas mínimas solicitadas con datos simulados: dashboard, gestión de página y QR, publicación, documentos, detalle, cuenta, Basic Editor y cambios de modo.
- Adaptación real por formato: sidebar en escritorio, navegación compacta en tablet y barra inferior en móvil.
- Entrada directa a Power, selector local Power/Básico y aviso visual al cambiar a Básico.
- Estados visuales simulados para copiar, publicar, guardar, compartir y crear documento.

## Preservación
- No modificar el interior visual del Power Editor aprobado; únicamente integrarlo como modo inmersivo del shell.
- Sin backend, base de datos, autenticación, APIs, persistencia, routing funcional ni engines.
- Sin nuevas funciones de producto fuera del brief.

## Técnica
- Mantener la implementación autocontenida y basada en estado local/mock data.
- Reutilizar pocos componentes visuales para navegación, encabezados, tabs, botones, estados y diálogos.
- Exponer los estados necesarios para QA visual en los viewports indicados.

## Validación
- Revisar accesibilidad visual, targets táctiles, overflow y ausencia de solapamientos.
- Capturar los estados mínimos en 360×800, 390×844, 430×932, 834×1112, 1112×834, 1366×768, 1440×900 y 1920×1080.
