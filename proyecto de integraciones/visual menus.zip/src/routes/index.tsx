import { createFileRoute } from "@tanstack/react-router";

import CripqerAppShell from "@/components/app/CripqerAppShell";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cripqer — App Shell Responsive" },
      {
        name: "description",
        content:
          "Referencia visual responsive de Cripqer para gestionar la página, QR, documentos cifrados, perfil y modos de edición.",
      },
      { property: "og:title", content: "Cripqer — App Shell Responsive" },
      {
        property: "og:description",
        content:
          "Prototipo visual completo de la experiencia Cripqer en escritorio, tablet y móvil.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CripqerAppShell,
});
