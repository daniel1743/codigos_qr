import { useEffect, useState, type ReactNode } from "react";
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  Bell,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Copy,
  Download,
  ExternalLink,
  Eye,
  FileLock2,
  Globe2,
  Home,
  Image,
  LayoutTemplate,
  Link2,
  LockKeyhole,
  
  MoreHorizontal,
  Paintbrush,
  Pencil,
  Plus,
  QrCode,
  Rocket,
  ScanLine,
  Settings,
  Share2,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Upload,
  User,
  X,
  type LucideIcon,
} from "lucide-react";

import PowerEditor from "@/components/editor/PowerEditor";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type View =
  | "dashboard"
  | "page-summary"
  | "page-preview"
  | "page-publish"
  | "page-qr"
  | "page-share"
  | "documents"
  | "document-detail"
  | "profile"
  | "basic"
  | "power";

const viewFromQuery = (): View => {
  if (typeof window === "undefined") return "dashboard";
  const value = new URLSearchParams(window.location.search).get("view") as View | null;
  return value ?? "dashboard";
};

const PAGE_TABS: { id: View; label: string }[] = [
  { id: "page-summary", label: "Resumen" },
  { id: "page-preview", label: "Ver página" },
  { id: "page-publish", label: "Publicación" },
  { id: "page-qr", label: "QR" },
  { id: "page-share", label: "Compartir" },
];

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex min-w-0 items-center gap-3">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-app-primary text-sm font-bold text-app-primary-foreground">
        C
      </span>
      {!compact ? (
        <div className="min-w-0">
          <p className="truncate font-ui text-[15px] font-bold tracking-[0.08em] text-app-ink">CRIPQER</p>
          <p className="truncate text-[10px] text-app-muted">Workspace personal</p>
        </div>
      ) : null}
    </div>
  );
}

function StatusBadge({ children, tone = "success" }: { children: ReactNode; tone?: "success" | "warning" | "neutral" }) {
  const tones = {
    success: "bg-app-success-soft text-app-success",
    warning: "bg-app-warning-soft text-app-warning",
    neutral: "bg-app-soft text-app-muted",
  };
  return (
    <span className={cn("inline-flex h-7 items-center gap-1.5 rounded-full px-2.5 text-xs font-semibold", tones[tone])}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {children}
    </span>
  );
}

function AppSidebar({ view, onView, compact = false }: { view: View; onView: (view: View) => void; compact?: boolean }) {
  const pageActive = view.startsWith("page-");
  return (
    <aside className={cn("hidden h-[100dvh] shrink-0 flex-col border-r border-app-line bg-app-sidebar lg:flex", compact ? "w-[84px]" : "w-[244px]")}>
      <div className="flex h-20 items-center px-5"><BrandMark compact={compact} /></div>
      <nav className="flex-1 space-y-1 px-3" aria-label="Navegación principal">
        <SidebarItem icon={Home} label="Inicio" active={view === "dashboard"} compact={compact} onClick={() => onView("dashboard")} />
        <SidebarItem icon={Globe2} label="Mi página" active={pageActive} compact={compact} onClick={() => onView("page-summary")} endIcon={ChevronDown} />
        {!compact && pageActive ? (
          <div className="ml-5 border-l border-app-line pl-3 py-1">
            {PAGE_TABS.map((tab) => (
              <Button key={tab.id} variant="ghost" onClick={() => onView(tab.id)} className={cn("h-8 w-full justify-start px-2 text-xs", view === tab.id ? "bg-app-primary-soft text-app-primary" : "text-app-muted")}>
                {tab.label}
              </Button>
            ))}
          </div>
        ) : null}
        <SidebarItem icon={Pencil} label="Editor" active={view === "basic"} compact={compact} onClick={() => onView("power")} endIcon={ChevronRight} />
        
        <SidebarItem icon={FileLock2} label="Documentos" active={view === "documents" || view === "document-detail"} compact={compact} onClick={() => onView("documents")} />
      </nav>
      <div className="space-y-1 border-t border-app-line p-3">
        <SidebarItem icon={User} label="Perfil" active={view === "profile"} compact={compact} onClick={() => onView("profile")} />
        <SidebarItem icon={Settings} label="Ajustes" compact={compact} onClick={() => onView("profile")} />
        <div className={cn("mt-3 flex items-center gap-3 rounded-lg bg-app-soft p-2", compact && "justify-center")}>
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-app-avatar text-xs font-bold text-app-primary">DF</span>
          {!compact ? <div className="min-w-0"><p className="truncate text-xs font-semibold text-app-ink">Daniel Falcon</p><p className="truncate text-[10px] text-app-muted">Plan Pro</p></div> : null}
        </div>
      </div>
    </aside>
  );
}

function SidebarItem({ icon: Icon, label, active, compact, onClick, endIcon: EndIcon }: { icon: LucideIcon; label: string; active?: boolean; compact?: boolean; onClick: () => void; endIcon?: LucideIcon }) {
  return (
    <Button variant="ghost" onClick={onClick} title={label} className={cn("relative h-11 w-full px-3", compact ? "justify-center" : "justify-start", active ? "bg-app-primary-soft text-app-primary" : "text-app-muted hover:bg-app-soft hover:text-app-ink")}>
      {active ? <span className="absolute inset-y-2 left-0 w-0.5 rounded-full bg-app-primary" /> : null}
      <Icon className="h-[18px] w-[18px]" />
      {!compact ? <span>{label}</span> : null}
      {!compact && EndIcon ? <EndIcon className="ml-auto h-3.5 w-3.5" /> : null}
    </Button>
  );
}

function MobileNav({ view, onView }: { view: View; onView: (view: View) => void }) {
  const items: { label: string; icon: LucideIcon; target: View; active: boolean }[] = [
    { label: "Inicio", icon: Home, target: "dashboard", active: view === "dashboard" },
    { label: "Página", icon: Globe2, target: "page-summary", active: view.startsWith("page-") },
    { label: "Editar", icon: Pencil, target: "power", active: false },
    { label: "Docs", icon: FileLock2, target: "documents", active: view === "documents" || view === "document-detail" },
    { label: "Perfil", icon: User, target: "profile", active: view === "profile" },
  ];
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 grid h-[72px] grid-cols-5 border-t border-app-line bg-app-surface/95 px-1 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden" aria-label="Navegación móvil">
      {items.map((item) => (
        <Button key={item.label} variant="ghost" onClick={() => onView(item.target)} className={cn("h-full min-w-0 flex-col gap-1 rounded-none px-1 text-[10px]", item.active ? "text-app-primary" : "text-app-muted")}>
          <span className={cn("grid h-8 w-11 place-items-center rounded-full", item.active && "bg-app-primary-soft")}><item.icon className="h-5 w-5" /></span>
          {item.label}
        </Button>
      ))}
    </nav>
  );
}

function AppHeader({ title, eyebrow }: { title: string; eyebrow?: string | undefined }) {
  return (
    <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b border-app-line bg-app-surface px-4 py-3 sm:px-6 lg:px-8">
      <div className="min-w-0">
        {eyebrow ? <p className="truncate text-[11px] font-semibold uppercase tracking-[0.1em] text-app-muted">{eyebrow}</p> : null}
        <h1 className="truncate font-ui text-xl font-semibold text-app-ink sm:text-2xl">{title}</h1>
      </div>
      <div className="flex shrink-0 items-center gap-1 sm:gap-2">
        <Button variant="ghost" size="icon" className="h-11 w-11 text-app-muted" aria-label="Notificaciones"><Bell /></Button>
        <span className="hidden h-9 w-px bg-app-line sm:block" />
        <span className="grid h-10 w-10 place-items-center rounded-full bg-app-avatar text-xs font-bold text-app-primary">DF</span>
      </div>
    </header>
  );
}

function PageHeader({ title, description, action }: { title: string; description: string; action?: ReactNode }) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4">
      <div className="min-w-0"><h2 className="font-ui text-2xl font-semibold text-app-ink sm:text-3xl">{title}</h2><p className="mt-1 max-w-2xl text-sm text-app-muted">{description}</p></div>
      {action}
    </div>
  );
}

function Metric({ label, value, change, icon: Icon }: { label: string; value: string; change: string; icon: LucideIcon }) {
  return (
    <article className="border-t border-app-line py-5">
      <div className="flex items-center justify-between"><p className="text-sm text-app-muted">{label}</p><Icon className="h-4 w-4 text-app-faint" /></div>
      <div className="mt-3 flex items-end justify-between gap-2"><strong className="font-ui text-3xl font-semibold text-app-ink">{value}</strong><span className="flex items-center gap-1 text-xs font-semibold text-app-success"><TrendingUp className="h-3.5 w-3.5" />{change}</span></div>
    </article>
  );
}

function QuickAction({ icon: Icon, label, detail, onClick, primary }: { icon: LucideIcon; label: string; detail: string; onClick: () => void; primary?: boolean }) {
  return (
    <Button variant="ghost" onClick={onClick} className={cn("h-auto min-h-[78px] w-full justify-start gap-3 whitespace-normal rounded-lg border p-3 text-left", primary ? "border-app-primary bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong hover:text-app-primary-foreground" : "border-app-line bg-app-surface text-app-ink hover:bg-app-soft")}>
      <span className={cn("grid h-10 w-10 shrink-0 place-items-center rounded-lg", primary ? "bg-app-primary-foreground/15" : "bg-app-primary-soft text-app-primary")}><Icon className="h-5 w-5" /></span>
      <span className="min-w-0"><span className="block text-sm font-semibold">{label}</span><span className={cn("mt-0.5 block text-xs font-normal", primary ? "text-app-primary-foreground/75" : "text-app-muted")}>{detail}</span></span>
      <ArrowRight className="ml-auto h-4 w-4 shrink-0" />
    </Button>
  );
}

function Dashboard({ onView }: { onView: (view: View) => void }) {
  return (
    <div className="space-y-7">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div><p className="text-sm text-app-muted">Viernes, 11 de septiembre</p><h2 className="mt-1 font-ui text-3xl font-semibold text-app-ink sm:text-4xl">Hola, Daniel</h2><p className="mt-2 text-sm text-app-muted">Tu página está activa y recibiendo visitas.</p></div>
        <Button onClick={() => onView("power")} className="h-11 bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong"><Pencil />Editar página</Button>
      </div>
      <section className="grid gap-5 border-y border-app-line py-5 md:grid-cols-[1.25fr_2fr]">
        <div className="flex min-w-0 items-center gap-4 md:border-r md:border-app-line md:pr-6">
          <PageMiniature />
          <div className="min-w-0"><StatusBadge>Publicada</StatusBadge><h3 className="mt-2 truncate font-ui text-lg font-semibold text-app-ink">Mi página Cripqer</h3><p className="mt-1 truncate text-xs text-app-muted">cripqer.com/daniel</p><p className="mt-3 text-xs text-app-faint">Actualizada hace 2 h</p></div>
        </div>
        <div className="grid grid-cols-2 gap-x-6 md:grid-cols-3"><Metric label="Visitas" value="1,284" change="12%" icon={Eye} /><Metric label="Escaneos QR" value="327" change="8%" icon={ScanLine} /><div className="col-span-2 md:col-span-1"><Metric label="Compartidos" value="86" change="5%" icon={Share2} /></div></div>
      </section>
      <section><h3 className="mb-3 text-sm font-semibold text-app-ink">Acciones rápidas</h3><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><QuickAction icon={Pencil} label="Editar página" detail="Abrir Power Editor" primary onClick={() => onView("power")} /><QuickAction icon={ExternalLink} label="Ver página" detail="Vista publicada" onClick={() => onView("page-preview")} /><QuickAction icon={QrCode} label="Ver QR" detail="Gestionar y descargar" onClick={() => onView("page-qr")} /><QuickAction icon={FileLock2} label="Crear documento" detail="Documento cifrado" onClick={() => onView("documents")} /></div></section>
      <section className="grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        <div><div className="mb-3 flex items-center justify-between"><h3 className="text-sm font-semibold text-app-ink">Actividad reciente</h3><Button variant="ghost" size="sm" className="text-app-primary">Ver todo</Button></div><div className="divide-y divide-app-line border-y border-app-line">{[[Rocket,"Página publicada","Hoy, 18:42"],[QrCode,"18 nuevos escaneos","Hoy, 14:10"],[FileLock2,"Propuesta comercial creada","Ayer, 09:32"]].map(([Icon,label,time]) => { const I = Icon as LucideIcon; return <div key={label as string} className="flex items-center gap-3 py-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-app-soft text-app-muted"><I className="h-4 w-4" /></span><p className="min-w-0 flex-1 truncate text-sm font-medium text-app-ink">{label as string}</p><time className="shrink-0 text-xs text-app-faint">{time as string}</time></div>; })}</div></div>
        <div className="rounded-lg bg-app-ink p-5 text-app-surface"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-app-surface/60">Plan Pro</p><h3 className="mt-2 font-ui text-xl font-semibold">Todo listo para crecer.</h3><p className="mt-2 text-sm text-app-surface/65">Tus herramientas principales están activas.</p><Button variant="outline" className="mt-5 border-app-surface/20 bg-transparent text-app-surface hover:bg-app-surface/10 hover:text-app-surface">Ver mi plan</Button></div>
      </section>
    </div>
  );
}

function PageMiniature({ large = false }: { large?: boolean }) {
  return <div className={cn("relative shrink-0 overflow-hidden rounded-lg border border-app-line bg-app-preview", large ? "aspect-[4/3] w-full" : "h-28 w-20")}><div className="h-[42%] bg-app-preview-accent" /><div className="absolute inset-x-[14%] top-[30%] rounded-md bg-app-surface p-2 shadow-sm"><div className="mx-auto h-8 w-8 rounded-full bg-app-avatar" /><div className="mx-auto mt-2 h-1.5 w-2/3 rounded bg-app-ink/75" /><div className="mx-auto mt-1 h-1 w-4/5 rounded bg-app-line-strong" /><div className="mt-3 h-5 rounded bg-app-primary" /></div></div>;
}

function LocalTabs({ view, onView }: { view: View; onView: (view: View) => void }) {
  return <div className="-mx-4 overflow-x-auto border-b border-app-line px-4 sm:mx-0 sm:px-0"><nav className="flex min-w-max gap-1" aria-label="Secciones de Mi página">{PAGE_TABS.map((tab) => <Button key={tab.id} variant="ghost" onClick={() => onView(tab.id)} className={cn("h-12 rounded-none border-b-2 px-4 text-sm", view === tab.id ? "border-app-primary text-app-primary" : "border-transparent text-app-muted")}>{tab.label}</Button>)}</nav></div>;
}

function PageSummary({ onView }: { onView: (view: View) => void }) {
  return <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_360px]"><div className="space-y-7"><PageHeader title="Tu página está publicada" description="Todo está actualizado. Comparte tu enlace o continúa editando cuando quieras." action={<StatusBadge>Publicada</StatusBadge>} /><div className="border-y border-app-line py-5"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-app-muted">URL pública</p><div className="mt-2 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2"><p className="truncate font-ui text-lg font-medium text-app-ink">cripqer.com/daniel</p><Button variant="outline" size="icon" className="h-11 w-11" aria-label="Copiar enlace"><Copy /></Button></div><p className="mt-2 text-xs text-app-faint">Última publicación hoy, 18:42</p></div><div className="grid gap-3 sm:grid-cols-2"><QuickAction icon={ExternalLink} label="Ver página" detail="Abrir vista publicada" onClick={() => onView("page-preview")} /><QuickAction icon={Pencil} label="Editar" detail="Abrir Power Editor" primary onClick={() => onView("power")} /><QuickAction icon={QrCode} label="Mi QR" detail="Personalizar y descargar" onClick={() => onView("page-qr")} /><QuickAction icon={Share2} label="Compartir" detail="Copiar enlace o enviar" onClick={() => onView("page-share")} /></div></div><aside><p className="mb-3 text-sm font-semibold text-app-ink">Vista de tu página</p><PageMiniature large /><p className="mt-3 text-center text-xs text-app-faint">Vista previa de la versión publicada</p></aside></div>;
}

function PagePreview({ onView }: { onView: (view: View) => void }) {
  return <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_300px]"><div className="overflow-hidden rounded-lg border border-app-line bg-app-soft p-3 sm:p-6"><div className="mx-auto max-w-3xl overflow-hidden rounded-lg border border-app-line bg-app-surface shadow-sm"><div className="flex h-10 items-center gap-1.5 border-b border-app-line px-3"><i className="h-2 w-2 rounded-full bg-app-line-strong" /><i className="h-2 w-2 rounded-full bg-app-line-strong" /><i className="h-2 w-2 rounded-full bg-app-line-strong" /><span className="ml-2 text-[10px] text-app-faint">cripqer.com/daniel</span></div><div className="h-44 bg-app-preview-accent" /><div className="mx-auto -mt-12 max-w-md px-6 pb-12 text-center"><div className="mx-auto h-24 w-24 rounded-full border-4 border-app-surface bg-app-avatar" /><h3 className="mt-4 font-ui text-2xl font-semibold text-app-ink">Daniel Falcon</h3><p className="mt-2 text-sm text-app-muted">Diseño, tecnología y productos que conectan.</p><div className="mt-6 space-y-2"><div className="h-11 rounded-lg bg-app-primary" /><div className="h-11 rounded-lg bg-app-soft" /></div></div></div></div><aside className="space-y-3"><h3 className="font-ui text-lg font-semibold text-app-ink">Página publicada</h3><p className="text-sm text-app-muted">Esta es la vista que pueden abrir tus visitantes.</p><Button className="h-11 w-full bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong"><ExternalLink />Abrir página</Button><Button variant="outline" className="h-11 w-full" onClick={() => onView("power")}><Pencil />Editar</Button><Button variant="ghost" className="h-11 w-full" onClick={() => onView("page-share")}><Share2 />Compartir</Button></aside></div>;
}

function PublishView() {
  return <div className="mx-auto max-w-3xl"><div className="flex items-start gap-4 border-b border-app-line pb-6"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-app-success-soft text-app-success"><Check className="h-6 w-6" /></span><div><StatusBadge>Publicada</StatusBadge><h2 className="mt-3 font-ui text-3xl font-semibold text-app-ink">Tu página está al día</h2><p className="mt-2 text-sm text-app-muted">La última versión se publicó hoy a las 18:42 y está disponible para todos.</p></div></div><div className="grid gap-6 py-7 sm:grid-cols-2"><div><p className="text-xs font-semibold uppercase tracking-[0.1em] text-app-muted">Versión publicada</p><p className="mt-2 text-sm font-semibold text-app-ink">11 septiembre 2026 · 18:42</p><p className="mt-1 text-xs text-app-faint">Sin cambios pendientes</p></div><div><p className="text-xs font-semibold uppercase tracking-[0.1em] text-app-muted">Dirección</p><p className="mt-2 text-sm font-semibold text-app-ink">cripqer.com/daniel</p><Button variant="link" className="h-auto p-0 text-app-primary"><ExternalLink />Abrir página</Button></div></div><div className="rounded-lg border border-app-line bg-app-soft p-5"><h3 className="font-ui text-lg font-semibold text-app-ink">Cuando hagas cambios</h3><p className="mt-1 text-sm text-app-muted">Podrás revisar la vista previa y actualizar esta versión. Nada cambia hasta que publiques.</p><Button className="mt-5 h-11 bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong"><Rocket />Publicar actualización</Button></div></div>;
}

function MockQr() {
  const cells = [1,1,1,0,1,0,1,1,1,1,0,1,0,1,0,1,0,0,1,1,1,0,1,0,1,1,0,0,1,0,1,0,1,1,1,0,1,0,1,1,1,1,0,1,0,0,1,0,1];
  return <div className="grid aspect-square w-full grid-cols-7 gap-1 rounded-lg bg-app-surface p-4" aria-label="Vista previa visual del código QR">{cells.map((on, i) => <span key={i} className={cn("rounded-[2px]", on ? "bg-app-ink" : "bg-transparent")} />)}</div>;
}

function QrView() {
  return <div className="grid gap-7 xl:grid-cols-[340px_minmax(0,1fr)]"><aside className="rounded-lg bg-app-ink p-6 text-app-surface"><p className="text-xs font-semibold uppercase tracking-[0.12em] text-app-surface/60">Mi QR</p><div className="mx-auto mt-5 max-w-[230px]"><MockQr /></div><div className="mt-5 flex items-center justify-between"><div><p className="text-sm font-semibold">Página principal</p><p className="text-xs text-app-surface/60">Activo</p></div><StatusBadge>Conectado</StatusBadge></div></aside><div className="space-y-7"><PageHeader title="Gestiona tu código QR" description="Personaliza su apariencia, revisa su destino y consulta su uso." /><section className="grid gap-5 border-y border-app-line py-5 md:grid-cols-2"><div><p className="text-xs font-semibold uppercase tracking-[0.1em] text-app-muted">Destino</p><div className="mt-2 flex items-center gap-2"><p className="min-w-0 flex-1 truncate text-sm font-semibold text-app-ink">cripqer.com/daniel</p><Button variant="outline" size="icon" className="h-11 w-11" aria-label="Copiar destino"><Copy /></Button></div></div><div className="flex flex-wrap items-end gap-2 md:justify-end"><Button variant="outline" className="h-11"><Paintbrush />Editar QR</Button><Button variant="outline" className="h-11"><Share2 />Compartir</Button><Button className="h-11 bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong"><Download />Descargar</Button></div></section><section className="grid gap-6 md:grid-cols-2"><div><h3 className="text-sm font-semibold text-app-ink">Apariencia</h3><div className="mt-3 space-y-4 rounded-lg border border-app-line p-4"><div className="flex items-center justify-between"><span className="text-sm text-app-muted">Color principal</span><span className="grid h-11 w-11 place-items-center rounded-lg border border-app-line"><i className="h-6 w-6 rounded-md bg-app-ink" /></span></div><div className="flex items-center justify-between"><span className="text-sm text-app-muted">Fondo</span><span className="grid h-11 w-11 place-items-center rounded-lg border border-app-line"><i className="h-6 w-6 rounded-md border border-app-line bg-app-surface" /></span></div><div className="flex items-center justify-between"><span className="text-sm text-app-muted">Estilo</span><span className="text-sm font-semibold text-app-ink">Redondeado</span></div></div></div><div><h3 className="text-sm font-semibold text-app-ink">Estadísticas</h3><div className="mt-3 grid grid-cols-2 gap-4"><div className="border-t border-app-line pt-4"><p className="text-xs text-app-muted">Escaneos</p><p className="mt-2 font-ui text-3xl font-semibold text-app-ink">327</p></div><div className="border-t border-app-line pt-4"><p className="text-xs text-app-muted">Esta semana</p><p className="mt-2 font-ui text-3xl font-semibold text-app-ink">48</p></div></div><div className="mt-5 flex h-24 items-end gap-2">{[35,48,42,67,55,78,88].map((h,i) => <span key={i} className="flex-1 rounded-t bg-app-primary-soft" style={{height:`${h}%`}}><span className="block h-1.5 rounded-full bg-app-primary" /></span>)}</div></div></section><section><h3 className="text-sm font-semibold text-app-ink">Formato de descarga</h3><div className="mt-3 flex flex-wrap gap-2">{["PNG","SVG","PDF"].map((format,i)=><Button key={format} variant={i===0?"default":"outline"} className={cn("h-11", i===0 && "bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong")}>{format}</Button>)}</div></section></div></div>;
}

function ShareView() {
  return <div className="mx-auto max-w-2xl"><PageHeader title="Comparte tu página" description="Usa el enlace público o elige una forma rápida de compartir." /><div className="mt-7 rounded-lg border border-app-line p-4"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-app-muted">Enlace público</p><div className="mt-2 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2"><p className="truncate text-sm font-semibold text-app-ink">https://cripqer.com/daniel</p><Button className="h-11 bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong"><Copy />Copiar</Button></div></div><div className="mt-4 grid gap-3 sm:grid-cols-3"><QuickAction icon={Share2} label="Compartir" detail="Abrir opciones" onClick={() => {}} /><QuickAction icon={QrCode} label="Código QR" detail="Mostrar QR" onClick={() => {}} /><QuickAction icon={ExternalLink} label="Abrir" detail="Ver página" onClick={() => {}} /></div></div>;
}

const documents = [
  { name: "Propuesta comercial 2026", date: "Hoy, 09:32", status: "Activo", access: "12 accesos" },
  { name: "Contrato de servicios", date: "8 sep 2026", status: "Activo", access: "7 accesos" },
  { name: "Dossier confidencial", date: "2 sep 2026", status: "Borrador", access: "Sin actividad" },
];

function DocumentsView({ onView, onCreate }: { onView: (view: View) => void; onCreate: () => void }) {
  return <div className="space-y-6"><PageHeader title="Documentos cifrados" description="Organiza y comparte archivos protegidos desde un solo lugar." action={<Button onClick={onCreate} className="h-11 bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong"><Plus />Crear <span className="hidden sm:inline">documento</span></Button>} /><div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-y border-app-line py-3"><p className="text-sm text-app-muted">3 documentos</p><Button variant="outline" size="icon" className="h-11 w-11" aria-label="Más opciones"><MoreHorizontal /></Button></div><div className="divide-y divide-app-line border-b border-app-line">{documents.map((doc) => <Button key={doc.name} variant="ghost" onClick={() => onView("document-detail")} className="grid h-auto min-h-[78px] w-full grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-none px-0 text-left hover:bg-app-soft"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-app-primary-soft text-app-primary"><FileLock2 className="h-5 w-5" /></span><span className="min-w-0"><span className="block truncate text-sm font-semibold text-app-ink">{doc.name}</span><span className="mt-1 block text-xs font-normal text-app-muted">{doc.date} · {doc.access}</span></span><span className="flex items-center gap-3"><StatusBadge tone={doc.status === "Borrador" ? "neutral" : "success"}>{doc.status}</StatusBadge><ChevronRight className="hidden h-4 w-4 text-app-faint sm:block" /></span></Button>)}</div></div>;
}

function DocumentDetail({ onView }: { onView: (view: View) => void }) {
  return <div className="space-y-7"><Button variant="ghost" onClick={() => onView("documents")} className="h-10 px-0 text-app-muted hover:bg-transparent hover:text-app-ink"><ArrowLeft />Documentos</Button><PageHeader title="Propuesta comercial 2026" description="Documento cifrado · Actualizado hoy, 09:32" action={<StatusBadge>Activo</StatusBadge>} /><div className="grid gap-7 xl:grid-cols-[minmax(0,1fr)_320px]"><div className="grid min-h-[360px] place-items-center rounded-lg border border-app-line bg-app-soft p-6"><div className="text-center"><span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-app-primary-soft text-app-primary"><LockKeyhole className="h-7 w-7" /></span><h3 className="mt-4 font-ui text-xl font-semibold text-app-ink">Vista protegida</h3><p className="mt-2 text-sm text-app-muted">El contenido se mostrará aquí al abrir el documento.</p><Button variant="outline" className="mt-5 h-11"><Eye />Ver documento</Button></div></div><aside className="space-y-5"><div><p className="text-xs font-semibold uppercase tracking-[0.1em] text-app-muted">Acceso y seguridad</p><div className="mt-3 space-y-3 border-y border-app-line py-4"><div className="flex items-center justify-between text-sm"><span className="text-app-muted">Protección</span><span className="font-semibold text-app-ink">Enlace seguro</span></div><div className="flex items-center justify-between text-sm"><span className="text-app-muted">Estado</span><StatusBadge>Activo</StatusBadge></div></div></div><div className="grid grid-cols-2 gap-2"><Button variant="outline" className="h-11"><QrCode />QR</Button><Button variant="outline" className="h-11"><Share2 />Compartir</Button><Button variant="outline" className="col-span-2 h-11"><Download />Descargar QR</Button></div><div className="rounded-lg bg-app-soft p-4"><p className="text-xs text-app-muted">Actividad</p><p className="mt-1 font-ui text-2xl font-semibold text-app-ink">12 accesos</p><p className="mt-1 text-xs text-app-faint">Último acceso hace 3 horas</p></div></aside></div></div>;
}

function ProfileView({ onView }: { onView: (view: View) => void }) {
  const sections = [["Mis datos",User,"Nombre y correo de la cuenta"],["Seguridad",ShieldCheck,"Contraseña y acceso"],["Plan",Sparkles,"Plan Pro activo"],["Ajustes",Settings,"Preferencias generales"],["Ayuda",CircleHelp,"Centro de ayuda"]] as const;
  return <div className="grid gap-8 xl:grid-cols-[minmax(0,1fr)_320px]"><div><div className="flex items-center gap-4 border-b border-app-line pb-6"><span className="grid h-16 w-16 shrink-0 place-items-center rounded-full bg-app-avatar font-ui text-lg font-bold text-app-primary">DF</span><div className="min-w-0"><h2 className="truncate font-ui text-2xl font-semibold text-app-ink">Daniel Falcon</h2><p className="truncate text-sm text-app-muted">daniel@cripqer.com</p></div><Button variant="outline" className="ml-auto hidden h-11 sm:inline-flex">Editar perfil</Button></div><div className="divide-y divide-app-line">{sections.map(([label,Icon,detail]) => <Button key={label} variant="ghost" className="grid h-[72px] w-full grid-cols-[auto_minmax(0,1fr)_auto] gap-3 rounded-none px-0 text-left hover:bg-app-soft"><Icon className="h-5 w-5 text-app-primary" /><span className="min-w-0"><span className="block text-sm font-semibold text-app-ink">{label}</span><span className="block truncate text-xs font-normal text-app-muted">{detail}</span></span><ChevronRight className="h-4 w-4 text-app-faint" /></Button>)}</div><Button variant="ghost" className="mt-5 h-11 text-app-danger hover:bg-app-danger-soft hover:text-app-danger">Cerrar sesión</Button></div><aside><h3 className="text-sm font-semibold text-app-ink">Accesos rápidos</h3><div className="mt-3 space-y-2"><QuickAction icon={ExternalLink} label="Ver mi página" detail="Página publicada" onClick={() => onView("page-preview")} /><QuickAction icon={QrCode} label="Ver mi QR" detail="Mi página · QR" onClick={() => onView("page-qr")} /><QuickAction icon={Pencil} label="Editar mi página" detail="Abrir Power Editor" onClick={() => onView("power")} /></div><div className="mt-8 border-t border-app-line pt-5"><BrandMark /><p className="mt-3 text-xs text-app-faint">Versión 1.0.0 · 2026</p></div></aside></div>;
}

function ModeSelector({ mode, onPower, onBasic }: { mode: "power" | "basic"; onPower: () => void; onBasic: () => void }) {
  return <div className="inline-flex rounded-lg border border-app-line bg-app-soft p-1"><Button variant="ghost" onClick={onPower} className={cn("h-9 px-4", mode === "power" ? "bg-app-surface text-app-primary shadow-sm" : "text-app-muted")}><span className="h-2 w-2 rounded-full bg-current" />Power</Button><Button variant="ghost" onClick={onBasic} className={cn("h-9 px-4", mode === "basic" ? "bg-app-surface text-app-primary shadow-sm" : "text-app-muted")}>Básico</Button></div>;
}

function BasicEditor({ onPower }: { onPower: () => void }) {
  const [section, setSection] = useState("Perfil");
  return <div className="min-h-[calc(100dvh-145px)]"><div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b border-app-line pb-5"><div><p className="text-xs font-semibold uppercase tracking-[0.1em] text-app-muted">Modo de edición</p><h2 className="mt-1 font-ui text-2xl font-semibold text-app-ink">Editor básico</h2></div><ModeSelector mode="basic" onPower={onPower} onBasic={() => {}} /></div><div className="grid gap-6 py-6 lg:grid-cols-[180px_minmax(0,1fr)_320px]"><nav className="flex gap-1 overflow-x-auto lg:flex-col">{["Perfil","Enlaces","Diseño","Plantillas","Compartir"].map((item) => <Button key={item} variant="ghost" onClick={() => setSection(item)} className={cn("h-11 shrink-0 justify-start", section === item ? "bg-app-primary-soft text-app-primary" : "text-app-muted")}><span className="grid h-6 w-6 place-items-center">{item === "Perfil" ? <User /> : item === "Diseño" ? <Paintbrush /> : item === "Plantillas" ? <LayoutTemplate /> : item === "Compartir" ? <Share2 /> : <Link2 />}</span>{item}</Button>)}</nav><div className="space-y-5"><div><h3 className="font-ui text-xl font-semibold text-app-ink">{section}</h3><p className="mt-1 text-sm text-app-muted">Edita la información esencial de tu página de forma sencilla.</p></div><div className="space-y-4 rounded-lg border border-app-line p-5"><div className="flex items-center gap-4"><span className="grid h-16 w-16 place-items-center rounded-full bg-app-avatar text-app-primary"><User className="h-6 w-6" /></span><Button variant="outline" className="h-11"><Upload />Cambiar foto</Button></div>{[["Nombre","Daniel Falcon"],["Biografía","Diseño, tecnología y productos que conectan."],["Enlace principal","cripqer.com/daniel"]].map(([label,value]) => <label key={label} className="block"><span className="text-xs font-semibold text-app-muted">{label}</span><span className="mt-1.5 flex min-h-11 items-center rounded-lg border border-app-line bg-app-surface px-3 text-sm text-app-ink">{value}</span></label>)}<Button className="h-11 bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong">Guardar cambios</Button></div></div><aside className="hidden lg:block"><p className="mb-3 text-sm font-semibold text-app-ink">Vista previa</p><PageMiniature large /><Button variant="ghost" onClick={onPower} className="mt-4 h-11 w-full text-app-primary"><Sparkles />Ir a edición avanzada</Button></aside></div></div>;
}

function CreateDocumentDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;
  return <div className="fixed inset-0 z-50 grid place-items-end bg-app-overlay p-0 sm:place-items-center sm:p-4"><div role="dialog" aria-modal="true" aria-labelledby="create-title" className="w-full max-w-md rounded-t-xl bg-app-surface p-5 shadow-xl sm:rounded-xl"><div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3"><div><p className="text-xs font-semibold uppercase tracking-[0.1em] text-app-muted">Nuevo documento</p><h2 id="create-title" className="mt-1 font-ui text-xl font-semibold text-app-ink">Crear documento cifrado</h2></div><Button variant="ghost" size="icon" onClick={onClose} className="h-11 w-11" aria-label="Cerrar"><X /></Button></div><div className="mt-5 space-y-4"><label className="block"><span className="text-xs font-semibold text-app-muted">Nombre</span><span className="mt-1.5 flex h-11 items-center rounded-lg border border-app-line px-3 text-sm text-app-faint">Ej. Propuesta comercial</span></label><div className="rounded-lg border border-dashed border-app-line-strong bg-app-soft p-6 text-center"><Upload className="mx-auto h-6 w-6 text-app-primary" /><p className="mt-2 text-sm font-semibold text-app-ink">Seleccionar archivo</p><p className="mt-1 text-xs text-app-muted">Representación visual</p></div></div><div className="mt-6 flex justify-end gap-2"><Button variant="ghost" className="h-11" onClick={onClose}>Cancelar</Button><Button className="h-11 bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong">Crear documento</Button></div></div></div>;
}

function SwitchWarning({ open, onClose, onConfirm }: { open: boolean; onClose: () => void; onConfirm: () => void }) {
  if (!open) return null;
  return <div className="fixed inset-0 z-50 grid place-items-end bg-app-overlay p-0 sm:place-items-center sm:p-4"><div role="dialog" aria-modal="true" aria-labelledby="switch-title" className="w-full max-w-lg rounded-t-xl bg-app-surface p-6 shadow-xl sm:rounded-xl"><span className="grid h-12 w-12 place-items-center rounded-full bg-app-warning-soft text-app-warning"><Sparkles className="h-5 w-5" /></span><p className="mt-5 text-xs font-semibold uppercase tracking-[0.1em] text-app-muted">Cambiar a edición sencilla</p><h2 id="switch-title" className="mt-2 font-ui text-2xl font-semibold text-app-ink">Algunas opciones avanzadas no se muestran en Básico</h2><p className="mt-3 text-sm leading-6 text-app-muted">Tu versión Power se conservará para que puedas volver cuando quieras. No perderás tu trabajo.</p><div className="mt-7 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><Button variant="ghost" className="h-11" onClick={onClose}>Cancelar</Button><Button className="h-11 bg-app-primary text-app-primary-foreground hover:bg-app-primary-strong" onClick={onConfirm}>Cambiar a Básico</Button></div></div></div>;
}

export default function CripqerAppShell() {
  const [view, setView] = useState<View>("dashboard");
  
  const [createOpen, setCreateOpen] = useState(false);
  const [switchOpen, setSwitchOpen] = useState(false);

  useEffect(() => {
    const apply = () => setView(viewFromQuery());
    apply();
    const timer = window.setTimeout(apply, 350);
    return () => window.clearTimeout(timer);
  }, []);

  const onView = (next: View) => {
    if (next === "basic" && view === "power") setSwitchOpen(true);
    else setView(next);
  };

  if (view === "power") {
    return (
      <>
        <PowerEditor onBack={() => setView("dashboard")} onBasic={() => setSwitchOpen(true)} />
        <SwitchWarning open={switchOpen} onClose={() => setSwitchOpen(false)} onConfirm={() => { setSwitchOpen(false); setView("basic"); }} />
      </>
    );
  }

  const title = view === "dashboard" ? "Inicio" : view.startsWith("page-") ? "Mi página" : view === "documents" ? "Documentos cifrados" : view === "document-detail" ? "Documento" : view === "basic" ? "Editor" : "Perfil y cuenta";

  return (
    <div className="min-h-[100dvh] bg-app-background font-ui-body text-app-ink">
      <div className="flex min-h-[100dvh]">
        <AppSidebar view={view} onView={onView} />
        <div className="min-w-0 flex-1">
          <AppHeader title={title} eyebrow={view.startsWith("page-") ? "Centro de gestión" : undefined} />
          {view.startsWith("page-") ? <div className="bg-app-surface px-4 sm:px-6 lg:px-8"><LocalTabs view={view} onView={onView} /></div> : null}
          <main className="mx-auto w-full max-w-[1440px] px-4 pb-28 pt-6 sm:px-6 lg:px-8 lg:pb-10 lg:pt-8">
            {view === "dashboard" && <Dashboard onView={onView} />}
            {view === "page-summary" && <PageSummary onView={onView} />}
            {view === "page-preview" && <PagePreview onView={onView} />}
            {view === "page-publish" && <PublishView />}
            {view === "page-qr" && <QrView />}
            {view === "page-share" && <ShareView />}
            {view === "documents" && <DocumentsView onView={onView} onCreate={() => setCreateOpen(true)} />}
            {view === "document-detail" && <DocumentDetail onView={onView} />}
            {view === "profile" && <ProfileView onView={onView} />}
            {view === "basic" && <BasicEditor onPower={() => setView("power")} />}
          </main>
        </div>
      </div>
      <MobileNav view={view} onView={onView} />
      
      <CreateDocumentDialog open={createOpen} onClose={() => setCreateOpen(false)} />
      <SwitchWarning open={switchOpen} onClose={() => setSwitchOpen(false)} onConfirm={() => { setSwitchOpen(false); setView("basic"); }} />
    </div>
  );
}