import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  AlignCenter,
  AlignLeft,
  ArrowLeft,
  ArrowUpDown,
  Bold,
  Check,
  ChevronDown,
  ChevronRight,
  Copy,
  Crop,
  Eye,
  Image as ImageIcon,
  Italic,
  Layers,
  Link2,
  Lock,
  Maximize2,
  MoreHorizontal,
  MousePointer2,
  Move,
  Palette,
  PanelLeft,
  PanelRight,
  Plus,
  Redo2,
  Rocket,
  Search,
  Settings2,
  Smartphone,
  Sparkles,
  Square,
  Trash2,
  Type,
  Undo2,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-react";

/**
 * Cripqer — Power Editor · CASCARÓN VISUAL (UI/UX only)
 *
 * Esta pantalla es un prototipo de presentación: define estructura, jerarquía,
 * estados visuales y responsive. NO contiene engine, persistencia, historial,
 * cámara, ni sistema de selección real. Todo el estado local existe solo para
 * demostrar los estados de interfaz y será reemplazado por la lógica existente
 * de Cripqer en la capa de integración.
 */

type Sel = "none" | "text" | "image" | "button" | "section";
type Sheet = null | "style" | "color" | "layers" | "insert" | "inspector";

const SEL_META: Record<Exclude<Sel, "none">, { label: string; path: string; icon: typeof Type }> = {
  text: { label: "Texto", path: "Hero / Título", icon: Type },
  image: { label: "Imagen", path: "Hero / Media", icon: ImageIcon },
  button: { label: "Botón", path: "Hero / CTA primario", icon: Square },
  section: { label: "Sección", path: "Página / Hero", icon: Layers },
};

/* ---------------------------------------------------------------- primitives */

function IconBtn({
  icon: Icon,
  label,
  active,
  disabled,
  onClick,
  size = "md",
}: {
  icon: typeof Type;
  label: string;
  active?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  size?: "sm" | "md";
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      className={[
        "group relative inline-flex items-center justify-center rounded-lg transition-colors",
        size === "sm" ? "h-11 w-11 md:h-8 md:w-8" : "h-11 w-11 md:h-9 md:w-9",
        disabled
          ? "text-ed-faint/50 cursor-not-allowed"
          : active
            ? "bg-ed-accent/15 text-ed-accent"
            : "text-ed-muted hover:bg-ed-chrome-2 hover:text-ed-text",
      ].join(" ")}
    >
      <Icon className={size === "sm" ? "h-4 w-4" : "h-[18px] w-[18px]"} strokeWidth={1.75} />
    </button>
  );
}

function Chip({ children, tone = "muted" }: { children: ReactNode; tone?: "muted" | "accent" | "warn" }) {
  const tones = {
    muted: "border-ed-line text-ed-muted",
    accent: "border-ed-accent/40 text-ed-accent bg-ed-accent/10",
    warn: "border-ed-warn/40 text-ed-warn bg-ed-warn/10",
  } as const;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium tracking-wide ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

function Segmented({
  options,
  value,
  onChange,
}: {
  options: { id: string; icon?: typeof Type; label: string }[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="flex items-center gap-0.5 rounded-lg border border-ed-line bg-ed-bg/60 p-0.5">
      {options.map((o) => {
        const Icon = o.icon;
        const on = o.id === value;
        return (
          <button
            key={o.id}
            type="button"
            onClick={() => onChange(o.id)}
            title={o.label}
            className={[
              "inline-flex h-11 min-w-11 flex-1 items-center justify-center gap-1 rounded-md px-2 text-[11px] font-medium transition-colors md:h-7 md:min-w-7",
              on ? "bg-ed-elevated text-ed-text" : "text-ed-faint hover:text-ed-muted",
            ].join(" ")}
          >
            {Icon ? <Icon className="h-3.5 w-3.5" strokeWidth={1.75} /> : o.label}
          </button>
        );
      })}
    </div>
  );
}

function Field({ label, value, suffix }: { label: string; value: string; suffix?: string }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-[10px] font-medium uppercase tracking-[0.12em] text-ed-faint">{label}</span>
      <span className="flex h-8 items-center justify-between rounded-lg border border-ed-line bg-ed-bg/60 px-2.5 text-xs text-ed-text">
        {value}
        {suffix ? <span className="text-ed-faint">{suffix}</span> : null}
      </span>
    </label>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1.5">
      <span className="text-xs text-ed-muted">{label}</span>
      {children}
    </div>
  );
}

function PanelSection({
  title,
  children,
  action,
}: {
  title: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <section className="border-b border-ed-line px-4 py-4">
      <header className="mb-3 flex items-center justify-between">
        <h3 className="font-ui text-[11px] font-semibold uppercase tracking-[0.14em] text-ed-faint">
          {title}
        </h3>
        {action}
      </header>
      <div className="space-y-1">{children}</div>
    </section>
  );
}

function Swatches({ active = 0 }: { active?: number }) {
  const colors = ["#0f172a", "#2f6df6", "#12b8a6", "#f5a524", "#f14668", "#ffffff"];
  return (
    /* El círculo visible se mantiene compacto; el área táctil es ≥44px en móvil. */
    <div className="-my-1.5 flex items-center">
      {colors.map((c, i) => (
        <button
          key={c}
          type="button"
          aria-label={`Color ${c}`}
          className="grid h-12 w-12 shrink-0 place-items-center rounded-xl md:h-7 md:w-7"
        >
          <span
            className={`h-6 w-6 rounded-md border ${i === active ? "border-ed-accent ring-2 ring-ed-accent/30" : "border-ed-line-strong"}`}
            style={{ backgroundColor: c }}
          />
        </button>
      ))}
    </div>
  );
}

function Slider({ pct }: { pct: number }) {
  return (
    /* Riel visualmente fino con área táctil de 48px de alto en móvil. */
    <div className="relative -my-3 flex h-12 w-28 items-center md:my-0 md:h-4">
      <div className="relative h-1.5 w-full rounded-full bg-ed-elevated">
        <div className="absolute inset-y-0 left-0 rounded-full bg-ed-accent" style={{ width: `${pct}%` }} />
        <span
          className="absolute top-1/2 grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center md:h-5 md:w-5"
          style={{ left: `${pct}%` }}
        >
          <span className="h-3.5 w-3.5 rounded-full border-2 border-ed-accent bg-ed-chrome" />
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------- top bar */

function TopBar({
  saving,
  preview,
  leftOpen,
  inspectorOpen,
  onToggleLeft,
  onToggleInspector,
  onTogglePreview,
  device,
  setDevice,
  onBack,
  onBasic,
}: {
  saving: boolean;
  preview: boolean;
  leftOpen: boolean;
  inspectorOpen: boolean;
  onToggleLeft: () => void;
  onToggleInspector: () => void;
  onTogglePreview: () => void;
  device: string;
  setDevice: (d: string) => void;
  onBack?: (() => void) | undefined;
  onBasic?: (() => void) | undefined;
}) {
  const [modeMenu, setModeMenu] = useState(false);
  if (preview) {
    return (
      <header className="z-30 flex h-14 shrink-0 items-center gap-2 border-b border-ed-line bg-ed-chrome px-2 md:px-3">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-ed-accent/40 bg-ed-accent/10 px-3 py-1.5 text-xs font-semibold text-ed-accent">
          <Eye className="h-4 w-4" strokeWidth={1.75} /> Vista previa
        </span>
        <span className="hidden text-xs text-ed-faint sm:inline">Edición desactivada</span>
        <button
          type="button"
          onClick={onTogglePreview}
          className="ml-auto inline-flex h-11 items-center gap-1.5 rounded-xl border border-ed-line-strong px-3.5 text-sm font-semibold text-ed-text hover:bg-ed-chrome-2"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={2} /> Volver a editar
        </button>
      </header>
    );
  }

  return (
    <header className="relative z-30 flex h-14 shrink-0 items-center gap-2 border-b border-ed-line bg-ed-chrome px-2 md:px-3">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex h-11 items-center gap-1.5 rounded-xl px-2 text-sm font-medium text-ed-muted hover:bg-ed-chrome-2 hover:text-ed-text"
      >
        <ArrowLeft className="h-[18px] w-[18px]" strokeWidth={2} />
        <span className="hidden sm:inline">Volver</span>
      </button>

      <div className="flex min-w-0 items-center gap-2">
        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-ed-accent font-ui text-[13px] font-bold text-ed-accent-ink">
          C
        </span>
        <div className="hidden min-w-0 items-center gap-1.5 text-xs text-ed-muted md:flex">
          <span className="text-ed-text">Cripqer</span>
          <ChevronRight className="h-3.5 w-3.5 shrink-0 text-ed-faint" />
          <span className="truncate">Landing Aurora</span>
          <ChevronDown className="h-3.5 w-3.5 shrink-0 text-ed-faint" />
        </div>
      </div>

      <div className="mx-1 hidden h-6 w-px bg-ed-line md:block" />

      {onBasic ? (
        <>
          <div className="hidden items-center rounded-lg border border-ed-line bg-ed-bg/60 p-0.5 lg:flex">
            <span className="inline-flex h-8 items-center gap-1.5 rounded-md bg-ed-elevated px-3 text-xs font-semibold text-ed-text">
              <span className="h-1.5 w-1.5 rounded-full bg-ed-accent" /> Power
            </span>
            <button
              type="button"
              onClick={onBasic}
              className="h-8 rounded-md px-3 text-xs font-medium text-ed-muted hover:bg-ed-chrome-2 hover:text-ed-text"
            >
              Básico
            </button>
          </div>
          <div className="relative lg:hidden">
            <button
              type="button"
              onClick={() => setModeMenu((open) => !open)}
              aria-haspopup="dialog"
              aria-expanded={modeMenu}
              className="inline-flex h-11 items-center gap-1 rounded-xl border border-ed-line bg-ed-bg/60 px-3 text-sm font-semibold text-ed-text"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-ed-accent" /> Power
              <ChevronDown className="h-3.5 w-3.5 text-ed-faint" strokeWidth={2} />
            </button>
            {modeMenu ? (
              <div className="absolute left-0 top-[calc(100%+6px)] z-40 w-[min(78vw,280px)] rounded-xl border border-ed-line bg-ed-chrome p-3 shadow-xl" role="dialog" aria-label="Modo de edición">
                <p className="px-2 pb-2 text-[11px] font-semibold uppercase tracking-[0.1em] text-ed-faint">Modo de edición</p>
                <div className="flex h-12 items-center gap-2 rounded-lg bg-ed-elevated px-3 text-sm font-semibold text-ed-text">
                  <Check className="h-4 w-4 text-ed-accent" strokeWidth={2.5} /> Power Editor
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setModeMenu(false);
                    onBasic();
                  }}
                  className="mt-1 flex min-h-12 w-full items-center rounded-lg px-3 text-left text-sm font-medium text-ed-muted hover:bg-ed-chrome-2 hover:text-ed-text"
                >
                  Edición sencilla
                </button>
                <p className="px-3 pb-1 pt-2 text-xs text-ed-faint">¿Prefieres algo más sencillo?</p>
              </div>
            ) : null}
          </div>
        </>
      ) : null}

      <div className="hidden items-center gap-0.5 md:flex">
        <IconBtn icon={PanelLeft} label="Panel de capas" active={leftOpen} onClick={onToggleLeft} />
        <IconBtn icon={Undo2} label="Deshacer" />
        <IconBtn icon={Redo2} label="Rehacer (sin cambios por rehacer)" disabled />
      </div>

      <div className="ml-auto flex items-center gap-2">
        <span className="hidden md:inline-flex">
          {saving ? (
            <Chip tone="warn">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-ed-warn" />
              Guardando…
            </Chip>
          ) : (
            <Chip>
              <Check className="h-3 w-3" /> Guardado
            </Chip>
          )}
        </span>

        <div className="hidden lg:block">
          <Segmented
            options={[
              { id: "desktop", label: "Desktop", icon: Maximize2 },
              { id: "tablet", label: "Tablet", icon: Square },
              { id: "mobile", label: "Mobile", icon: Smartphone },
            ]}
            value={device}
            onChange={setDevice}
          />
        </div>

        <button
          type="button"
          onClick={onTogglePreview}
          className="inline-flex h-11 items-center gap-1.5 rounded-xl border border-ed-line px-3 text-xs font-medium text-ed-muted transition-colors hover:bg-ed-chrome-2 hover:text-ed-text"
        >
          <Eye className="h-4 w-4" strokeWidth={1.75} />
          <span className="hidden sm:inline">Vista previa</span>
        </button>

        <button
          type="button"
          className="inline-flex h-11 items-center gap-1.5 rounded-xl bg-ed-accent px-3.5 text-xs font-semibold text-ed-accent-ink transition-opacity hover:opacity-90"
        >
          <Rocket className="h-4 w-4" strokeWidth={2} />
          <span className="hidden sm:inline">Publicar</span>
        </button>

        <span className="hidden md:inline-flex">
          <IconBtn icon={PanelRight} label="Inspector" active={inspectorOpen} onClick={onToggleInspector} />
        </span>
      </div>
    </header>
  );
}

/* ---------------------------------------------------------------- nav rail */

function NavigationRail({ sel }: { sel: Sel }) {
  const items = [
    { icon: MousePointer2, label: "Seleccionar", active: sel !== "none" },
    { icon: Layers, label: "Capas" },
    { icon: Plus, label: "Insertar" },
    { icon: Palette, label: "Estilos" },
    { icon: Sparkles, label: "Assets" },
    { icon: Settings2, label: "Ajustes de página" },
  ];
  return (
    <nav className="hidden w-13 shrink-0 flex-col items-center gap-1 border-r border-ed-line bg-ed-chrome py-3 md:flex">
      {items.map((i, idx) => (
        <IconBtn key={i.label} icon={i.icon} label={i.label} active={idx === 0 ? i.active === true : false} />
      ))}
      <div className="mt-auto">
        <IconBtn icon={Search} label="Buscar" size="sm" />
      </div>
    </nav>
  );
}

/* --------------------------------------------------------------- left panel */

function LeftPanel({ sel }: { sel: Sel }) {
  const layers = [
    { id: "section", name: "Sección · Hero", depth: 0 },
    { id: "text", name: "Título", depth: 1 },
    { id: "p", name: "Párrafo", depth: 1 },
    { id: "button", name: "Botón · Empezar", depth: 1 },
    { id: "image", name: "Imagen · Mockup", depth: 1 },
    { id: "features", name: "Sección · Features", depth: 0 },
    { id: "footer", name: "Sección · Footer", depth: 0 },
  ];
  return (
    <aside className="hidden w-64 shrink-0 flex-col border-r border-ed-line bg-ed-chrome xl:flex">
      <div className="flex h-10 items-center justify-between border-b border-ed-line px-3">
        <span className="font-ui text-[11px] font-semibold uppercase tracking-[0.14em] text-ed-faint">
          Capas
        </span>
        <IconBtn icon={Plus} label="Añadir bloque" size="sm" />
      </div>
      <div className="flex-1 overflow-y-auto p-1.5">
        {layers.map((l) => {
          const on = l.id === sel;
          return (
            <div
              key={l.id}
              className={[
                "flex h-8 items-center gap-2 rounded-md px-2 text-xs",
                on ? "bg-ed-select/20 text-ed-text" : "text-ed-muted hover:bg-ed-chrome-2",
              ].join(" ")}
              style={{ paddingLeft: 8 + l.depth * 14 }}
            >
              {l.depth === 0 ? (
                <Layers className="h-3.5 w-3.5 shrink-0 text-ed-faint" strokeWidth={1.75} />
              ) : (
                <Square className="h-3 w-3 shrink-0 text-ed-faint" strokeWidth={1.75} />
              )}
              <span className="truncate">{l.name}</span>
              {on ? <span className="ml-auto h-1.5 w-1.5 rounded-full bg-ed-select" /> : null}
            </div>
          );
        })}
      </div>
      <div className="border-t border-ed-line px-3 py-2.5">
        <div className="flex items-center gap-2 text-[11px] text-ed-faint">
          <Lock className="h-3.5 w-3.5" strokeWidth={1.75} />
          Estructura gestionada por Cripqer
        </div>
      </div>
    </aside>
  );
}

/* ----------------------------------------------------------------- inspector */

function InspectorBody({ sel }: { sel: Sel }) {
  if (sel === "none") {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
        <span className="grid h-11 w-11 place-items-center rounded-xl border border-ed-line bg-ed-bg/60">
          <MousePointer2 className="h-5 w-5 text-ed-faint" strokeWidth={1.75} />
        </span>
        <p className="text-xs leading-relaxed text-ed-faint">
          Selecciona un elemento en el canvas
          <br />
          para ver qué puedes modificar.
        </p>
      </div>
    );
  }
  const meta = SEL_META[sel];
  return (
    <div className="flex-1 overflow-y-auto">
      <div className="flex items-center gap-2 border-b border-ed-line bg-ed-select/10 px-4 py-3">
        <meta.icon className="h-4 w-4 text-ed-select" strokeWidth={1.75} />
        <div className="min-w-0">
          <p className="truncate font-ui text-sm font-semibold text-ed-text">{meta.label}</p>
          <p className="truncate text-[11px] text-ed-faint">{meta.path}</p>
        </div>
        <div className="ml-auto flex items-center gap-0.5">
          <IconBtn icon={Copy} label="Duplicar" size="sm" />
          <IconBtn icon={Trash2} label="Eliminar" size="sm" />
        </div>
      </div>

      {sel === "text" && (
        <>
          <PanelSection title="Tipografía">
            <Row label="Familia">
              <span className="rounded-md border border-ed-line bg-ed-bg/60 px-2 py-1 text-xs">
                Space Grotesk
              </span>
            </Row>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <Field label="Tamaño" value="48" suffix="px" />
              <Field label="Alto línea" value="1.1" />
            </div>
            <Row label="Peso">
              <Segmented
                options={[
                  { id: "r", label: "400" },
                  { id: "m", label: "500" },
                  { id: "b", label: "700" },
                ]}
                value="b"
                onChange={() => {}}
              />
            </Row>
            <Row label="Estilo">
              <div className="flex gap-0.5">
                <IconBtn icon={Bold} label="Negrita" size="sm" active />
                <IconBtn icon={Italic} label="Cursiva" size="sm" />
                <IconBtn icon={Link2} label="Enlace" size="sm" />
              </div>
            </Row>
            <Row label="Alineación">
              <Segmented
                options={[
                  { id: "l", label: "Izquierda", icon: AlignLeft },
                  { id: "c", label: "Centro", icon: AlignCenter },
                ]}
                value="l"
                onChange={() => {}}
              />
            </Row>
          </PanelSection>
          <PanelSection title="Color">
            <Swatches active={5} />
            <Row label="Opacidad">
              <Slider pct={100} />
            </Row>
          </PanelSection>
        </>
      )}

      {sel === "image" && (
        <>
          <PanelSection title="Media">
            <div className="mb-3 aspect-video w-full overflow-hidden rounded-lg border border-ed-line bg-gradient-to-br from-ed-select/40 to-ed-accent/30" />
            <div className="grid grid-cols-2 gap-2">
              <button className="h-8 rounded-lg border border-ed-line text-xs text-ed-muted hover:text-ed-text">
                Reemplazar
              </button>
              <button className="inline-flex h-8 items-center justify-center gap-1.5 rounded-lg border border-ed-line text-xs text-ed-muted hover:text-ed-text">
                <Crop className="h-3.5 w-3.5" /> Recortar
              </button>
            </div>
          </PanelSection>
          <PanelSection title="Encaje">
            <Row label="Ajuste">
              <Segmented
                options={[
                  { id: "cover", label: "Cover" },
                  { id: "contain", label: "Contain" },
                ]}
                value="cover"
                onChange={() => {}}
              />
            </Row>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <Field label="Ancho" value="100" suffix="%" />
              <Field label="Radio" value="16" suffix="px" />
            </div>
            <Row label="Sombra">
              <Slider pct={45} />
            </Row>
          </PanelSection>
          <PanelSection title="Accesibilidad">
            <Field label="Texto alternativo" value="Mockup del editor" />
          </PanelSection>
        </>
      )}

      {sel === "button" && (
        <>
          <PanelSection title="Contenido">
            <Field label="Etiqueta" value="Empezar gratis" />
            <Field label="Destino" value="/signup" />
          </PanelSection>
          <PanelSection title="Apariencia">
            <Row label="Variante">
              <Segmented
                options={[
                  { id: "solid", label: "Solid" },
                  { id: "outline", label: "Outline" },
                  { id: "ghost", label: "Ghost" },
                ]}
                value="solid"
                onChange={() => {}}
              />
            </Row>
            <Row label="Tamaño">
              <Segmented
                options={[
                  { id: "s", label: "S" },
                  { id: "m", label: "M" },
                  { id: "l", label: "L" },
                ]}
                value="l"
                onChange={() => {}}
              />
            </Row>
            <Row label="Relleno">
              <Swatches active={1} />
            </Row>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <Field label="Radio" value="12" suffix="px" />
              <Field label="Padding X" value="24" suffix="px" />
            </div>
          </PanelSection>
          <PanelSection title="Estados">
            <div className="grid grid-cols-3 gap-2">
              {["Default", "Hover", "Disabled"].map((s, i) => (
                <div key={s} className="space-y-1.5 text-center">
                  <div
                    className={[
                      "grid h-8 place-items-center rounded-lg text-[10px] font-semibold",
                      i === 0 ? "bg-ed-select text-white" : i === 1 ? "bg-ed-select/80 text-white" : "bg-ed-elevated text-ed-faint",
                    ].join(" ")}
                  >
                    CTA
                  </div>
                  <span className="text-[10px] text-ed-faint">{s}</span>
                </div>
              ))}
            </div>
          </PanelSection>
        </>
      )}

      {sel === "section" && (
        <>
          <PanelSection title="Layout">
            <Row label="Dirección">
              <Segmented
                options={[
                  { id: "row", label: "Fila" },
                  { id: "col", label: "Columna" },
                ]}
                value="row"
                onChange={() => {}}
              />
            </Row>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <Field label="Padding Y" value="96" suffix="px" />
              <Field label="Gap" value="48" suffix="px" />
            </div>
            <Row label="Ancho máx.">
              <span className="text-xs text-ed-text">1200 px</span>
            </Row>
          </PanelSection>
          <PanelSection title="Fondo">
            <Swatches active={0} />
            <Row label="Opacidad">
              <Slider pct={80} />
            </Row>
          </PanelSection>
        </>
      )}

      <div className="px-4 py-4">
        <div className="rounded-lg border border-dashed border-ed-line px-3 py-2.5 text-[11px] leading-relaxed text-ed-faint">
          Controles visuales. La lógica se conecta al engine existente de Cripqer.
        </div>
      </div>
    </div>
  );
}

function Inspector({ sel }: { sel: Sel }) {
  return (
    <aside className="hidden w-[300px] shrink-0 flex-col border-l border-ed-line bg-ed-chrome lg:flex">
      <div className="flex h-10 items-center justify-between border-b border-ed-line px-3">
        <span className="font-ui text-[11px] font-semibold uppercase tracking-[0.14em] text-ed-faint">
          Inspector
        </span>
        <IconBtn icon={MoreHorizontal} label="Más opciones" size="sm" />
      </div>
      <InspectorBody sel={sel} />
    </aside>
  );
}

/* -------------------------------------------------------------------- canvas */

function Handles() {
  const pos = ["-top-1 -left-1", "-top-1 -right-1", "-bottom-1 -left-1", "-bottom-1 -right-1"];
  return (
    <>
      {pos.map((p) => (
        <span
          key={p}
          className={`absolute ${p} h-2.5 w-2.5 rounded-[3px] border-2 border-ed-select bg-white`}
        />
      ))}
    </>
  );
}

function FloatingToolbar({ sel }: { sel: Exclude<Sel, "none"> }) {
  // Solo las acciones de mayor frecuencia. El resto vive en "Más" / Inspector.
  const sets: Record<Exclude<Sel, "none">, { icon: typeof Type; label: string }[]> = {
    text: [
      { icon: Type, label: "Editar" },
      { icon: Palette, label: "Color" },
      { icon: AlignLeft, label: "Alinear" },
      { icon: Bold, label: "Tipografía" },
    ],
    image: [
      { icon: ImageIcon, label: "Reemplazar" },
      { icon: Crop, label: "Recortar" },
      { icon: Palette, label: "Estilo" },
    ],
    button: [
      { icon: Type, label: "Texto" },
      { icon: Link2, label: "Enlace" },
      { icon: Palette, label: "Estilo" },
    ],
    section: [
      { icon: Move, label: "Mover" },
      { icon: ArrowUpDown, label: "Reordenar" },
      { icon: Palette, label: "Fondo" },
    ],
  };
  return (
    <div className="absolute -top-11 left-0 z-20 hidden items-center gap-0.5 rounded-xl border border-ed-line-strong bg-ed-elevated/95 p-1 ed-shadow backdrop-blur md:flex">
      <span className="mr-1 inline-flex items-center gap-1 rounded-lg bg-ed-select/25 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-white">
        {SEL_META[sel].label}
      </span>
      {sets[sel].map((b) => (
        <IconBtn key={b.label} icon={b.icon} label={b.label} size="sm" />
      ))}
      <span className="mx-0.5 h-5 w-px bg-ed-line-strong" />
      <button
        type="button"
        className="inline-flex h-8 items-center gap-1 rounded-lg px-2 text-[11px] font-medium text-ed-muted hover:bg-ed-chrome-2 hover:text-ed-text"
      >
        <MoreHorizontal className="h-4 w-4" strokeWidth={1.75} /> Más
      </button>
    </div>
  );
}

function Selectable({
  id,
  sel,
  onSelect,
  children,
  preview,
  className = "",
}: {
  id: Exclude<Sel, "none">;
  sel: Sel;
  onSelect: (s: Sel) => void;
  children: ReactNode;
  preview: boolean;
  className?: string;
}) {
  const on = sel === id && !preview;
  const ref = useRef<HTMLDivElement>(null);
  // Reposiciona el canvas para que el objeto seleccionado siga visible.
  useEffect(() => {
    if (on && ref.current && window.innerWidth < 1024) {
      ref.current.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [on]);
  return (
    <div
      ref={ref}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(id);
      }}
      className={`relative ${className} ${preview ? "" : "cursor-default hover:outline hover:outline-1 hover:outline-ed-select/40"} ${
        on ? "outline outline-2 outline-ed-select" : ""
      }`}
    >
      {on ? (
        <>
          <Handles />
          <FloatingToolbar sel={id} />
          <span className="absolute -bottom-6 left-0 hidden rounded-md bg-ed-select px-1.5 py-0.5 text-[10px] font-medium text-white md:inline-block">
            {SEL_META[id].label}
          </span>
        </>
      ) : null}
      {children}
    </div>
  );
}

function CanvasPage({
  sel,
  onSelect,
  preview,
  editing,
}: {
  sel: Sel;
  onSelect: (s: Sel) => void;
  preview: boolean;
  editing: boolean;
}) {
  return (
    <Selectable id="section" sel={sel} onSelect={onSelect} preview={preview} className="@container bg-ed-page">
      <div className="px-6 py-10 @lg:px-10 @lg:py-14 @3xl:px-16 @3xl:py-20">
        <div className="mx-auto flex max-w-5xl flex-col gap-10 @2xl:flex-row @2xl:items-center @2xl:gap-14">
          <div className="flex-1 space-y-5">
            <span className="inline-flex rounded-full bg-[#0f172a]/8 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#0f172a]/60">
              Cripqer Studio
            </span>
            <Selectable id="text" sel={sel} onSelect={onSelect} preview={preview}>
              <h1
                className="font-ui text-3xl leading-[1.08] font-bold text-ed-page-ink @xl:text-4xl @3xl:text-5xl"
                style={{ caretColor: "#2f6df6" }}
              >
                <span className={sel === "text" && !preview ? "bg-ed-select/25" : ""}>
                  Construye páginas que ya saben cómo verse.
                </span>
                {editing ? (
                  <span className="ml-0.5 inline-block h-[1em] w-[2px] animate-pulse align-middle bg-[#2f6df6]" />
                ) : null}
              </h1>
            </Selectable>
            <p className="max-w-md text-sm leading-relaxed text-ed-page-ink/70 @xl:text-base">
              Edita en el canvas, ajusta en el inspector y publica sin salir del contexto. Cero
              fricción entre intención y resultado.
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <Selectable id="button" sel={sel} onSelect={onSelect} preview={preview} className="rounded-xl">
                <button className="rounded-xl bg-[#2f6df6] px-6 py-3 text-sm font-semibold text-white">
                  Empezar gratis
                </button>
              </Selectable>
              <button className="rounded-xl border border-[#0f172a]/15 px-5 py-3 text-sm font-semibold text-ed-page-ink/80">
                Ver demo
              </button>
            </div>
          </div>
          <Selectable
            id="image"
            sel={sel}
            onSelect={onSelect}
            preview={preview}
            className="flex-1 rounded-2xl"
          >
            <div className="aspect-4/3 w-full overflow-hidden rounded-2xl bg-gradient-to-br from-[#2f6df6] via-[#5b8cff] to-[#12b8a6]">
              <div className="flex h-full flex-col gap-2 p-5">
                <div className="h-2.5 w-20 rounded-full bg-white/50" />
                <div className="h-2.5 w-32 rounded-full bg-white/35" />
                <div className="mt-auto grid grid-cols-3 gap-2">
                  <div className="h-12 rounded-lg bg-white/25" />
                  <div className="h-12 rounded-lg bg-white/20" />
                  <div className="h-12 rounded-lg bg-white/15" />
                </div>
              </div>
            </div>
          </Selectable>
        </div>

        <div className="mx-auto mt-14 grid max-w-5xl gap-4 @xl:grid-cols-3">
          {["Bloques", "Estilos", "Publicación"].map((t) => (
            <div key={t} className="rounded-xl border border-[#0f172a]/10 p-4">
              <p className="font-ui text-sm font-semibold text-ed-page-ink">{t}</p>
              <p className="mt-1 text-xs leading-relaxed text-ed-page-ink/60">
                Estructura clara, control directo y feedback inmediato.
              </p>
            </div>
          ))}
        </div>
      </div>
    </Selectable>
  );
}

function ZoomControls({ zoom, setZoom }: { zoom: number; setZoom: (z: number) => void }) {
  return (
    <div className="absolute bottom-4 left-4 z-20 hidden items-center md:flex gap-0.5 rounded-xl border border-ed-line-strong bg-ed-elevated/90 p-1 ed-shadow backdrop-blur">
      <IconBtn icon={ZoomOut} label="Alejar" size="sm" onClick={() => setZoom(Math.max(50, zoom - 10))} />
      <button
        type="button"
        onClick={() => setZoom(100)}
        className="min-w-12 rounded-md px-1 text-[11px] font-semibold text-ed-text tabular-nums hover:bg-ed-chrome-2"
      >
        {zoom}%
      </button>
      <IconBtn icon={ZoomIn} label="Acercar" size="sm" onClick={() => setZoom(Math.min(200, zoom + 10))} />
      <span className="mx-0.5 h-5 w-px bg-ed-line-strong" />
      <IconBtn icon={Maximize2} label="Ajustar a pantalla" size="sm" onClick={() => setZoom(100)} />
    </div>
  );
}

/* --------------------------------------------------------------- mobile dock */

/**
 * UNA sola región inferior primaria. La selección TRANSFORMA el dock,
 * no añade una segunda barra. Hit areas ≥48px.
 */
function MobileDock({
  sel,
  onSheet,
  saving,
  onPreview,
  sheetOpen = false,
}: {
  sel: Sel;
  onSheet: (s: Sheet) => void;
  saving: boolean;
  onPreview: () => void;
  sheetOpen?: boolean;
}) {
  const sets: Record<Sel, { icon: typeof Type; label: string; sheet: Sheet }[]> = {
    none: [
      { icon: Plus, label: "Añadir", sheet: "insert" },
      { icon: Layers, label: "Secciones", sheet: "layers" },
      { icon: ImageIcon, label: "Media", sheet: "insert" },
      { icon: Square, label: "Páginas", sheet: "layers" },
      { icon: MoreHorizontal, label: "Más", sheet: "inspector" },
    ],
    text: [
      { icon: Type, label: "Editar", sheet: "style" },
      { icon: Bold, label: "Tipografía", sheet: "style" },
      { icon: Palette, label: "Color", sheet: "color" },
      { icon: AlignLeft, label: "Alinear", sheet: "style" },
      { icon: MoreHorizontal, label: "Más", sheet: "inspector" },
    ],
    image: [
      { icon: ImageIcon, label: "Reemplazar", sheet: "insert" },
      { icon: Crop, label: "Recortar", sheet: "style" },
      { icon: Palette, label: "Estilo", sheet: "style" },
      { icon: ArrowUpDown, label: "Orden", sheet: "layers" },
      { icon: MoreHorizontal, label: "Más", sheet: "inspector" },
    ],
    button: [
      { icon: Type, label: "Texto", sheet: "style" },
      { icon: Link2, label: "Enlace", sheet: "inspector" },
      { icon: Palette, label: "Estilo", sheet: "style" },
      { icon: Maximize2, label: "Tamaño", sheet: "style" },
      { icon: MoreHorizontal, label: "Más", sheet: "inspector" },
    ],
    section: [
      { icon: Move, label: "Layout", sheet: "style" },
      { icon: Palette, label: "Fondo", sheet: "color" },
      { icon: ArrowUpDown, label: "Orden", sheet: "layers" },
      { icon: Copy, label: "Duplicar", sheet: "inspector" },
      { icon: MoreHorizontal, label: "Más", sheet: "inspector" },
    ],
  };
  const items = sets[sel];
  return (
    <div className="shrink-0 border-t border-ed-line bg-ed-chrome lg:hidden">
      <div
        className={`${sheetOpen ? "hidden" : "flex"} items-center justify-between gap-2 px-2 py-1.5`}
      >
        <div className="flex min-w-0 items-center gap-1.5">
          {sel === "none" ? (
            <span className="truncate text-[11px] text-ed-faint">Sin selección</span>
          ) : (
            <span className="inline-flex min-w-0 items-center gap-1.5 rounded-full bg-ed-select/20 px-2 py-1 text-[11px] font-semibold text-ed-text">
              {(() => {
                const I = SEL_META[sel].icon;
                return <I className="h-3.5 w-3.5 shrink-0 text-ed-select" strokeWidth={2} />;
              })()}
              <span className="truncate">{SEL_META[sel].path}</span>
            </span>
          )}
        </div>
        <div className="flex shrink-0 items-center gap-0.5">
          <IconBtn icon={Undo2} label="Deshacer" />
          <IconBtn icon={Redo2} label="Rehacer" disabled />
          <span className="px-1 text-[10px] font-medium text-ed-faint">
            {saving ? "Guardando…" : "Guardado"}
          </span>
          <IconBtn icon={Eye} label="Vista previa" onClick={onPreview} />
        </div>
      </div>
      {/* Con la hoja abierta el dock se compacta (solo iconos, 44px) para no robar canvas. */}
      <nav
        className={`grid grid-cols-5 gap-1 border-t border-ed-line px-1.5 ${sheetOpen ? "py-0.5" : "pt-1 pb-2"}`}
      >
        {items.map((i) => (
          <button
            key={i.label}
            type="button"
            onClick={() => onSheet(i.sheet)}
            aria-label={i.label}
            className={`flex flex-col items-center justify-center gap-1 rounded-xl px-1 text-ed-muted active:bg-ed-chrome-2 ${sheetOpen ? "min-h-11" : "min-h-12 py-1.5"}`}
          >
            <i.icon className="h-5 w-5" strokeWidth={1.75} />
            {!sheetOpen ? (
              <span className="text-[10px] font-medium leading-none">{i.label}</span>
            ) : null}
          </button>
        ))}
      </nav>
    </div>
  );
}

function BottomSheet({
  sheet,
  sel,
  onClose,
}: {
  sheet: Sheet;
  sel: Sel;
  onClose: () => void;
}) {
  if (!sheet) return null;
  const titles: Record<string, string> = {
    style: "Estilo",
    color: "Color",
    layers: "Capas",
    insert: "Insertar",
    inspector: "Inspector",
  };
  return (
    /* Sin backdrop oscuro: la hoja convive con el canvas, que sigue iluminado. */
    <div className="shrink-0 xl:hidden">
      <div className="flex max-h-[42vh] flex-col rounded-t-2xl border-t border-ed-line-strong bg-ed-chrome ed-shadow">
        <button
          type="button"
          onClick={onClose}
          aria-label="Colapsar panel"
          className="flex h-6 shrink-0 items-center justify-center"
        >
          <span className="h-1.5 w-10 rounded-full bg-ed-line-strong" />
        </button>
        <div className="flex shrink-0 items-center justify-between border-b border-ed-line px-4 pb-2">
          <p className="font-ui text-sm font-semibold text-ed-text">
            {titles[sheet]}
            {sel !== "none" && sheet !== "insert" && sheet !== "layers" ? (
              <span className="ml-2 text-[11px] font-normal text-ed-faint">{SEL_META[sel].label}</span>
            ) : null}
          </p>
          <IconBtn icon={X} label="Cerrar" onClick={onClose} />
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">


        {sheet === "color" ? (
          <div className="space-y-5 p-4">
            <div className="h-28 rounded-xl bg-gradient-to-br from-[#2f6df6] via-[#12b8a6] to-[#f5a524]" />
            <div>
              <p className="mb-2 text-[11px] uppercase tracking-[0.12em] text-ed-faint">Paleta del proyecto</p>
              <div className="grid grid-cols-6 gap-2">
                {["#0f172a", "#2f6df6", "#12b8a6", "#f5a524", "#f14668", "#ffffff"].map((c, i) => (
                  <span
                    key={c}
                    className={`aspect-square rounded-lg border ${i === 1 ? "border-ed-accent ring-2 ring-ed-accent/30" : "border-ed-line-strong"}`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-ed-muted">Opacidad</span>
              <Slider pct={100} />
            </div>
            <div className="flex items-center justify-between rounded-lg border border-ed-line bg-ed-bg/60 px-3 py-2 text-xs">
              <span className="text-ed-faint">HEX</span>
              <span className="text-ed-text">#2F6DF6</span>
            </div>
          </div>
        ) : sheet === "inspector" ? (
          <div className="flex min-h-64 flex-col">
            <InspectorBody sel={sel} />
          </div>
        ) : sheet === "layers" ? (
          <div className="p-2">
            {["Sección · Hero", "Título", "Párrafo", "Botón · Empezar", "Imagen · Mockup", "Sección · Features"].map(
              (n, i) => (
                <div
                  key={n}
                  className={`flex h-10 items-center gap-2 rounded-lg px-3 text-sm ${i === 1 ? "bg-ed-select/20 text-ed-text" : "text-ed-muted"}`}
                >
                  <Square className="h-3.5 w-3.5 text-ed-faint" strokeWidth={1.75} />
                  {n}
                </div>
              ),
            )}
          </div>
        ) : sheet === "insert" ? (
          <div className="grid grid-cols-3 gap-2 p-4">
            {["Texto", "Imagen", "Botón", "Sección", "Galería", "Formulario"].map((n) => (
              <div
                key={n}
                className="flex aspect-4/3 flex-col items-center justify-center gap-2 rounded-xl border border-ed-line bg-ed-bg/50 text-xs text-ed-muted"
              >
                <Plus className="h-4 w-4" strokeWidth={1.75} />
                {n}
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4 p-4">
            <div>
              <p className="mb-2 text-[11px] uppercase tracking-[0.12em] text-ed-faint">Tamaño</p>
              <Segmented
                options={[
                  { id: "s", label: "S" },
                  { id: "m", label: "M" },
                  { id: "l", label: "L" },
                  { id: "xl", label: "XL" },
                ]}
                value="l"
                onChange={() => {}}
              />
            </div>
            <div>
              <p className="mb-2 text-[11px] uppercase tracking-[0.12em] text-ed-faint">Peso</p>
              <Segmented
                options={[
                  { id: "r", label: "Regular" },
                  { id: "m", label: "Medium" },
                  { id: "b", label: "Bold" },
                ]}
                value="b"
                onChange={() => {}}
              />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-ed-muted">Alto de línea</span>
              <Slider pct={35} />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-ed-muted">Espaciado</span>
              <Slider pct={60} />
            </div>
            <div>
              <p className="mb-2 text-[11px] uppercase tracking-[0.12em] text-ed-faint">Color</p>
              <Swatches active={5} />
            </div>
          </div>
        )}
          <div className="px-4 pb-4 pt-1">
            <p className="text-[11px] text-ed-faint">
              Los cambios se reflejan en el canvas, que permanece visible arriba.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function FakeKeyboard() {
  const rows = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"];
  return (
    <div className="shrink-0 border-t border-ed-line-strong bg-ed-chrome-2 lg:hidden">
      <div className="flex items-center gap-2 overflow-x-auto border-b border-ed-line px-3 py-2">
        {[Bold, Italic, Link2, AlignLeft, Palette, Type].map((I, i) => (
          <span
            key={i}
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-ed-line bg-ed-bg/60 text-ed-muted"
          >
            <I className="h-4 w-4" strokeWidth={1.75} />
          </span>
        ))}
        <span className="ml-auto shrink-0 rounded-full bg-ed-accent px-3 py-1.5 text-[11px] font-semibold text-ed-accent-ink">
          Listo
        </span>
      </div>
      <div className="space-y-1.5 bg-ed-bg/60 px-1.5 py-2">
        {rows.map((r, idx) => (
          <div key={r} className={`flex justify-center gap-1 ${idx === 1 ? "px-4" : idx === 2 ? "px-9" : ""}`}>
            {r.split("").map((k) => (
              <span
                key={k}
                className="grid h-9 flex-1 place-items-center rounded-md bg-ed-elevated text-xs font-medium text-ed-text"
              >
                {k}
              </span>
            ))}
          </div>
        ))}
        <div className="flex justify-center gap-1 px-2">
          <span className="grid h-9 w-12 place-items-center rounded-md bg-ed-chrome text-[10px] text-ed-muted">123</span>
          <span className="h-9 flex-1 rounded-md bg-ed-elevated" />
          <span className="grid h-9 w-14 place-items-center rounded-md bg-ed-select/70 text-[10px] font-semibold text-white">
            enter
          </span>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- shell */

export default function PowerEditor({ onBack, onBasic }: { onBack?: () => void; onBasic?: () => void } = {}) {
  const [sel, setSel] = useState<Sel>("none");
  const [sheet, setSheet] = useState<Sheet>(null);
  const [keyboard, setKeyboard] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState(false);
  const [leftOpen, setLeftOpen] = useState(true);
  const [inspectorOpen, setInspectorOpen] = useState(true);
  const [device, setDevice] = useState("desktop");

  // Deep-link de estados: solo para capturar evidencia visual de cada estado.
  useEffect(() => {
    const apply = () => {
    const q = new URLSearchParams(window.location.search);
    const s = q.get("sel") as Sel | null;
    if (s) setSel(s);
    const sh = q.get("sheet") as Sheet | null;
    if (sh) setSheet(sh);
    if (q.get("kb")) setKeyboard(true);
    if (q.get("saving")) setSaving(true);
    if (q.get("preview")) setPreview(true);
    if (q.get("left") === "0") setLeftOpen(false);
    if (q.get("insp") === "0") setInspectorOpen(false);
    const z = q.get("zoom");
    if (z) setZoom(Number(z));
    };
    apply();
    const t = setTimeout(apply, 400);
    return () => clearTimeout(t);
  }, []);

  // Representación visual del dispositivo elegido (solo encuadre, sin engine responsive).
  const frame =
    device === "mobile"
      ? { max: 390, label: "móvil", width: "390 px" }
      : device === "tablet"
        ? { max: 834, label: "tablet", width: "834 px" }
        : { max: 1200, label: "escritorio", width: "1200 px" };

  return (
    <div className="relative flex h-[100dvh] w-full flex-col overflow-hidden bg-ed-bg font-ui-body text-ed-text">
      <TopBar
        saving={saving}
        preview={preview}
        leftOpen={leftOpen}
        inspectorOpen={inspectorOpen}
        onToggleLeft={() => setLeftOpen(!leftOpen)}
        onToggleInspector={() => setInspectorOpen(!inspectorOpen)}
        onTogglePreview={() => setPreview(!preview)}
        device={device}
        setDevice={setDevice}
        onBack={onBack}
        onBasic={onBasic}
      />

      <div className="flex min-h-0 flex-1">
        {!preview && <NavigationRail sel={sel} />}
        {!preview && leftOpen && <LeftPanel sel={sel} />}

        <main className="relative flex min-w-0 flex-1 flex-col bg-ed-canvas">
          <div className="flex h-9 shrink-0 items-center gap-2 border-b border-ed-line bg-ed-canvas px-3 text-[11px] text-ed-faint">
            <span className="text-ed-muted">Página · Home</span>
            {sel !== "none" && !preview ? (
              <>
                <ChevronRight className="h-3 w-3" />
                <span className="text-ed-select">{SEL_META[sel].path}</span>
              </>
            ) : null}
            <span className="ml-auto hidden md:inline">
              {preview ? "Vista previa · edición desactivada" : `${frame.width} · ${frame.label}`}
            </span>
          </div>

          <div className="ed-grid-bg relative min-h-0 flex-1 overflow-auto">
            <div
              className="mx-auto my-4 w-full px-3 md:my-8 md:px-8"
              style={{ maxWidth: frame.max, width: `${zoom}%` }}
              onClick={() => setSel("none")}
            >
              <div className="overflow-hidden rounded-xl bg-ed-page ed-shadow">
                <div className="flex h-7 items-center gap-1.5 border-b border-black/5 bg-black/3 px-3">
                  <span className="h-2 w-2 rounded-full bg-black/15" />
                  <span className="h-2 w-2 rounded-full bg-black/15" />
                  <span className="h-2 w-2 rounded-full bg-black/15" />
                  <span className="ml-2 text-[10px] text-black/40">cripqer.app/home</span>
                </div>
                <CanvasPage sel={sel} onSelect={setSel} preview={preview} editing={keyboard} />
              </div>
            </div>
          </div>

          {!preview && <ZoomControls zoom={zoom} setZoom={setZoom} />}
        </main>

        {!preview && inspectorOpen && <Inspector sel={sel} />}
      </div>

      {!preview && !keyboard ? (
        <MobileDock
          sel={sel}
          onSheet={setSheet}
          saving={saving}
          onPreview={() => setPreview(true)}
          sheetOpen={sheet !== null}
        />
      ) : null}
      {keyboard ? <FakeKeyboard /> : null}

      {!preview ? <BottomSheet sheet={sheet} sel={sel} onClose={() => setSheet(null)} /> : null}
    </div>
  );
}
