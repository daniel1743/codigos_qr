import { createFileRoute } from "@tanstack/react-router";

import PowerEditor from "@/components/editor/PowerEditor";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cripqer Power Editor — Arquitectura visual UI/UX" },
      {
        name: "description",
        content:
          "Cascarón visual del Power Editor de Cripqer: topbar, canvas protagonista, rail, inspector contextual, bottom dock y sheets en desktop, tablet y mobile.",
      },
      { property: "og:title", content: "Cripqer Power Editor — Arquitectura visual UI/UX" },
      {
        property: "og:description",
        content:
          "Prototipo visual del Power Editor: jerarquía, estados de selección, inspector contextual y responsive completo.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PowerEditor,
});
